// Map key
// export const MAP_API_KEY="AIzaSyCIvt4PUYtPxUczjN2hmbDY-gTCHK1wZ7k"; 
export const MAP_API_KEY="AIzaSyBVgspnXgBCGDpQWARl0sZyKyK2pT7MMZw"; 

//phone number validation regex
export const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/

//password validation regex
export const passwordValidationRegx =new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
export const websiterRegx = new RegExp(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
// export const passwordValidationRegx =new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");

// const DynamicLinkTxt="google-site-verification=MHFKvnMChd-9FdZgIjLFw-W5bobU-WtYSgNjZVjYMtg"

// const url=`${"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=1600+Surat&key=AIzaSyBVgspnXgBCGDpQWARl0sZyKyK2pT7MMZw"}`
