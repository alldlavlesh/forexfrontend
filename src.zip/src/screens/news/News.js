import React, { useRef, useState, useEffect } from 'react';
import { Text, View, FlatList, ScrollView, Alert, StatusBar, LogBox, KeyboardAvoidingView, Platform, Keyboard, Modal, Button, Image, ImageBackground, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, ImageIcons, CommonStrings, Api } from '../../common'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import select from '../../common/select.png'
import { SwipeablePanel } from 'rn-swipeable-panel';
import SwipeButton from 'rn-swipe-button';
import SearchBar from '../../components/forms/inputField/SearchBar';
import NewsDetails from './NewsDetails';
import moment from 'moment';

const News = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;


    const [search, setSearch] = useState("");
    const defaultStatusMessage = 'swipe status appears here';
    const [swipeStatusMessage, setSwipeStatusMessage] = useState(
        defaultStatusMessage,
    );
    const [panelProps, setPanelProps] = useState({
        fullWidth: true,
        openLarge: true,
        showCloseButton: false,

        // ...or any prop you want
    });

    useEffect(() => {

        // props?.getNewsList();
        props?.searchNews({
            search: ""
        });


    }, [])

    const searchText = (e) => {
        props?.searchNews({
            search: e
        });
        setSearch(e);

    }

    const DATA = [
        {
            img: ImageIcons.stevs_forex_patience_strategy_1,
            text: 'Forex collection in jump for world',
            text1: '15 August 2023',
            img1: ImageIcons.Chart,

        },
        {
            img: ImageIcons.stevs_forex_patience_strategy_1,
            text: 'Forex collection in jump for world',
            text1: '15 August 2023',
            img1: ImageIcons.Chart1,

        },
        {
            img: ImageIcons.stevs_forex_patience_strategy_1,
            text: 'Forex collection in jump for world',
            text1: '15 August 2023',
            img1: ImageIcons.Chart2,

        },

    ]

    const renderItem1 = ({ item, index }) => {
        return (
            <View style={tw` p-2 `}>
                <TouchableOpacity onPress={() => props?.navigation?.navigate("NewsDetails", { item: item })}>
                    <Image source={{ uri: Api.fileUrl + item?.image }} style={tw` h-26 w-40 `} />
                    <Text style={tw`text-center text-[#171717] font-bold text-sm leading-4 mt-2 mx-3 `} numberOfLines={1}>{item.title}</Text>
                    <Text style={tw`text-center text-[#848484] mt-1 text-3 mb-4`}>{moment(item.createdat).format('DD MMMM YYYY')}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);
    return (
        <>
            <View style={{ backgroundColor: '#FFFFFF', flex: 1, }}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'News'} />
                <View style={tw`mt-5 flex justify-center items-center  w-12/12 `}>
                    <ScrollView contentContainerStyle={{}} keyboardShouldPersistTaps='handled'>

                        <View style={tw` items-center flex justify-center  `}>
                            <SearchBar
                                style={tw` border-inherit`}
                                value={search}
                                onChangeText={(search) => searchText(search)}
                                placeholder="Search by News"
                                placeholderTextColor={Colors.GREY}
                            />
                        </View>

                        <View style={tw`flex mt-5 items-center`}>
                            <FlatList
                                numColumns={2}
                                data={props?.searchNewsdata}
                                renderItem={renderItem1}
                                keyExtractor={item => item?.id}
                            />
                        </View>

                    </ScrollView>
                </View>
            </View>
        </>

    )
}

export default (News);