import React, { useRef, useState } from 'react';
import { Text, View, ScrollView, FlatList, Alert, StatusBar, LogBox, KeyboardAvoidingView, Platform, Keyboard, Modal, Button, Image, ImageBackground, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, ImageIcons, CommonStrings, Api } from '../../common'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import select from '../../common/select.png'
import { SwipeablePanel } from 'rn-swipeable-panel';
import SwipeButton from 'rn-swipe-button';
import SearchBar from '../../components/forms/inputField/SearchBar';
import moment from 'moment';

const NewsDetails = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const itemget = props?.route?.params?.item
    const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);
    const DATA = [
        {
            img: ImageIcons.stevs_forex_patience_strategy_4,
            text: '15 August 2023',
            text1: 'Forex is rulling out in the world',
            text2: 'Justo donec enim diam vulputate ut pharetra. Ut placerat orci nulla pellentesque dignissim. Laoreet suspendisse interdum',
            text3: 'more',
            img1: ImageIcons.Chart,
        },

    ]

    return (
        <>
            <View style={{ backgroundColor: '#FFFFFF', flex: 1 }}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'News'}  style={tw`bg-[#FFFFFF] `}/>

                <ScrollView contentContainerStyle={{}} keyboardShouldPersistTaps='handled'>
            <View style={tw`mt-2 flex  items-center`}>
            <Image source={{ uri: Api.fileUrl + itemget?.image }} style={tw`rounded-3 h-50 w-84`} />

                        <View style={tw`flex-start ml-2`}>
               <Text style={tw`text-[#1ABC7B] font-bold text-sm mt-6`}>{moment(itemget?.createdat).format('DD MMMM YYYY')}</Text>
           <Text style={tw`text-[#171717] font-bold text-xl`}>{itemget?.title}</Text>
           <Text style={tw`text-[#848484] text-sm mt-2`}>{itemget?.description}</Text>
          </View>
        </View>
</ScrollView>
            </View>
        </>

    )
}




export default (NewsDetails);