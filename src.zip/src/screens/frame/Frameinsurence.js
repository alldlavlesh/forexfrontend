import React, { useEffect, useState,useRef } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, ScrollView,Alert, Image ,ImageBackground,TextInput,Keyboard} from 'react-native';
import { Fonts, Colors, ImageIcons ,CommonStrings} from '../../common';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import InputField from '../../components/forms/inputField';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import { BarChart } from "react-native-chart-kit";
import styles from './styles';
import InsightFilterModal from '../../components/modals/InsightFilterModal';
import moment from 'moment';
import Loader from '../../components/modals/Loader';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import ImagePicker from 'react-native-image-crop-picker';
import { websiterRegx } from '../../services/helper';
import { WebView } from 'react-native-webview';

const Frameinsurence = (props) => {

    const {
        navigation    
    } = props;

    return (
        <WebView
          source={{ uri: 'https://wallpon-financial.typeform.com/to/QSm7zbhG' }}
          style={{ marginTop: 0 }}
        />                
    )
}



export default Frameinsurence;
