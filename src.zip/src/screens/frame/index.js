import React, { useEffect, useState, useCallback } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, Image, ImageBackground, ScrollView, Dimensions } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import { useFocusEffect } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';

import { initialState } from '../../redux/reducer/Auth';
const Frame = (props, rootProps) => {

  const SCREEN_HEIGHT = Dimensions.get('screen').height;
  const SCREEN_WIDTH = Dimensions.get('screen').width;
  // Local states
  let userData;
  const [isRefresh, setIsRefresh] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { loginCredentials, storeAutofilInfo, verificationStatus, verificationSteps } = rootProps;
  const dispatch = useDispatch();
  // userData = useSelector(state => initialState.data);

  useEffect(() => {
    //  props.getRedeemedCoupons();
    props.getUser();
  }, [])

  

  function mapStateToProps(state) {
  }
  //  const phoneformate = {props?.getUserdetail?.phone};
  var number = '';
  if (props?.getUserdetail?.phone != "" && props?.getUserdetail?.phone != undefined) {
    const match = (props?.getUserdetail?.phone).match(/(\d{3})(\d{3})(\d{4})$/);


    number = ['(', match[1], ') ', match[2], '-', match[3]].join('');

  }



  useEffect(() => {

    setTimeout(() => {
      setIsLoading(false)
      setIsRefresh(false)
    }, 500);
  }, [props?.vendorList])

  const renderItem = ({ item, index }) => {
    return (
      <TouchableOpacity
        onPress={() => props.navigation.navigate("SingleCouponInsight", { couponDetail: item })}
        style={styles.listItem}>
        <View style={{ width: '100%' }}>
          <View style={styles.titleContainer}>
            <Text style={styles.titleText}>{item?.title}</Text>
          </View>
          <View style={[styles.subTitleContainer, { marginTop: 10 }]}>
            <Text style={styles.titleSubText}>{"Times Redeemed"}</Text>
            <Text style={styles.titleSubText}>{item?.NoOfTimesRedeemed}</Text>
          </View>
          <View style={[styles.subTitleContainer, { paddingBottom: 10, marginTop: 5 }]}>
            <Text style={styles.timeLeftText}>{"Time Left"}</Text>
            <Text style={[styles.timeLeftText, { color: item?.daysLeft >= 0 ? Colors.DARK_GREY : Colors.RED }]}>{item?.daysLeft >= 0 ? item?.daysLeft + " Days" : "Expired"}</Text>
          </View>
        </View>
      </TouchableOpacity>
    )
  }
  
  return (

    <ScrollView style={styles.root}>

      <View style={styles.header}>
      </View>
      <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />

      <View>
        <View style={{ marginHorizontal: "5%", marginTop: "5%" }}>
          <Text style={{ fontSize: 18, color: "black", fontWeight: "bold" }}>Which business Services are you interested in ?</Text>
        </View>
        <TouchableOpacity
          style={{ marginVertical: "5%", marginTop: "10%" }}>
          <RoundedButton onPress={() => props.navigation.navigate('Merchant')} text='Insurance Services' />
        </TouchableOpacity>
        <TouchableOpacity
          style={{ marginVertical: "5%" }}>
          <RoundedButton onPress={() => props.navigation.navigate('Frameinsurence')} text='Merchant Services' />
        </TouchableOpacity>
        <TouchableOpacity
          style={{ marginVertical: "5%" }}>
          <RoundedButton onPress={() => props.navigation.navigate('Webmobile')} text='Web & Mobile App Development' />
        </TouchableOpacity>

        <TouchableOpacity
          style={{ marginVertical: "5%" }}>
          <RoundedButton onPress={() => props.navigation.navigate('Tax')} text='Tax and Accounting Services' />
        </TouchableOpacity>

        <TouchableOpacity
          style={{ marginVertical: "5%" }}>
          <RoundedButton onPress={() => props.navigation.navigate('Financial')} text='Financial Services' />
        </TouchableOpacity>






      </View>
    </ScrollView>
  )
}

export default Frame;

