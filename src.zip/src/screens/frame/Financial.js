import React, { useEffect, useState,useRef } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, ScrollView,Alert,Dimensions, Image ,ImageBackground,TextInput,Keyboard} from 'react-native';
import { Fonts, Colors, ImageIcons ,CommonStrings} from '../../common';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import InputField from '../../components/forms/inputField';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import { BarChart } from "react-native-chart-kit";
import styles from './styles';
import InsightFilterModal from '../../components/modals/InsightFilterModal';
import moment from 'moment';
import Loader from '../../components/modals/Loader';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import { WebView } from 'react-native-webview';
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

const Financial = (props) => {
    var amount = props.initiateReqData.amount;
    var transactionId = props.initiateReqData._id;
    // var amount = props?.route?.params && props?.route?.params?.amount ? props?.route?.params?.amount : 1;
    
    function onMessage(data) {
        alert(data.nativeEvent.data);
    }

    function sendDataToWebView() {
        webviewRef.current.postMessage('Data from React Native App');
    }

    const webviewRef = useRef();
    
    const {
        navigation,    
    } = props;
    const jsCode = `document.getElementById("myForm").submit()`;
    return (        
        <WebView javaScriptEnabledAndroid={true} injectedJavaScript={jsCode} ref={webviewRef} onMessage={onMessage} source={{ html: `<!DOCTYPE html><html lang="en" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">       
        <head>
            <title></title><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><meta content="width=device-width, initial-scale=1.0" name="viewport" />            
        </head>        
        <body style="background-color: #FFF; margin: auto; text-align: center; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;">
            <form action="https://www.coinpayments.net/index.php" id="myForm" method="post">
                <input type="hidden" name="cmd" value="_pay">
                <input type="hidden" name="reset" value="1">
                <input type="hidden" name="merchant" value="361b307c0b315e847212d532c73a3876">
                <input type="hidden" name="item_name" value="DailySavingsDeposit">
                <input type="hidden" name="item_number" value="${transactionId}">
                <input type="hidden" name="invoice" value="${transactionId}">
                <input type="hidden" name="currency" value="USD">
                <input type="hidden" name="amountf" value="${amount}">
                <input type="hidden" name="quantity" value="1">
                <input type="hidden" name="allow_quantity" value="0">
                <input type="hidden" name="want_shipping" value="1">
                <input type="hidden" name="ipn_url" value="http://54.235.232.249:6565/v1/users/getTransactionDetail">
                <input type="hidden" name="allow_extra" value="0">
                <input type="hidden" name="first_name" value="${props.loginCredentials.userName ? props.loginCredentials.userName :''}">
                <input type="hidden" name="last_name" value="">
                <input type="hidden" name="email" value="${props.loginCredentials.email}">
                <input type="hidden" name="address1" value="">
                <input type="hidden" name="address2" value="">
                <input type="hidden" name="city" value="">
                <input type="hidden" name="state" value="">
                <input type="hidden" name="zip" value="">
                <input type="hidden" name="country" value="">
                <input type="image" src="https://www.coinpayments.net/images/pub/buynow-grey.png" alt="Buy Now with CoinPayments.net">
            </form>
            
        </body>
        
        </html>` }} style={{ flex: 1, width:screenWidth, height:400 }}  />          
        
    )
}

export default Financial;
