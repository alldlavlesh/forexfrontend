import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView, KeyboardAvoidingView } from 'react-native';
import { Fonts, Colors, ImageIcons, Api } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import { useDispatch, useSelector } from 'react-redux';
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';
import branch from 'react-native-branch';

const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const Profile = (props, rootProps) => {

  let userData;
  const [profileImgPath, setprofileImgPath] = useState("");
  const [isRefresh, setIsRefresh] = useState(false);
  const [number, setNumber] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { loginCredentials, storeAutofilInfo, verificationStatus, verificationSteps } = rootProps;
  const dispatch = useDispatch();
  userData = useSelector(state => state);

  const openLink = () => {
    let url = props?.dashboarddata?.whatapplink.toString();
    Linking.openURL(url)
  }

  const openMailLink = () => {
    Linking.openURL('mailto:support@dailysavings.ai');
  }


  const shareLink = async (item) => {
    let messageCaption = "Daily Savings";
    let sharedByUser = "Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link ";
    let linkShare = "refer.dailysavings.ai?user=" + props?.loginCredentials?.user?.id;

    let branchUniversalObject = await branch.createBranchUniversalObject('canonicalIdentifier', {
      locallyIndex: true,
      title: 'Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link',
      ogUrl: linkShare,
      ogImageWidth: '100',
      ogImageHeight: '80',
      contentImageUrl: 'http://dubai.dailysavings.ai/static/media/ICON.d02fc6ca.jpg',
      canonicalUrl: 'http://dubai.dailysavings.ai/static/media/ICON.d02fc6ca.jpg',
      contentDescription: 'Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link',
      contentMetadata: {
        ratingAverage: 5,
        customMetadata: {
          ogUrl: linkShare,
          ogImageWidth: '100',
          ogImageHeight: '80',
          itemType: 'referral',
          itemId: props?.loginCredentials?.user?.id,
          contentImageUrl: 'http://dubai.dailysavings.ai/static/media/ICON.d02fc6ca.jpg',
          itemDetails: "Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link"
        }
      }
    })

    let controlParams1 = {
      desktopUrl: linkShare,
      iosDeepview: linkShare,
      custom: "Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link"
    }

    let linkProperties = { feature: 'share', channel: 'social' }
    let { url } = await branchUniversalObject.generateShortUrl(linkProperties, controlParams1)

    let shareOptions = { messageHeader: sharedByUser, messageBody: messageCaption }

    let controlParams = { $ios_url: url }
    let { channel, completed, error } = await branchUniversalObject.showShareSheet(shareOptions, linkProperties, controlParams)
    
  }

  useEffect(() => {
    let request = {
      "user_id": props?.loginCredentials?._id
    }
    props.getUser(request);
  }, [])

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" && "padding"}
      style={tw`flex-1 justify-center`}>
      <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} profile={true} name={'Profile'} />

          
      <ScrollView style={tw``}>
        <View style={tw`flex justify-center w-12/12 items-center  `}>
          <View style={tw` w-11/12  flex-row flex  items-center mt-2 `} >
            {
              (props?.getUserdetail?.profileImage || profileImgPath) ?
                <Image source={profileImgPath ? { uri: profileImgPath } : { uri: Api.fileUrl + props?.getUserdetail?.profileImage }} style={tw`w-25 h-25 rounded-full border-2 border-white`}></Image>
                :
                <Image source={ImageIcons.Fprofile} style={tw`w-25 h-25  rounded-full border-2 border-white bg-[#908FEC]`}></Image>

            }
            <View style={tw`p-3 `}>
              <Text style={tw`text-5 text-[#000] font-bold`}>
                {props?.getUserdetail?.userName}
              </Text>
              <Text style={tw`text-4 text-[#707070]   `}>
                {props?.getUserdetail?.email}
              </Text>
            </View>

          </View>
          <View style={tw` bg-[#F3FBED] rounded-[6]  w-11/12  mt-5  `}>
            <TouchableOpacity onPress={() => props?.navigation?.navigate("Refferal")}>
              <View style={tw` bg-[#F3FBED] rounded-[6] h-15   flex-row flex  items-center justify-evenly  `}>

                <Image source={ImageIcons.Gift} style={tw`h-9 w-9 `} />
                <View style={tw`  items-start `}>
                  <Text style={tw`text-black font-bold text-4 `}>Referral Code</Text>
                  <Text style={tw`text-black text-3  text-[#707070] `}> Share with your friend and get $20 </Text>
                </View>
              </View>

            </TouchableOpacity>
          </View>
          <View style={tw`w-11/12  mt-5`}>
            <TouchableOpacity onPress={() => props?.navigation?.navigate("Introduction")}>
              <View style={tw`flex-row flex      items-center`}>
                <View style={tw`    w-2/12  items-start`} >
                  <Image source={ImageIcons.about_Icon} resizeMode='contain' style={tw`h-8 w-8`} />
                </View>
                <View style={tw`items-center w-10/12 justify-between flex-row`} >
                  <Text style={tw`text-lg font-bold text-[#03314B]`}>About us</Text>
                  <Image source={ImageIcons.next_icon} resizeMode='contain' style={tw`h-4 w-4`} />
                </View>
              </View>
            </TouchableOpacity>



            <TouchableOpacity>
              <View style={tw`flex-row flex    mt-5  items-center`}>
                <View style={tw`    w-2/12  items-start`} >
                  <Image source={ImageIcons.language} resizeMode='contain' style={tw`h-8 w-8`} />
                </View>
                <View style={tw`     items-center w-10/12 justify-between flex-row`} >
                  <Text style={tw`text-lg font-bold text-[#03314B]`}>Language</Text>
                  <Text style={tw`text-base text-[#707070] font-bold ml-19`}>English</Text>
                  <Image source={ImageIcons.next_icon} resizeMode='contain' style={tw`h-4 w-4`} />
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => props?.navigation?.navigate("Setting")}>
              <View style={tw`flex-row flex    mt-5  items-center`}>
                <View style={tw`  w-2/12  items-start`} >
                  <Image source={ImageIcons.settings} resizeMode='contain' style={tw`h-8 w-8`} />
                </View>
                <View style={tw`   items-center w-10/12 justify-between flex-row`} >
                  <Text style={tw`text-lg font-bold text-[#03314B]`}>Settings</Text>
                  <Image source={ImageIcons.next_icon} resizeMode='contain' style={tw`h-4 w-4`} />
                </View>
              </View>
            </TouchableOpacity>


            <TouchableOpacity onPress={() => props?.navigation?.navigate("FAQ")}>
              <View style={tw`flex-row flex   mt-5  items-center`}>
                <View style={tw` w-2/12  items-start`} >
                  <Image source={ImageIcons.faq1} resizeMode='contain' style={tw`h-8 w-8`} />
                </View>
                <View style={tw`items-center w-10/12 justify-between flex-row`} >
                  <Text style={tw`text-lg font-bold text-[#03314B]`}>FAQ</Text>
                  <Image source={ImageIcons.next_icon} resizeMode='contain' style={tw`h-4 w-4`} />
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => props.logout() }>
              <View style={tw`flex-row flex   mt-5  items-center`}>
                <View style={tw` w-2/12  items-start`} >
                  <Image source={ImageIcons.logoutIcon} resizeMode='contain' style={[tw`h-7 w-7`,{tintColor: "#F61C7A"}]} />
                </View>
                <View style={tw`items-center w-10/12 justify-between flex-row`} >
                  <Text style={tw`text-lg font-bold text-[#03314B]`}>Logout</Text>
                  <Image source={ImageIcons.next_icon} resizeMode='contain' style={tw`h-4 w-4`} />
                </View>
              </View>
            </TouchableOpacity>

          </View>
          <View style={tw`w-11/12 mt-5`}>
            <TouchableOpacity>
              <View style={tw`flex  items-center    shadow-[#7D64FF] bg-[#171717]   shadow-2xl p-2  rounded-[6] flex-row `}>
                <View style={tw`    w-2/12  items-start`}>
                  <Image source={ImageIcons.feedback} resizeMode='contain' style={tw`h-12 w-12 `} />
                </View>
                <View style={tw` items-center w-8/12 `} >
                  <Text style={tw`text-[#ffff] text-base  text-xs `}>We'd love to hear your feedback on threads,if you have any?</Text>
                </View>
                <View style={tw`   w-2/12  items-end`}>
                  <Image source={ImageIcons.Chevron_Right} resizeMode='contain' style={tw`h-8 w-8`} />
                </View>
              </View>
            </TouchableOpacity>
          </View>
          {/* bg-[#171717] */}
        </View>

        <View style={tw`mt-7`}>
          <Loader isVisible={props?.couponsListLoader} />
        </View>

      </ScrollView>


      <CustomBottomTab {...props} isActive={true} selected={"Profile"} />

    </KeyboardAvoidingView>
  )
}

export default Profile;