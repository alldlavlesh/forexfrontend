import React, { useEffect, useState, useRef } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, ScrollView, Alert, Image, ImageBackground, TextInput, Keyboard, KeyboardAvoidingView } from 'react-native';
import { Fonts, Colors, ImageIcons, CommonStrings, Api } from '../../common';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import LinearGradient from 'react-native-linear-gradient';
import InputField from '../../components/forms/inputField';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import { BarChart } from "react-native-chart-kit";
import styles from './styles';

import InsightFilterModal from '../../components/modals/InsightFilterModal';
import moment from 'moment';
import tw from 'twrnc';
import select from '../../common/select.png'
import Loader from '../../components/modals/Loader';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import ImagePicker from 'react-native-image-crop-picker';
import { websiterRegx } from '../../services/helper';
//import TextInput from '../../component/forms/TextInput';
const DailyLabels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
// const HourlyLabels = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"];
const HourlyLabels = ["12 am", "01 am", "02 am", "03 am", "04 am", "05 am", "06 am", "07 am", "08 am", "09 am", "10 am", "11 am", "12 pm", "01 pm", "02 pm", "03 pm", "04 pm", "05 pm", "06 pm", "07 pm", "08 pm", "09 pm", "10 pm", "11 pm"];

const Editprofile = (props) => {
    // Local states
    const {
        navigation,
        route,
        errors,
        values,
        handleChange,
        handleSubmit,
    } = props;
    //const { user } = route?.params;
    //const [username, setusername] = useState(user.userName);

    //Reference
    const titleRef = useRef();
    const phonenoRef = useRef();
    const phonenoBusinessRef = useRef();
    const webRef = useRef();

    const userRef = useRef();
    const businRef = useRef();
    const [username, onChangeText3] = React.useState("");
    // const [name, onChangeText4] = React.useState("");
    const [website, onChangewebsite] = React.useState("");
    const [businessemail, onChangeText5] = React.useState("");
    // const [email, onChangeText1] = React.useState("");
    // const [password, onChangeText2] = React.useState("");
    const [coupon, setCoupon] = useState();
    const [openFilterModal, setOpenFilterModal] = useState(false);
    const [filterType, setFilterType] = useState("Hourly"); //Hourly , Daily
    const [hourlyValues, setHourlyValues] = useState([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
    const [dailyValues, setDailyValues] = useState([0, 0, 0, 0, 0, 0, 0]);
    const [graphData, setGraphData] = useState({
        labels: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        datasets: [
            {
                data: [0, 0, 0, 0, 0, 0, 0],
            }
        ]
    });
    const [profileImgPath, setprofileImgPath] = useState("");
    const [backprofilePath, setbackprofilePath] = useState("");
    const [fromGallery, setFromGallery] = useState(false);
    const [retakeFlag, setRetakeFlag] = useState(false);
    const [isShowPassword, setIsShowPassword] = useState(true);

    const emailInputRef = useRef();
    const passwordInputRef = useRef();
    const [name, setName] = useState(props?.getUserdetail?.name);
    const [isValidEmail, setIsValidEmail] = useState(false);
    const [validPass, setValidPass] = useState(false);
    const [phoneNumber, setPhoneNumber] = useState(props?.getUserdetail?.mobile_number);
    const [validPhoneNumber, setvalidPhoneNumber] = useState(true);
    const [email, setEmail] = useState(props?.getUserdetail?.email)
    const [password, setPassword] = useState(props?.getUserdetail?.password)
    const [countryCode, setCountryCode] = useState();


    const handleEmailChange = (text) => {

        setEmail(text)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        setIsValidEmail(emailRegex.test(text));
    }

    const handleNameChange = (text) => {
        setName(text)
    }

    const handlePassswordChange = (value) => {
        // setPassword(value)

        // const passRegex = "^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$"
        // setValidPass(passRegex.test(value));
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        setPassword(value)
        // alert('Password must be at least 8 characters long and contain at least one letter and one number.');
        setValidPass(passwordRegex.test(value));
    }
    const handlemobilechange = (value) => {
        setPhoneNumber(value);
        const phoneRegex = /^[0-9]{9,10}$/;
        const isValid = phoneRegex.test(value);
        setvalidPhoneNumber(isValid);
    
        if (!isValid) {
            setAlertMessage('Please enter a valid phone number.');
        } else {
            setAlertMessage('');
        }
    }

    useEffect(() => {
        //props.getUser();
    }, [])

    function mapStateToProps(state) {
    }
   
    const getCouponTrackingData = (couponId) => {
        props.getRedeemedTrackingData(couponId);
    }


    const handleRegistrationSubmit = () => {
        const formData = new FormData();
        // if (!errors.name) {
        formData.append("name", name);
        //}
        // if (!errors.countryCode) {
        formData.append("email", email);
        // }
        // if (!errors.phoneno) {
         formData.append("mobile_number", phoneNumber);
        
        // }

        if (profileImgPath != '') {
            let fileNamePro = profileImgPath.split('/').pop();
            let mimeTypePro = profileImgPath.split('.').pop();
            let filePro = {
                'uri': profileImgPath,
                'type': `image/${mimeTypePro}`,
                'name': fileNamePro
            }
            formData.append('profileimage', filePro);
        }

        props.updateProfile(formData, navigation)
        setTimeout(() => {
            let request = {
                "user_id": props?.loginCredentials?.user?.id
            }
            props.getUser(request);
        }, 100);

    }


    const selectPhoto = async () => {
        ImagePicker.openPicker({
            width: 720,
            mediaType: 'photo',
            compressImageQuality: 0.5,
            height: 906,
            cropping: true
        }).then(image => {
            if (image?.path) {
                setFromGallery(true);
                setRetakeFlag(!retakeFlag);
                setprofileImgPath(image.path || res?.uri);
            }
        }).catch((error) => {
        });
    }

    const choosePhoto = async () => {
        ImagePicker.openPicker({
            width: 720,
            mediaType: 'photo',
            compressImageQuality: 0.5,
            height: 906,
            cropping: true
        }).then(image => {
            if (image?.path) {
                setFromGallery(true);
                // setRetakeFlag(!retakeFlag);
                // setbackprofilePath(image.path || res?.uri);
            }
        }).catch((error) => {
        });
    }

    const handleCountryCodeChange = (value) => {
        setCountryCode(value)
    }

    // filter graph data by (Daily/Hourly)
    const prepareGraphData = (filterBy) => {
        if (filterBy === "Hourly") {
            let data = {
                labels: HourlyLabels,
                datasets: [
                    {
                        data: hourlyValues,
                    }
                ]
            };
            setGraphData(data);
            setOpenFilterModal(false)
        } else {
            let data = {
                labels: DailyLabels,
                datasets: [
                    {
                        data: dailyValues,
                    }
                ]
            };
            setGraphData(data);
            setOpenFilterModal(false)
        }
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={{ flex: 1, justifyContent: 'center' }}
        >
            <ScrollView style={tw`flex-1 bg-[#ffffff] max-h-full`}>
                <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} editprofile={true} name={'Edit Profile'} />
                <View>
                    <View style={tw`self-center mt-4`}>
                        {
                            (props?.getUserdetail.profileimage || profileImgPath) ?
                                <Image source={profileImgPath ? { uri: profileImgPath } : { uri: Api.fileUrl + props?.getUserdetail?.profileimage }} style={tw`w-40 h-40 rounded-full border-2 border-white`}></Image>
                                :
                                <Image source={ImageIcons.Fprofile} style={tw`w-40 h-40  bg-[#908FEC] rounded-full border-2 border-white`}></Image>
                        }

                        <TouchableOpacity style={tw`h-12 w-12 bg-gray-400 rounded-full  absolute border-white ml-30 mt-24`} onPress={() => selectPhoto()}>
                            <Image source={ImageIcons.image_icon} style={tw`h-12 w-12`} />
                        </TouchableOpacity>
                    </View>

                    <View style={tw` justify-between bg-[#fff] rounded-t-[9] shadow-2xl shadow-[#7D64FF] mt-5 `}>
                        <View style={tw`relative`}>
                            <TextInput
                                style={tw`mx-10  bg-[#ffffff] text-black rounded-4 border border-[#908FEC]  h-13 mt-10 p-4`}
                                value={name}
                                type='text'
                                placeholder={'Name'}
                                placeholderTextColor={'black'}
                                // onChangeText={handleChange('name')}
                                onChangeText={handleNameChange}
                                // keyboardType="email-address"
                                reference={titleRef}
                                selectionColor="black"
                            />
                            <View style={tw`absolute top-7 left-15 bg-[#ffff]`}>
                                <Text style={tw`text-sm font-bold  text-[#F61C7A] pl-1 w-18`}>Full name</Text>
                            </View>
                        </View>


                        <View style={tw`relative`}>
                            <TextInput
                                style={tw`mx-10  bg-[#ffffff] text-black rounded-4 border border-[#908FEC] h-13 mt-5 p-4`}
                                value={email}
                                type='text'
                                editable={false} // Disable user interactions
                                placeholder={'Email'}
                                placeholderTextColor={'black'}
                                onChangeText={handleEmailChange}
                                keyboardType="email-address"
                                reference={emailInputRef}
                                selectionColor="black"
                                onSubmitEditing={() => passwordInputRef?.current?.focus()}
                            />
                            <View style={tw`absolute top-2 left-15 bg-[#ffff] pl-1 w-24.5`}>
                                <Text style={tw`text-sm font-bold  text-[#F61C7A]`}>Email address</Text>
                            </View>
                        </View>

                        {/* <View style={tw`relative`}>
                            <TextInput
                                style={tw`mx-10  bg-[#ffffff] text-black rounded-4 border border-[#908FEC] h-13 mt-5 p-4`}
                                value={password}
                                type='text'
                                placeholder={'Password'}
                                placeholderTextColor={'black'}
                                // onChangeText={handleChange('name')}
                                onChangeText={handlePassswordChange}
                                // keyboardType="email-address"
                                reference={titleRef}
                                selectionColor="black"
                            />
                            <View style={tw`absolute top-2 left-15 bg-[#ffff] pl-1 w-18`}>
                                <Text style={tw`text-sm font-bold  text-[#F61C7A]`}>Password</Text>
                            </View>
                        </View> */}


                        <View style={tw`relative`}>
                            <PhoneMaskInput
                                style={tw`  bg-[#ffffff]  text-black rounded-4  h-17 mt-5 	`}
                                id="countryCode"
                                defaultValue={phoneNumber}
                                placeholder=" Enter Phone no."
                                defaultCode={(countryCode != undefined) ? countryCode : 'IN'}
                                // onCountryCodeChange={handleCountryCodeChange}
                                layout="first"
                                // onCountryChange={handleChange('countryCode')}
                                // onCountryCodeChange={handleChange('countryCode')}
                                onChangePhone={(value) => handlemobilechange(value)}
                                theme="white"
                                reference={phonenoRef}
                                returnKeyType='done'
                            />
                            <View style={tw`absolute top-2.5 left-15 bg-[#ffff] pl-1 w-26`}>
                                <Text style={tw`text-sm font-bold  text-[#F61C7A]`}>Phone number</Text>
                            </View>
                        </View>

                        <TouchableOpacity style={tw`justify-center items-center`} onPress={() => { handleRegistrationSubmit() }}>
                            <LinearGradient colors={['#E0F64B', '#E0F64B']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-15 w-70 my-10   items-center  justify-center rounded-[9] p-1 `}
                            >
                                <View style={tw`flex-row `}>
                                    <Text style={tw`text-black text-[4.5] font-bold  `}>Save</Text>
                                </View>

                            </LinearGradient>
                        </TouchableOpacity>

                    </View>

                </View>
                <Loader isVisible={props?.editprofileloader} />
            </ScrollView>
        </KeyboardAvoidingView>
    )
}

const formikEnhancer = withFormik({

});


export default formikEnhancer(Editprofile);
