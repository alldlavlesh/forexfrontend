import React, { useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView, KeyboardAvoidingView } from 'react-native';

import CustomHeaderTab from '../../components/CustomHeaderTab';
import tw from 'twrnc';
import { WebView } from 'react-native-webview';

const Introduction = (props) => {
    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            >
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'About US'} />
                 <ScrollView style={{ backgroundColor:'#ffffff', padding:30, height:'100%'}}>
                   <Text style={{ lineHeight:30}}>
                      Forex Application is for the trading, investment and other platforms. Forex Application is for the trading, investment and other platforms.Forex Application is for the trading, investment and other platforms.Forex Application is for the trading, investment and other platforms.Forex Application is for the trading, investment and other platforms.
                      Forex Application is for the trading, investment and other platforms. Forex Application is for the trading, investment and other platforms.Forex Application is for the trading, investment and other platforms.Forex Application is for the trading, investment and other platforms.Forex Application is for the trading, investment and other platforms.

                   </Text>
                 </ScrollView>                         
        </KeyboardAvoidingView>
    )
}

export default Introduction;