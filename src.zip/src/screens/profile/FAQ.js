import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, TextInput, ImageBackground, TouchableOpacity, Image, ScrollView, KeyboardAvoidingView } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import vector from '../../common/Vector.png'
import bellicon from '../../common/Vector1.png'
import seticon from '../../common/Vector2.png'
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';


const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const FAQ = (props) => {

    const [show, setShow] = useState(false);
    const [show1, setShow1] = useState(false);
    const [show2, setShow2] = useState(false);
    const [show3, setShow3] = useState(false);
    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>


            <ScrollView style={tw`bg-white`}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'FAQ'} />
                <View style={tw``}>
                    <View style={tw` items-center mt-5`}>
                        <Text style={tw`text-2xl font-bold`}>How we can help you?</Text>
                    </View>

                </View>
               {/* <View style={tw`flex flex-row items-center bg-[#F5F5F5] rounded-[2] px-4 mx-4 mt-6`}>
                    <Image
                        source={vector}
                        style={tw`h-6 w-6  `}

                    >
                    </Image>
                    <TextInput
                        placeholder="Enter your keyword"
                        style={tw`flex-1 bg-gray ml-5 text-black`}
                        placeholderTextColor={'gray'}
                    />


                </View>*/}
                <View style={tw`mt-5 flex-row justify-evenly`}>
                    <View style={tw`bg-[#DFF1FF] p-5 rounded-[2] `}>
                        <Image
                            source={bellicon}
                            style={tw`h-6 w-6  `}

                        >
                        </Image>
                        <Text style={tw`mt-5 text-sm text-[#616161]`}>Question about</Text>
                        <Text style={tw`mt-1 font-bold text-sm`}>Getting Started</Text>
                    </View>
                    <View style={tw`bg-[#E8FFEB] p-5 rounded-[2] `}>
                        <Image
                            source={seticon}
                            style={tw`h-6 w-6  `}

                        >
                        </Image>
                        <Text style={tw`mt-5 text-sm text-[#616161]`}>Question about</Text>
                        <Text style={tw`mt-1 font-bold text-sm`}>How to invest</Text>
                    </View>
                </View>
                <View>
                    <Text style={tw`text-base font-bold mx-4 mt-5`}>Top Questions</Text>
                </View>
                <View style={tw`border-solid border-2 border-gray-300 mx-3 p-4 rounded-[2] mt-5`}>
                    <View style={tw`flex-row items-center justify-between`}>
                        <Text style={tw`text-sm font-bold`}>What is the different between Moderate and Aggressive plan?</Text>
                        <TouchableOpacity onPress={() => setShow(s => !s)}>

                            {show == true ?
                                <View style={tw`h-7 justify-center`}>
                                    <Image source={ImageIcons.editcolor} style={tw`w-3 h-0.7`} />
                                </View>
                                :

                                <Text style={tw`text-[#DF1525] text-2xl`}>+</Text>
                            }

                        </TouchableOpacity>

                    </View>
                    {show == true &&
                        <View>
                            <Text style={tw`text-sm mt-3 text-[#757575]`}>
                                Moderate mode has 0% risk with guaranteed returns of 5-15% per month. Aggressive mode is 100% risky as the financial experts invest money in different financial segments that fluctuated as per the market. here, returns are 20-30% per month.
                            </Text>
                        </View>
                    }
                </View>
                <View style={tw`border-solid border-2 border-gray-300 mx-3 p-4 rounded-[2] mt-5 `}>
                    <View style={tw`flex-row items-center justify-between`}>
                        <Text style={tw`text-sm font-bold w-9/12 tracking-wide`}>How can I withdraw principal amount and total earnings?</Text>
                        <TouchableOpacity onPress={() => setShow1(s => !s)}>
                            {show1 == true ?
                                <View style={tw`h-7 justify-center`}>
                                    <Image source={ImageIcons.editcolor} style={tw`w-3 h-0.7`} />
                                </View>
                                :

                                <Text style={tw`text-[#DF1525] text-2xl`}>+</Text>
                            }
                        </TouchableOpacity>
                    </View>
                    {show1 == true &&
                        <View>
                            <Text style={tw`text-sm mt-3 text-[#757575]`}>
                                For capital withdrawal- Add bank account details under "Setting" first, then click on "Investments option", then click on "Withdraw deposit" button. Your funds will be credited in your account within 24 hours. For interest earned withdrawal- click on " Withdraw now" option on investments page. Enter amount and add UPI id and click on arrow option. Your profit will be credited in account within 48 hours.
                            </Text>
                        </View>
                    }
                </View>
                <View style={tw`border-solid border-2 border-gray-300 mx-3 p-4 rounded-[2] mt-5 `}>
                    <View style={tw`flex-row items-center justify-between`}>
                        <Text style={tw`text-sm font-bold w-9/12 tracking-wide`}>I have deposited funds in costa savings account via Easy2pay but it not showing in?</Text>
                        <TouchableOpacity onPress={() => setShow2(s => !s)}>
                            {show2 == true ?
                                <View style={tw`h-7 justify-center`}>
                                    <Image source={ImageIcons.editcolor} style={tw`w-3 h-0.7`} />
                                </View> :

                                <Text style={tw`text-[#DF1525] text-2xl`}>+</Text>
                            }
                        </TouchableOpacity>
                    </View>
                    {show2 == true &&
                        <View>
                            <Text style={tw`text-sm mt-3 text-[#757575]`}>
                            Funds will be reflected in " costa savings" account within 5-15 minutes. if still problem persists, kindly mail us on support@costasavings.com or contact us on this No. 7404740482.
                            </Text>
                        </View>
                    }
                </View>
                {/* <View style={tw`border-solid border-2 border-gray-300 mx-3 p-4 rounded-[2] mt-5 `}>
                    <View style={tw`flex-row items-center justify-between`}>
                        <Text style={tw`text-sm font-bold w-9/12 tracking-wide`}>Is the Stock Market Opens On Weekends?</Text>
                        <TouchableOpacity onPress={() => setShow3(s => !s)}>
                            {show3 == true ?
                                <View style={tw`h-7 justify-center`}>
                                    <Image source={ImageIcons.editcolor} style={tw`w-3 h-0.7`} />
                                </View>
                                :

                                <Text style={tw`text-[#DF1525] text-2xl`}>+</Text>
                            }
                        </TouchableOpacity>
                    </View>
                    {show3 == true &&
                        <View>
                            <Text style={tw`text-sm mt-3 text-[#757575]`}>
                                Open the tradbase app to get Started and follow the step.Tradebase does not charge a fee to create or maintain your tradebase account.
                            </Text>
                        </View>
                    }
                </View> */}



            </ScrollView>



            {/* <CustomBottomTab {...props} isActive={true} selected={"Insights"} /> */}
        </KeyboardAvoidingView>
    )
}

export default FAQ;