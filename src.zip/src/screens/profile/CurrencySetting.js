import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView, Switch } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import ToggleSwitch from 'toggle-switch-react-native'

// import { CurrentSetting } from '../../container';
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';


const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const CurrencySetting = (props) => {

  const [enabled, setEnabled] = useState(false)
  const [enabled1, setEnabled1] = useState(false)
  const [enabled2, setEnabled2] = useState(false)
  const [enabled3, setEnabled3] = useState(false)

  const toggleSwitch = () => {
    setEnabled(!enabled);
    handleChange()
  };
  const toggleSwitch1 = () => {
    setEnabled1(!enabled1);
    handleChange()
  };
  const toggleSwitch2 = () => {
    setEnabled2(!enabled2);
    handleChange()
  };
  const toggleSwitch3 = () => {
    setEnabled3(!enabled3);
    handleChange()
  };

  const handleChange = () => {
    let request = {
      "enabled": 'USDT',
      "enabled1": 'INDT',
      "enabled2": 'AEDT',
      "enabled13": 'GBPT',
      
  }
  props?.setCurrency(request)
  }
  const trackColorOn = Platform.OS === "android" ? "#E33A61" : "#696969"
  const trackColorOff = Platform.OS === "android" ? "#696969" : "#696969"
  const thumbColorOn = Platform.OS === "android" ? "#ffffff" : "#32CD32"
  const thumbColorOff = Platform.OS === "android" ? "#696969" : "#808080"

  return (
    <View style={tw`flex-1 bg-white`}>

      <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
      <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Currency Setting'} />
      <ScrollView>


        <View style={tw`flex-1 mb-20`}>
          <View style={tw` w-12/12 justify-center p-4`}>
            <View style={tw`shadow-[#7D64FF]`}>
              <View style={tw`h-17 w-12/12 bg-white items-center  justify-center shadow-xl  shadow-[#7D64FF] rounded-[4]  flex-row`}>
                <View style={tw`flex-row w-9/12 items-center  `}>
                  <Image source={ImageIcons.Medium3} style={tw`h-12 w-12`} />
                  <Text style={tw`p-4`}>Add logo USDT</Text>
                </View>
                {/* <Switch
                  onValueChange={toggleSwitch}
                  thumbColor={enabled ? thumbColorOn : thumbColorOff}
                  value={enabled}
                  trackColor={{ false: trackColorOff, true: trackColorOn }}
                /> */}
                <TouchableOpacity onPress={toggleSwitch}>
                  <LinearGradient
                    colors={enabled ? ['#C10932', '#FD5578']: ['#939296', '#7B7A80']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    style={tw`h-7.5 w-12.5 rounded-[4]`}
                  >
                    <View style={[tw`rounded-full w-5 h-5 absolute mt-1.3 `, { backgroundColor: enabled ? '#ffffff' : '#F5F5F5', left: enabled ? 25 : 5 }]} />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
            <View style={tw`shadow-[#7D64FF]`}>
              <View style={tw`h-17 w-12/12 bg-white items-center  justify-center shadow-xl shadow-[#7D64FF] rounded-[4]  flex-row`}>
                <View style={tw`flex-row w-9/12 items-center  `}>
                  <Image source={ImageIcons.Medium3} style={tw`h-12 w-12`} />
                  <Text style={tw`p-4`}>INDT or comming soon(Grey)</Text>
                </View>
                {/* <Switch
                    onValueChange={toggleSwitch1}
                    thumbColor={enabled1 ? thumbColorOn : thumbColorOff}
                    value={enabled1}
                    trackColor={{ false: trackColorOff, true: trackColorOn }}
                  /> */}
                <TouchableOpacity onPress={toggleSwitch1}>
                  <LinearGradient
                    colors={enabled1 ? ['#C10932', '#FD5578'] : ['#939296', '#7B7A80']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    style={tw`h-7.5 w-12.5 rounded-[4]`}
                  >
                    <View style={[tw`rounded-full w-5 h-5 absolute mt-1.3`, { backgroundColor: enabled1 ? '#ffffff' : '#F5F5F5', left: enabled1 ? 25 : 5 }]} />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
            <View style={tw`shadow-[#7D64FF]`}>
              <View style={tw`h-17 w-12/12 bg-white items-center  justify-center shadow-xl shadow-[#7D64FF] rounded-[4]  flex-row`}>
                <View style={tw`flex-row w-9/12 items-center `}>
                  <Image source={ImageIcons.Medium3} style={tw`h-12 w-12`} />
                  <Text style={tw`p-4`}>AEDT</Text>
                </View>
                {/* <Switch
                  onValueChange={toggleSwitch2}
                  thumbColor={enabled2 ? thumbColorOn : thumbColorOff}
                  value={enabled2}
                  trackColor={{ false: trackColorOff, true: trackColorOn }}
                /> */}
                <TouchableOpacity onPress={toggleSwitch2}>
                  <LinearGradient
                    colors={enabled2 ? ['#C10932', '#FD5578'] : ['#939296', '#7B7A80']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    style={tw`h-7.5 w-12.5 rounded-[4]`}
                  >
                    <View style={[tw`rounded-full w-5 h-5 absolute mt-1.3`, { backgroundColor: enabled2 ? '#ffffff' : '#F5F5F5', left: enabled2 ? 25 : 5 }]} />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
            <View style={tw`shadow-[#7D64FF]`}>
              <View style={tw`h-17 w-12/12 bg-white  items-center  justify-center shadow-2xl shadow-[#7D64FF] rounded-[4]  flex-row`}>
                <View style={tw`flex-row w-9/12 items-center  `}>
                  <Image source={ImageIcons.Medium3} style={tw`h-12 w-12`} />
                  <Text style={tw`p-4`}>GBPT</Text>
                </View>
                {/* <Switch
                  onValueChange={toggleSwitch3}
                  thumbColor={enabled3 ? thumbColorOn : thumbColorOff}
                  value={enabled3}
                  trackColor={{ false: trackColorOff, true: trackColorOn }}
                /> */}
                <TouchableOpacity onPress={toggleSwitch3}>
                  <LinearGradient
                    colors={enabled3 ? ['#C10932', '#FD5578'] : ['#939296', '#7B7A80']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    style={tw`h-7.5 w-12.5 rounded-[4]`}
                  >
                    <View style={[tw`rounded-full w-5 h-5 absolute mt-1.3`, { backgroundColor: enabled3 ? '#ffffff' : '#F5F5F5', left: enabled3 ? 25 : 5 }]} />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>


          </View>

        </View>


        <Loader isVisible={props?.couponsListLoader} />
      </ScrollView>

      {/* <CustomBottomTab {...props} isActive={true} selected={"Profile"} /> */}
    </View>
  )
}

export default CurrencySetting;