import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, Switch, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView } from 'react-native';
import { Fonts, Colors, ImageIcons, Api } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import { useDispatch, useSelector } from 'react-redux';
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';
import branch from 'react-native-branch';

const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const Setting = (props, rootProps) => {
  const [isEnabled, setisEnabled] = React.useState(true);

  let userData;
  const [profileImgPath, setprofileImgPath] = useState("");
  const [isRefresh, setIsRefresh] = useState(false);
  const [number, setNumber] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { loginCredentials, storeAutofilInfo, verificationStatus, verificationSteps } = rootProps;
  const dispatch = useDispatch();
  userData = useSelector(state => state);

  const openLink = () => {
    let url = props?.dashboarddata?.whatapplink.toString();
    Linking.openURL(url)
  }

  const openMailLink = () => {
    Linking.openURL('mailto:support@dailysavings.ai');
  }


  const shareLink = async (item) => {
    let messageCaption = "Daily Savings";
    let sharedByUser = "Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link ";
    let linkShare = "refer.dailysavings.ai?user=" + props?.loginCredentials?.user?.id;

    let branchUniversalObject = await branch.createBranchUniversalObject('canonicalIdentifier', {
      locallyIndex: true,
      title: 'Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link',
      ogUrl: linkShare,
      ogImageWidth: '100',
      ogImageHeight: '80',
      contentImageUrl: 'http://dubai.dailysavings.ai/static/media/ICON.d02fc6ca.jpg',
      canonicalUrl: 'http://dubai.dailysavings.ai/static/media/ICON.d02fc6ca.jpg',
      contentDescription: 'Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link',
      contentMetadata: {
        ratingAverage: 5,
        customMetadata: {
          ogUrl: linkShare,
          ogImageWidth: '100',
          ogImageHeight: '80',
          itemType: 'referral',
          itemId: props?.loginCredentials?.user?.id,
          contentImageUrl: 'http://dubai.dailysavings.ai/static/media/ICON.d02fc6ca.jpg',
          itemDetails: "Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link"
        }
      }
    })

    let controlParams1 = {
      desktopUrl: linkShare,
      iosDeepview: linkShare,
      custom: "Hi there, I found this interesting app that gives daily returns and you can withdraw the amount to your account or any nearby stores. Download Daily Savings App by clicking below link"
    }

    let linkProperties = { feature: 'share', channel: 'social' }
    let { url } = await branchUniversalObject.generateShortUrl(linkProperties, controlParams1)

    let shareOptions = { messageHeader: sharedByUser, messageBody: messageCaption }

    let controlParams = { $ios_url: url }
    let { channel, completed, error } = await branchUniversalObject.showShareSheet(shareOptions, linkProperties, controlParams)
    
  }

  useEffect(() => {
    let request = {
      "user_id": props?.loginCredentials?.user?.id
    }
    props.getUser(request);
  }, [])

  return (
    <View style={tw`flex-1 bg-white`}>
      {/* <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} /> */}
      <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} profile={false} name={'Settings'} />
      <ScrollView >
        <View style={tw`flex-1 w-12/12 justify-center items-center p-4   `}>
          <View style={tw` w-12/12   `}>
            <Text style={tw`text-[#6C727F] text-base font-bold`}>General</Text>
          </View>

          <View style={tw`w-12/12  `}>

            {/* <TouchableOpacity style={tw`flex-row`} onPress={() => props.navigation.navigate("CurrencySetting")}>
                <Image source={ImageIcons.Path} style={tw`h-6 w-6 mt-4 mx-6`} />
                <Text style={tw`text-base mt-4`}>Currency settings</Text>
              </TouchableOpacity> */}
            <TouchableOpacity>
              <View style={tw`flex-row  justify-between mt-5 items-center`}>
                <Text style={tw`text-lg font-bold text-[#03314B]`}>Notification</Text>
                <Image source={ImageIcons.right} resizeMode='contain' style={tw`h-7 w-7`} />
              </View>
            </TouchableOpacity>

            <TouchableOpacity >
              <View style={tw`flex-row  justify-between mt-5 items-center`} >
                <Text style={tw`text-lg   font-bold text-[#03314B]`}>Contact Us</Text>
                <Image source={ImageIcons.right} resizeMode='contain' style={tw`h-7 w-7  `} />
              </View>
            </TouchableOpacity>

            <View style={tw`flex-row  justify-between mt-5 items-center`}>
              <View style={tw`flex-row `}>
                <Text style={tw`text-[#6C727F] text-base font-bold`}>Security</Text>
              </View>
            </View>
            <TouchableOpacity>
              <View style={tw`flex-row  justify-between mt-5 items-center`} >
                <Text style={tw`text-lg   font-bold text-[#03314B]`}>Security Pin</Text>
                {/* <Image source={ImageIcons.next_icon} resizeMode='contain' style={tw`h-5 w-5 ml-45 mt-1`} /> */}
                <View style={tw`h-7 w-7  `}>
                  <Switch
                    value={isEnabled}
                    onValueChange={(value) => setisEnabled(value)}
                    trackColor={{ false: "gray", true: "#F61C7A" }}
                    thumbColor={isEnabled ? "#FCDDEC" : "#FCDDEC"}
                  />
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity >
              <View style={tw`flex-row  justify-between mt-5 items-center`} >
                <Text style={tw`text-lg     font-bold text-[#03314B]`}>Privacy Policy</Text>
                <Image source={ImageIcons.right} resizeMode='contain' style={tw`h-7 w-7 `} />
              </View>
            </TouchableOpacity>
            <View style={tw`flex-row  justify-start mt-5  items-center`}>
             
                <Text style={tw`text-[#6C727F] text-base font-bold`}>Choose what data you share with us</Text>
             
            </View>
            <TouchableOpacity >
              <View  style={tw`flex-row  justify-between mt-5 items-center`} >
                <Text style={tw`text-lg     font-bold text-[#03314B]`}>Legal</Text>
                <Image source={ImageIcons.right} resizeMode='contain' style={tw`h-7 w-7 `} />
              </View>
            </TouchableOpacity>
            <View style={tw`flex items-center justify-center  mt-20 `}>
              <TouchableOpacity>
                <View style={tw` h-13 w-76  bg-[#E0F64B] flex  items-center  justify-center rounded-[2]`}>
                  <Text style={tw`text-[#000000]   text-[4.5]   `}>Appy Changes</Text>
                </View>
              </TouchableOpacity>
              <View style={tw`items-center mt-3 justify-center  `}>
                <Text style={tw`text-[#6C727F]`}>@ 2023 | Forex market by chandigarh</Text>
              </View>
            </View>



          </View>
          {/* <View>
            <View style={tw`flex-row h-20 w-10.5/12 bg-white shadow-[#7D64FF] bg-[#171717]  shadow-2xl   rounded-[6] border-2px mx-6  mt-5`}>

              <Image source={ImageIcons.feedback} resizeMode='contain' style={tw`h-12 w-12 mx-4 my-4 `} />
              <TouchableOpacity style={tw`mx-1    `} onPress={() => props?.navigation?.navigate("Deposite")}>
                <Text style={tw`text-[#ffff] text-base  text-xs  mt-6    `}>We'd love to hear your feedback</Text>
                <Text style={tw`text-[#ffff] text-base  text-xs  `}>on threads, if you have any?</Text>
              </TouchableOpacity>
              <Image source={ImageIcons.Chevron_Right} resizeMode='contain' style={tw`h-8 w-8 ml-4 my-6`} />

            </View>
          </View> */}
        </View>

        <Loader isVisible={props?.couponsListLoader} />
      </ScrollView>

      <CustomBottomTab {...props} isActive={true} selected={"Profile"} />
    </View>
  )
}

export default Setting;