import React, { useState } from 'react';
import { ScrollView, KeyboardAvoidingView } from 'react-native';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import tw from 'twrnc';
import { WebView } from 'react-native-webview';

const TermsConditions = (props) => {
    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Terms & Conditions'} />
                <WebView
                    source={{ uri: 'https://dailysavings.ai/tnc.html' }}
                    style={{ marginTop: 0 }}
                />                          
        </KeyboardAvoidingView>
    )
}

export default TermsConditions;