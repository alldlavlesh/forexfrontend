import React, { useState, useRef } from 'react';
import { Text, View, StatusBar, Alert, Image, Dimensions } from 'react-native';
import { RNCamera } from 'react-native-camera';
import ImagePicker from 'react-native-image-crop-picker';
import { Colors, CommonStrings } from '../../common';
import { LinkButton, RoundedButton } from '../../components/forms/button';
import Loader from '../../components/modals/Loader';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import styles from './styles';
import { checkPermision, openPermissionSettings } from '../../services/permission';
import VerificationHeader from './VerificationHeader';
const { width, height } = Dimensions.get('window');

const VerificationForm4 = (props) => {
    // References
    const cameraRefStore = useRef(null);
    // Local states
    const [storeImgPath, setStoreImgPath] = useState("");
    const [retakeFlag, setRetakeFlag] = useState(false);
    const [fromGallery, setFromGallery] = useState(false);

    // Select/Capture utility bill image
    const takePicture = async () => {
        let cameraPermission = await checkPermision("camera");
        if (cameraPermission) {
            try {
                setStoreImgPath("");
                setFromGallery(false);
                setRetakeFlag(!retakeFlag);
                if (cameraRefStore) {
                    const options = { quality: 0.5, base64: true, width: 720, height: 906 };
                    const data = await cameraRefStore.current.takePictureAsync(options);
                     ImagePicker.openCropper({
                        path: data.uri,
                        width: 720,
                        height: 906
                    }).then(image => {
                        if (image?.path) {
                            setFromGallery(false);
                            setStoreImgPath(image.path || data.uri);
                        }
                    }).catch((error) => {
                        
                        setStoreImgPath(data?.uri);
                    })

                    
                }
            } catch (error) {
                setStoreImgPath("");
                setFromGallery(false);
                setRetakeFlag(false);
                openPermissionSettings();
            }
        } else {
            openPermissionSettings();
        }
    };

    const selectPhoto = async () => {
        ImagePicker.openPicker({
            width: 720,
            mediaType:'photo',
            compressImageQuality: 0.5,
            height: 906,
        }).then(image => {
            
            if (image?.path) {
                setFromGallery(true);
                setRetakeFlag(!retakeFlag);
                setStoreImgPath(image?.path);
            }
        }).catch((error) => {
        });
    }

    // Upload image of Store's facade request submission
    const handleSubmitStoreImage = () => {
        if (!storeImgPath || storeImgPath === "" || storeImgPath === null) {
            Alert.alert(CommonStrings.AppName, "Please select your store image")
        } else {
            let fileName = storeImgPath.split('/').pop();
            let mimeType = storeImgPath.split('.').pop();
            let file = {
                'uri': storeImgPath,
                'type': `image/${mimeType}`,
                'name': fileName
            }
           
            const formData = new FormData();
            formData.append('storeFacade', file);
            props.uploadStoreFacade(formData, props.navigation)
        }
    }

    return (
        <View style={styles.cameraContainer}>
            <StatusBar backgroundColor={"transparent"} barStyle="light-content" translucent={true} />
            <View style={{ flex: 1, marginTop: '18%',height:50 }}>
                    <VerificationHeader  first={'green'} second={'green'} third={'blue'}/>
               </View> 
            {/* <View style={{ position: 'absolute', top: hp('7%'), right: 50, zIndex: 1 }}>
                <Text
                    style={{ color: Colors.BLUE }}
                    onPress={() => {
                        props.navigation?.dispatch(
                            CommonActions.reset({
                                index: 0,
                                routes: [{ name: "CouponsStack" }],
                            })
                        );
                    }}
                >
                    Skip
                </Text>
            </View> */}
            {storeImgPath && retakeFlag ?
                <View style={styles.preview}>
                    <Image source={{ uri: storeImgPath }} style={{
                        width: width, height: height * 0.525,
                        resizeMode: 'contain'
                    }} />
                </View> :
                <RNCamera
                    ref={ref => {
                        cameraRefStore.current = ref;
                    }}
                    style={styles.preview}
                    flashMode={RNCamera.Constants.FlashMode.auto}
                    captureAudio={false}
                    androidCameraPermissionOptions={{
                        title: 'Permission to use camera',
                        message: 'We need your permission to use your camera',
                        buttonPositive: 'Ok',
                        buttonNegative: 'Cancel',
                    }}
                />
            }
            <View style={{ flex: 0.6, backgroundColor: Colors.WHITE }}>
                <View style={styles.subTitle}>
                    <Text style={{ fontSize: 15, textAlign: 'center' }}>Take a photo of your store's facade </Text>
                </View>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <View style={[styles.buttonContainer, { flexDirection: retakeFlag ? 'row' : 'column', alignItems: 'center' }]}>
                        {
                            retakeFlag &&
                            <View style={{ width: '50%', marginRight: -20 }}>
                                <LinkButton
                                    text="Retake Photo"
                                    textStyle={{ color: Colors.BLUE }}
                                    customStyle={{ paddingVertical: 15 }}
                                    onPress={() => setRetakeFlag(!retakeFlag)}
                                />
                            </View>
                        }
                        <View style={{ width: '50%', marginLeft: -15, paddingTop: 19 }}>
                            <RoundedButton
                                text={retakeFlag ? "Confirm" : "Take Photo"}
                                onPress={() => retakeFlag ? handleSubmitStoreImage() : takePicture()}
                            />
                        </View>
                    </View>
                    {
                        !retakeFlag &&
                        <View style={{ width: wp('65%'), marginLeft: -15,paddingTop: 15 }}>
                            <RoundedButton
                                text={"Choose from Gallery"}
                                isOutline={true}
                                onPress={() => selectPhoto()}
                            />
                        </View>
                    }
                </View>
            </View>
            <Loader isVisible={props?.storeImageUploadLoader} />
        </View >
    );
}

export default VerificationForm4;