import React, { useState, useRef, useEffect } from 'react';
import { Fonts, Colors, ImageIcons, CommonStrings } from '../../common';
import tw from 'twrnc'
import Loader from '../../components/modals/Loader';
import { WebView } from 'react-native-webview';
const screenWidth = Dimensions.get('window').width;
// import LinearGradient from 'react-native-linear-gradient';

// import Icon from 'react-native-vector-icons/FontAwesome';
// import all the components we are going to use
import {
    SafeAreaView,
    StyleSheet,
    View,
    Text,
    Image,
    Button,
    FlatList,
    ImageBackground,
    TouchableOpacity,
    StatusBar,
    Dimensions,
    ScrollView,
    Alert
} from 'react-native';

//import AppIntroSlider to use it
import LinearGradient from 'react-native-linear-gradient';
import AppIntroSlider from 'react-native-app-intro-slider';
import { SwipeablePanel } from 'rn-swipeable-panel';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import { batch } from 'react-redux';
import CheckBox from '@react-native-community/checkbox';
import select from '../../common/select.png'
import { TextInput } from 'react-native-gesture-handler';
import { addTransaction } from '../../redux/actions/Coupon';
import SwipeButton from 'rn-swipe-button';

const Invest = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
    } = props;
    const listRef = useRef();
    const [showRealApp, setShowRealApp] = useState(false);
    let [ShowComment, setShowModelComment] = useState(true);
    let [animateModal, setanimateModal] = useState(false);
    const [currentIndex, setcurrentIndex] = useState(0);
    const [type, setType] = useState('')
    const [disableCBButton, setDisableCBButton] = useState(false)
    const defaultStatusMessage = 'swipe status appears here';
    const [swipeStatusMessage, setSwipeStatusMessage] = useState(
        defaultStatusMessage,
    );
    const [number, setNumber] = useState('')
    const [coin, setCoin] = React.useState(false);
    const [wallet, setWallet] = useState('');
    const [show, setShow] = useState('HighRisk')
    const SCREEN_HEIGHT = Dimensions.get('screen').height;
    const [panelProps, setPanelProps] = useState({
        fullWidth: true,
        openLarge: true,
        showCloseButton: false,
        onClose: () => closePanel(),
        onPressCloseButton: () => closePanel(),
        // ...or any prop you want
    });
    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [isPanelActive, setIsPanelActive] = useState(false);
    const [interestCategory, setInterestCategory] = useState('High Risk');
    const [riskCategory, setRiskCategory] = useState('2');
    const [rememberMe, setRememberMe] = useState(false)
    const [slide, setSlide] = useState(false)
    const [firstLoad, setFirstLoad] = useState(false)


    const rowdata = [
        { name: 'LTCT' },
        { name: 'GRS' },
        { name: 'GUAP' },
        { name: 'ILC' },
        { name: 'KMD' },
        { name: 'QXEN' },
        { name: 'PIVX' },
        { name: 'QTUM' },
        { name: 'RVN' },
        { name: 'SMART' },
        { name: 'SOL' },
        { name: 'SYS' },
        { name: 'TLOS' },
        { name: 'TRX' },
        { name: 'USDT.SOL' },
        { name: 'USDT.TRC 20' },
        { name: 'VTC' },
        { name: 'WAVES' },
        { name: 'XEM' },
        { name: 'XMR' },

    ]
    useEffect(() => {
        if (firstLoad == true) {
            handleTransaction()
        }
        setFirstLoad(true)
    }, [slide]);

    useEffect(() => {
        // props?.getTransactionsList('deposit');
        props?.walletBalance();

    }, [])
    const handleTransaction = () => {
        if (number == "") {
            Alert.alert(CommonStrings.AppName, 'Please Enter Amount')
        } else if (number < 10) {
            Alert.alert(CommonStrings.AppName, 'Minimum Amount should be $10.')
        } else {

            var data = {
                type: "invest",
                title: interestCategory,
                amount: number,
                riskCategory: riskCategory
            }
            
            props.initiateTransaction(data, navigation)
            props?.walletBalance();
            setNumber("");
            

        }
    }
    // const handleSubmit1 = () => {
    //     if (wallet == '') {
    //         alert('Enter the Walled Address')
    //     } else if (number == '') {
    //         alert('Enter the Amount')
    //     } else {
    //         let request = {
    //             coin: dropdownval,
    //             withdrawType: withdrawType,
    //             wallet: wallet,
    //             amount: number,
    //             type: "withdraw"
    //         }
    //         setIsPanelActive(false)
    //         setNumber(null)
    //         
    //         props?.initiateWithdrawRequest(request)

    //     }
    // }
    const handleAmountChange = (text) => {
        setNumber(text);
    }
    const handleNumberChange = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {
            setNumber(value);
            setIsValidNumber(true)
        }
    };
    const handleNumberChange1 = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {

            setCoin(value);
            setWallet(true)

        }
    };

    const currencyFormat = (num) => {
        return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    }

    const openPanel = () => {
        if (number == "") {
            alert("Please Enter Amount")
        } else if (number < 10) {
            alert("Minimum Amount should be $10")
        } else {
            setIsPanelActive(true);
        }
    }
    const handleAgressiveClick = () => {
        setAgressive(['#C40730', '#FD5578']);
        setConservative('white');
        setRefferal('white');
        setProfit('white')
        setWithdrawType('agressive');
    };

    const handleConservativeClick = () => {
        setConservative(['#C40730', '#FD5578']);
        setAgressive('white');
        setRefferal('white');
        setProfit('white');
        setWithdrawType('conservative');

    };
    const handleProfitClick = () => {
        setProfit(['#C40730', '#FD5578']);
        setRefferal('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('admitprofit');
    };

    const handleRefferalClick = () => {
        setRefferal(['#C40730', '#FD5578']);
        setProfit('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('refer');
    };
    // const closemodal = () => {
    //     setmodalVisible(false)
    // }
    const closePanel = () => {
        setIsPanelActive(false);
    };

    // const openPanel = () => {
    //     setIsPanelActive(true);
    // };
    const CheckoutButton = () => {
        return (
            <View style={tw`h-16 w-16 bg-white items-center justify-center`}>
                <Image source={ImageIcons.arrow_both} style={tw`h-4 bg-white absolute mt-3.5 w-4 ml-3 `} />
            </View>
        );
    }
    const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);
    return (
        <>
            <View style={{ backgroundColor: '#FFFFFF' }}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Invest'} />

                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps='handled'>
                    {isPanelActive == false &&

                        <View style={tw`flex justify-center items-center w-12/12`}>
                            <View style={tw`mt-6 w-10/12 `}>
                                <Text style={tw`text-[#000000] text-2xl	font-bold text-center`}>How much would you like to Invest today?</Text>
                            </View>
                            <View style={tw`h-35 w-10/12 bg-[#ffffff] rounded-[8] justify-center border  my-5 px-9`}>
                                <View style={tw`flex-row justify-between w-12/12 mt-3`}>
                                    <Text style={tw`text-[#002662] text-3.5  `}>Enter Amount</Text>
                                    <Text style={tw`text-[#030303] text-3.5 `}>Perfect your Earnings</Text>
                                </View>
                                <View style={tw`flex-row w-12/12 mt-9 flex items-center `}>
                                    <Text style={tw`text-black font-bold text-3xl  w-1/12`}>$</Text>
                                    <TextInput
                                        style={tw`text-black font-bold text-3xl w-11/12    `}
                                        value={number}
                                        type='text'
                                        placeholder={'Enter Amount'}
                                        placeholderTextColor={'gray'}
                                        onChangeText={handleAmountChange}
                                        keyboardType="numeric"
                                        selectionColor="Black"
                                    />
                                </View>
                            </View>
                            <View style={tw`bg-[#171717] flex-row p-4 px-9 justify-between w-10/12 rounded-[8] shadow-2xl  shadow-[#7D64FF] `}>
                                <View>
                                    <Text style={tw`text-white opacity-70 mt-[1.5] font-bold  text-[#FFFFFF]`}>Available Balance</Text>
                                    {/* <Text style={tw`text-white font-bold text-5 mt-4`}>$14,590.20</Text> */}
                                    <View style={tw`flex-row mt-5  items-center text-center`}>
                                        {/* $ {props?.getwalletBalance?.amount} */}
                                        <Text style={tw`text-[#2AEFB4] font-bold text-4xl `}>${currencyFormat(props?.getwalletBalance?.amount)} </Text>
                                    </View>
                                </View>
                            </View>
                            <View style={tw` w-10/12 mt-5 `}>
                                <Text style={tw` ml-3 text-xl text-[#030303] `}>Choose your investment type</Text>
                            </View>
                            {riskCategory == '2' &&
                                <View style={tw`flex-row justify-evenly w-11/12`}>

                                    <TouchableOpacity style={tw`w-5/12 h-50  bg-white shadow-[#7D64FF]   shadow-2xl rounded-[6] border-2px  my-5`}
                                        onPress={() => {
                                            setInterestCategory("Low Risk");
                                            setRiskCategory('1');
                                        }} >
                                        <View>
                                            <Image source={ImageIcons.Icon_7} style={tw`h-12 w-12.5 mx-4 my-4`} />
                                            <View style={tw` my-10`}>
                                                <Text style={tw` mx-4 text-black font-bold text-2xl`}>15% - 0%</Text>
                                                <Text style={tw`text-sm mx-4 mt-3 text-black `}>Low risk</Text>
                                            </View>

                                        </View>
                                    </TouchableOpacity>
                                    <TouchableOpacity style={tw`w-5/12`} onPress={() => {
                                        setInterestCategory("High Risk");
                                        setRiskCategory('2');
                                    }}>
                                        <View>
                                            <LinearGradient colors={['#171717', '#171717']} start={{ x: 0.0, y: 0.0 }}
                                                end={{ x: 1.0, y: 0.0 }}
                                                locations={[0.0, 1.0]} style={tw`h-50  bg-white   shadow-2xl shadow-[#7D64FF]  rounded-[6] border-2px  my-5`}>
                                                <View style={tw``}>
                                                    <Image source={ImageIcons.Icon_7} style={tw`h-12 w-12.5 mx-4 my-4`} />

                                                    <View style={tw` my-10`}>
                                                        <Text style={tw` mx-4 text-white font-bold text-2xl`}>15% - 5%</Text>
                                                        <Text style={tw` mx-4 mt-3 text-white text-sm`}>High risk</Text>
                                                    </View>
                                                </View>
                                            </LinearGradient>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            }
                            {riskCategory == '1' &&
                                <View style={tw`flex-row justify-evenly w-11/12`}>
                                    <TouchableOpacity style={tw`w-5/12`} onPress={() => {
                                        setInterestCategory("Low Risk");
                                        setRiskCategory('1');
                                    }} >
                                        <View>
                                            <LinearGradient colors={['#171717', '#171717']} start={{ x: 0.0, y: 0.0 }}
                                                end={{ x: 1.0, y: 0.0 }}
                                                locations={[0.0, 1.0]} style={tw`h-50  bg-white shadow-[#7D64FF]   shadow-2xl rounded-[6] border-2px  my-5`}>
                                                <View style={tw`flex-row`}>
                                                    <Image source={ImageIcons.Icon_7} style={[tw`h-12 w-12.5 mx-4 my-4`]} />
                                                    {/* <Image source={ImageIcons.vector} style={tw`h-3 w-4 m-18 my-7`} /> */}
                                                </View>
                                                <View style={tw` my-10`}>
                                                    <Text style={tw` mx-4 text-white font-bold text-2xl`}>5% - 10%</Text>
                                                    <Text style={tw` mx-5 mt-3 text-white text-sm`}>Low risk</Text>
                                                </View>
                                            </LinearGradient>
                                        </View>
                                    </TouchableOpacity>
                                    <TouchableOpacity style={tw`w-5/12 h-50  bg-white shadow-[#7D64FF]   shadow-2xl rounded-[6] border-2px  my-5`}
                                        onPress={() => {
                                            setInterestCategory("High Risk");
                                            setRiskCategory('2');
                                        }}>
                                        <View >
                                            <Image source={ImageIcons.Icon_7} style={[tw`h-12 w-12.5 mx-4 my-4 `]} />
                                            <View style={tw` my-10`}>
                                                <Text style={tw` mx-4 text-black font-bold text-2xl`}>15% - 5%</Text>
                                                <Text style={tw`text-sm mx-4 mt-3 text-black `}> High risk</Text>
                                            </View>

                                        </View>
                                    </TouchableOpacity>
                                </View>
                            }

                        </View>

                    }
                    <View style={tw`w-12/12 justify-center items-center mt-10 mb-30`}>
                        <SwipeButton
                            disableResetOnTap
                            containerStyles={{ borderRadius: 10, }} // Remove borderRadius
                            height={50}
                            width={'80%'}
                            disabledThumbIconBorderColor={'#fff'}
                            onSwipeFail={() => {
                                setSlide(false)
                            }}
                            onSwipeStart={() => {
                                setSlide(false)
                            }}
                            onSwipeSuccess={() => {
                                setSlide(true)
                            }}
                            railBackgroundColor="#000"
                            railFillBackgroundColor='#fff'
                            shouldResetAfterSuccess={true}
                            railStyles={{ borderRadius: 10, borderColor: 'white', backgroundColor: 'white', marginVertical: '2%', marginHorizontal: '2%' }}
                            thumbIconComponent={CheckoutButton}
                            thumbIconBorderColor={'#ffffff'}
                            title="Swipe to Invest"
                            titleFontSize={20}
                            // titleStyles={{color: (slide == true) ? '#000000' : '#000000', paddingLeft:'10%'}}            
                            titleStyles={{ color: '#fff', paddingLeft: '10%', zIndex: 1001 }}
                        />

                    </View>


                </ScrollView>



            </View>

            <SwipeablePanel style={tw` h-151 bg-[#ffffff] `} {...panelProps} isActive={isPanelActive}>
                <View style={tw` bg-[#FFF] `}>
                    <Text style={tw`text-center my-4 font-5 text-sm`}>Selecy your coin for withdrawal</Text>

                    <View style={tw`h-30 w-10.6/12 bg-[#002662] shadow-[#7D64FF]  shadow-2xl rounded-[4] border-2px mx-6 mt-20`}>
                        <View style={tw`p-4 mx-2`}>
                            <Text style={tw`text-[#ffffff]`}>Enter your wallet address</Text>
                        </View>
                        <View style={tw`relative  ml-6 flex-row`}>
                            <TextInput
                                style={tw` w-7/12  bg-[#ffffff] text-black rounded-3 h-11  p-3	`}
                                value={wallet}
                                onChangeText={(value) => setWallet(value)}
                                placeholder={'Wallet Address'}
                                placeholderTextColor={"black"}
                                // onChangeText={handleChange('email')}
                                // onChangeText={handleNumberChange1}
                                // reference={emailInputRef}
                                selectionColor="white"
                            // onSubmitEditing={() => passwordInputRef?.current?.focus()}
                            />
                            {coin &&
                                <>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-6 w-6  justify-center text-center items-center rounded-[2] my-2 absolute mx-35  `}
                                    >
                                        <View style={tw`flex-row `}>
                                            <Image
                                                source={select}
                                                style={[tw`h-4 w-4  `, { tintColor: 'white' }]}
                                            >
                                            </Image>
                                        </View>
                                    </LinearGradient>
                                </>
                            }

                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-9 w-3/12  justify-center text-center items-center rounded-[2]  mx-5   flex-row`}
                            >
                                <TouchableOpacity onPress={() => setShowdrowdoenval(s => !s)} style={tw`flex-row`}>
                                    <Text style={tw`text-[#ffffff]`}>{dropdownval}</Text>
                                    <Image source={ImageIcons.dropdown} style={tw`h-2 w-3 mx-2 mt-2`} />
                                </TouchableOpacity>
                            </LinearGradient>
                        </View>
                    </View>
                    {showdrowdoenval == true &&
                        <ScrollView style={tw`bg-[#000000] border mt-8 absolute z-50 h-40 right-7 top-54`}>
                            {rowdata?.map((data) => {
                                return (
                                    <TouchableOpacity onPress={() => { setDropdownval(data.name); setShowdrowdoenval(false) }} style={tw`mt-2 mb-2 pl-5 pr-5`}><Text style={tw`text-[#ffffff]`}>{data.name}</Text></TouchableOpacity>
                                )
                            })}
                        </ScrollView>
                    }
                    <Text style={tw`text-center text-xs mt-5`}>Note: Withdrawal process may take 04-10 working hours.</Text>
                    <TouchableOpacity onPress={() => handleSubmit1()}>
                        <LinearGradient colors={['#171717', '#171717']} start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw`h-16 w-8/12 mx-auto items-center  justify-center rounded-[8] p-1 mt-40`}
                        >
                            <Text style={tw`text-white text-sm font-bold`}>Proceed</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>


            </SwipeablePanel>

        </>

    )
}




export default (Invest);