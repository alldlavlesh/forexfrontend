import React, { useRef, useState, useEffect } from 'react';
import { Text, View, FlatList, ScrollView, Alert, StatusBar, LogBox, KeyboardAvoidingView, Platform, Keyboard, Modal, Button, Image, ImageBackground, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, ImageIcons, CommonStrings } from '../../common'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import select from '../../common/select.png'
import { SwipeablePanel } from 'rn-swipeable-panel';
import SwipeButton from 'rn-swipe-button';
import moment from 'moment';

const Totalinvest = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const [number, setNumber] = useState('')
    const [isValidNumber, setIsValidNumber] = useState(false);
    const [modalvisible, setmodalVisible] = React.useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [coin, setCoin] = React.useState(false);
    const [wallet, setWallet] = useState('');
    const defaultStatusMessage = 'swipe status appears here';
    const [swipeStatusMessage, setSwipeStatusMessage] = useState(
        defaultStatusMessage,
    );
    const [panelProps, setPanelProps] = useState({
        fullWidth: true,
        openLarge: true,
        showCloseButton: false,
        onClose: () => closePanel(),
        onPressCloseButton: () => closePanel(),
        // ...or any prop you want
    });
    const [isPanelActive, setIsPanelActive] = useState(false);

    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [agressive, setAgressive] = useState(['#C10932', '#FD5578']);
    const [conservative, setConservative] = useState('white');
    const [withdrawType, setWithdrawType] = useState('agressive');
    const [profit, setProfit] = useState('white');
    const [refferal, setRefferal] = useState('white');

    const currencyFormat = (num) => {
        return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    }

    useEffect(() => {
        // props?.getTransactionsList('deposit');
        props.getTransactionsListStock({
            value: 'all'
        })
    }, [])

    const rowdata = [
        { name: 'LTCT' },
        { name: 'GRS' },
        { name: 'GUAP' },
        { name: 'ILC' },
        { name: 'KMD' },
        { name: 'QXEN' },
        { name: 'PIVX' },
        { name: 'QTUM' },
        { name: 'RVN' },
        { name: 'SMART' },
        { name: 'SOL' },
        { name: 'SYS' },
        { name: 'TLOS' },
        { name: 'TRX' },
        { name: 'USDT.SOL' },
        { name: 'USDT.TRC 20' },
        { name: 'VTC' },
        { name: 'WAVES' },
        { name: 'XEM' },
        { name: 'XMR' },

    ]
    const DATA = [
        {
            img: ImageIcons.downarrow_img,
            text: 'High Risk',
            text1: '23-08-2023 | 10:04 AM',
            text2: '$0.10',
            text3: 'Completed',
            img1: ImageIcons.Chart,
        },
        {
            img: ImageIcons.downarrow_img,
            text: 'Low Risk',
            text1: '23-08-2023 | 10:04 AM',
            text2: '$0.06',
            text3: 'Completed',
            img1: ImageIcons.Chart,
        }

    ]

    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };

    const renderItem1 = ({ item, index }) => {
        
        return (
            <View style={tw` w-12/12 rounded-2xl border-2px flex items-center shadow-sm mt-2 shadow-[#CEEBFF]  flex-row p-2   `}>

                <View style={tw` w-2/12 `}>
                    <ImageBackground source={ImageIcons.bg} style={tw` items-center justify-center  h-10 w-10  rounded-full`}>
                        <Image source={ImageIcons.downarrow_img} style={tw` h-8 w-8  rounded-full`} />
                    </ImageBackground>
                </View>
                <View style={tw`w-6/12`}>
                    {item?.title === "wallet_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>Wallet Amount</Text>
                    )}
                    {item?.title === "low_risk_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>Low Risk Investment</Text>
                    )}
                    {item?.title === "high_risk_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>High Risk Investment</Text>
                    )}
                    {!["wallet_amount", "low_risk_amount", "high_risk_amount"].includes(item?.title) && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>{item?.title}</Text>
                    )}
                    <Text style={tw`text-sm font-bold text-black font-[1]`}>{moment(item?.created_at)?.format('lll')}</Text>
                </View>
                <View style={tw` w-4/12 items-end p-1`}>
                    <Text style={tw`text-sm  font-bold text-black  font-[4]`}>${currencyFormat(item?.amount)}</Text>
                    <Text style={tw`text-sm  font-[6] text-[#13C08C] font-bold`}>Completed</Text>
                </View>
            </View>

        );
    }

    return (


        
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>
            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Invest more get more'} />
            <ScrollView style={tw` `}>
                <View style={tw` w-12/12  flex justify-center items-center mt-4  `} >
                    <View style={tw` w-11/12  flex justify-center items-start   `} >
                        <Text style={tw`text-[#191925]  font-bold text-xl ml-3`}>Total Invested amount</Text>

                         <Text style={tw`text-[#191925] font-bold text-3xl ml-3 mt-2 `}>${currencyFormat(props?.dashboarddata?.investedAmount)}</Text>

                    </View>
                    <View style={tw` w-10.8/12  flex justify-center items-center mt-4  `}>
                        <View style={tw`h-38 bg-[#171717]  w-12/12   flex justify-center items-center   rounded-[5]  flex-row`}>
                            <View style={tw`w-6/12  flex justify-center items-center`}>
                                <Image source={ImageIcons.whitecircle} style={tw` h-12 w-12`} />
                                <Text style={tw`text-lg text-[#FFFFFF] `}>${parseFloat(props?.dashboarddata?.otherData?.high_risk_amount).toFixed(2)}</Text>
                                <Text style={tw`text-xl text-[#FFFFFF] `}>High risk</Text>
                            </View>
                            <Image source={ImageIcons.Line_2} style={tw`bg-white h-28 w-0.2`} />
                            <View style={tw`w-6/12  flex justify-center items-center`}>
                                <Image source={ImageIcons.whitecircle} style={tw` h-12 w-12 `} />
                                {/* {/ <Text style={tw`text-lg font-light text-[#FFFFFF] `}>${parseFloat(props?.dashboarddata?.otherData?.low_risk_amount).toFixed(2)}</Text> /} */}
                                <Text style={tw`text-lg font-light text-[#FFFFFF] `}>${parseFloat(props?.dashboarddata?.otherData?.low_risk_amount).toFixed(2)}</Text>
                                <Text style={tw`text-xl  text-[#FFFFFF] `}>Low risk</Text>
                            </View>

                        </View>
                    </View>

                    <View style={tw` w-12/12  flex justify-center items-center mt-4  `} >
                        <LinearGradient colors={[ '#CBDDC4', '#D7DAE0']} start={{ x: 0, y: 0.1 }}
                            end={{ x: 1, y: 0.1 }} style={tw`h-44 w-12/12 flex  items-center `}>
                            <View style={tw` w-11/12  flex justify-center items-start mt-4 `}>
                                <Text style={tw`text-[#191925]  font-bold text-xl ml-3`}>You have earned profit of</Text>

                                {/* <TextInput style={tw`text-[#191925] font-bold text-xl ml--2`}>{props?.dashboarddata?.totalBalance?.toFixed(2)}</TextInput> */}
                                {/* {/ <Text style={tw`text-[#191925] font-bold text-3xl mt--10 ml--2`}>${(parseFloat(props?.dashboarddata?.wallet?.conservativeAmount) + parseFloat(props?.dashboarddata?.wallet?.amount)).toFixed(2)}</Text > /} */}
                                < Text style={tw`text-[#191925] font-bold text-3xl mt-2 ml-3`}>${(props?.dashboarddata?.wallet?.conservativeAmount ?props?.dashboarddata?.wallet?.conservativeAmount:'0.00')}</Text>


                            </View>
                        </LinearGradient>
                    </View>
                    <View style={tw` w-10.8/12  flex justify-center items-center mt--15  `} >
                        <View style={tw`h-30 bg-[#171717]  w-12/12  rounded-[5] flex justify-center items-center flex-row`}>
                            <View style={tw`w-4/12  justify-center items-center`}>
                                <TouchableOpacity onPress={() => props.navigation.navigate("Invest")}>
                                    <Image source={ImageIcons.Plus} style={tw` h-15 w-15.4`} />
                                    <Text style={tw`text-base text-[#FFFFFF] ml-2 `}>Invest</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={tw`w-4/12 justify-center items-center`}>
                                <TouchableOpacity onPress={() => props.navigation.navigate("Transaction")}>
                                    <Image source={ImageIcons.Polygon_4} style={tw` h-15 w-15.4 ml-3 `} />
                                    <Text style={tw`text-base text-[#FFFFFF] `}>Transaction</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={tw`w-4/12 justify-center items-center`}>
                                <TouchableOpacity onPress={() => props.navigation.navigate("Withdraw")}>
                                    <Image source={ImageIcons.Handollar} style={tw` h-15 w-15`} />
                                    <Text style={tw`text-base text-[#FFFFFF] `}>Withdraw</Text>
                                </TouchableOpacity>
                            </View>


                        </View>
                    </View>
                    <View style={tw`w-11/12 mt-4`}>
                        <Text style={tw`text-[#000000] text-base text-sm font-bold`}> Recent Transactions</Text>
                    </View>
                    <View style={tw` w-11/12  mt-4`}>
                        <FlatList
                            data={props?.transactionStock}
                            renderItem={renderItem1}
                            keyExtractor={item => item?.id}
                            ListEmptyComponent={renderEmptyComponent}
                        />
                    </View>


                </View>

            </ScrollView >



        </KeyboardAvoidingView >



    )
}




export default (Totalinvest);