import React from 'react'
import { View, Image, Text } from 'react-native';
import styles from './styles'
import { ImageIcons } from '../../common'

const VerificationHeader = (props) => {
    return (
        <View style={styles.headerContainer}>
            <HeaderItem color={props.first} id={"reviews"} image={ImageIcons.noteIcon} text={"Review listed information"} />
            <HeaderItem color={props.second} id={"photo_bill"} image={ImageIcons.listIcon} text={"Photo of store's utility bill"} />
            
        </View>
    )
}

const HeaderItem = ({ color, id, image, text }) => {
    return (
        <View key={id} style={{ width: '32%', justifyContent: 'center', alignItems: 'center'}}>
            <Image source={image} style={[styles.headerItemImg,{ tintColor: color }]} />
            <Text style={styles.headerItemText}>{text}</Text>
        </View>
    )
}

export default VerificationHeader;
