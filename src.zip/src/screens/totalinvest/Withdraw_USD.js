import React, { useRef, useState } from 'react';
import { Text, View, ScrollView, Alert, StatusBar, LogBox, KeyboardAvoidingView, Platform, Keyboard, Modal, Button, Image, ImageBackground, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, ImageIcons, CommonStrings } from '../../common'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import select from '../../common/select.png'
import { SwipeablePanel } from 'rn-swipeable-panel';
import SwipeButton from 'rn-swipe-button';

const Withdraw_USD = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const [number, setNumber] = useState('')
    const [isValidNumber, setIsValidNumber] = useState(false);
    const [modalvisible, setmodalVisible] = React.useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [coin, setCoin] = React.useState(false);
    const [wallet, setWallet] = useState('');
    const defaultStatusMessage = 'swipe status appears here';
    const [swipeStatusMessage, setSwipeStatusMessage] = useState(
        defaultStatusMessage,
    );
    const [panelProps, setPanelProps] = useState({
        fullWidth: true,
        openLarge: true,
        showCloseButton: false,
        onClose: () => closePanel(),
        onPressCloseButton: () => closePanel(),
        // ...or any prop you want
    });
    const [isPanelActive, setIsPanelActive] = useState(false);

    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [agressive, setAgressive] = useState(['#C10932', '#FD5578']);
    const [conservative, setConservative] = useState('white');
    const [withdrawType, setWithdrawType] = useState('agressive');
    const [profit, setProfit] = useState('white');
    const [refferal, setRefferal] = useState('white');

    const rowdata = [
        { name: 'LTCT' },
        { name: 'GRS' },
        { name: 'GUAP' },
        { name: 'ILC' },
        { name: 'KMD' },
        { name: 'QXEN' },
        { name: 'PIVX' },
        { name: 'QTUM' },
        { name: 'RVN' },
        { name: 'SMART' },
        { name: 'SOL' },
        { name: 'SYS' },
        { name: 'TLOS' },
        { name: 'TRX' },
        { name: 'USDT.SOL' },
        { name: 'USDT.TRC 20' },
        { name: 'VTC' },
        { name: 'WAVES' },
        { name: 'XEM' },
        { name: 'XMR' },

    ]

    const handleSubmit1 = () => {
        if (wallet == '') {
            alert('Enter the Walled Address')
        } else if (number == '') {
            alert('Enter the Amount')
        } else {
            let request = {
                coin: dropdownval,
                withdrawType: withdrawType,
                wallet: wallet,
                amount: number,
                type: "withdraw"
            }
            setIsPanelActive(false)
            setNumber(null)
            
            props?.initiateWithdrawRequest(request)

        }
    }
    const handleNumberChange = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {
            setNumber(value);
            setIsValidNumber(true)
        }
    };
    const handleNumberChange1 = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {

            setCoin(value);
            setWallet(true)

        }
    };

    const openPanel = () => {
        if (number == "") {
            alert("Please Enter Amount")
        } else if (number < 10) {
            alert("Minimum Amount should be $10")
        } else {
            setIsPanelActive(true);
        }
    }
    const handleAgressiveClick = () => {
        setAgressive(['#C40730', '#FD5578']);
        setConservative('white');
        setRefferal('white');
        setProfit('white')
        setWithdrawType('agressive');
    };

    const handleConservativeClick = () => {
        setConservative(['#C40730', '#FD5578']);
        setAgressive('white');
        setRefferal('white');
        setProfit('white');
        setWithdrawType('conservative');

    };
    const handleProfitClick = () => {
        setProfit(['#C40730', '#FD5578']);
        setRefferal('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('admitprofit');
    };

    const handleRefferalClick = () => {
        setRefferal(['#C40730', '#FD5578']);
        setProfit('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('refer');
    };
    // const closemodal = () => {
    //     setmodalVisible(false)
    // }
    const closePanel = () => {
        setIsPanelActive(false);
    };

    // const openPanel = () => {
    //     setIsPanelActive(true);
    // };
    const CheckoutButton = () => {
        return (
            <View style={tw`h-11 w-11 rounded-full bg-[#BD0B30] items-center justify-center `}>
                <Image source={ImageIcons.arrow_login} style={tw`h-4 tint-[#fff]  absolute mt-3.5 w-5 ml-3 `} />
            </View>
        );
    }
    const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);
    return (
        <>
            <View style={{ backgroundColor: '#FFFFFF' }}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Withdraw USD'} />
                {isPanelActive == false &&
                    <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps='handled'>
                        <View style={tw`bg-[#171717] flex-row p-4 justify-between mx-5 rounded-[8] mt-6 shadow-2xl h-33 shadow-[#7D64FF] z`}>

                            <View>

                                <Text style={tw`text-white opacity-70 mt-[1.5] font-bold mx-2 ml-3`}>Available Balance</Text>
                                {/* <Text style={tw`text-white font-bold text-5 mt-4`}>$14,590.20</Text> */}
                                <View style={tw`flex-row mt-5  items-center text-center`}>
                                    {/* <TextInput style={tw`text-white font-bold text-3xl `}>${props?.dashboarddata?.totalBalance?.toFixed(2)}</TextInput> */}
                                    <Text style={tw`text-[#2AEFB4] font-bold text-5xl mx-2 ml-3`}>${(parseFloat(props?.dashboarddata?.wallet?.conservativeAmount) + parseFloat(props?.dashboarddata?.wallet?.amount)).toFixed(2)}</Text>
                                </View>

                            </View>
                            <View style={tw`text-right`}>
                                {/* <Text style={tw`text-white text-right mt-[1.5] font-bold opacity-70 right-4`}>Agressive Plan</Text>
                                <Text style={tw`text-white text-right right-4 text-base font-bold`}>${parseFloat(props?.dashboarddata?.wallet?.conservativeAmount).toFixed(2)}</Text>
                                <Text style={tw`text-white mt-2 opacity-70 font-bold text-right mx-1 right-3`}>Conservative Plan</Text>
                                <Text style={tw`text-white text-right right-4 text-base font-bold`}>${parseFloat(props?.dashboarddata?.wallet?.amount).toFixed(2)}</Text> */}

                                {/* <Image source={ImageIcons.withdrawmoney} style={tw`h-30 w-30 mt-5`}/> */}
                            </View>



                        </View>
                        {/* <View style={tw`justify-center items-center`}>
                            <View style={tw`h-25 bg-white  w-10.6/12   shadow-xl shadow-[#7D64FF]  rounded-[2] mt-6 flex-row`}>
                                <View style={tw`w-3/12 justify-center items-center mx-11 flex-row`}>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-15 w-15 rounded-full  justify-center items-center`}>
                                        <Image source={ImageIcons.network} style={tw` h-8 w-8`} />
                                    </LinearGradient>
                                    <View style={tw`flex-column ml-3`}>
                                        <Text style={tw`text-xs text-[#94AFB6] `}>Daily Profits</Text>
                                        <Text style={tw`text-base text-[#3D6670] font-bold`}>${parseFloat(props?.dashboarddata?.wallet?.adminProfitAmount).toFixed(2)}</Text>
                                    </View>
                                </View>
                                <View style={tw`w-3/12 justify-center items-center mx-9 flex-row`}>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-15 w-15 rounded-full  justify-center items-center`}>
                                        <Image source={ImageIcons.network1} style={tw` h-8 w-8`} />
                                    </LinearGradient>
                                    <View style={tw`flex-column ml-3`}>
                                        <Text style={tw`text-xs text-[#94AFB6] `}>Refer N earn</Text>
                                        <Text style={tw`text-base text-[#3D6670] font-bold`}>${parseFloat(props?.dashboarddata?.wallet?.refferalWalletAmount).toFixed(2)}</Text>
                                    </View>
                                </View>
                            </View>
                        </View> */}
                        <View style={tw`float-left`} >
                            <Text style={tw`text-[#848484] ml-5 mt-4`}> AMOUNT</Text>
                            {/* <View style={tw`bg-[#fff]  p-4 justify-center items-center mx-5 rounded-[6] border mt-6 shadow-2xl h-35 shadow-[#7D64FF] z`}> */}
                            {/* <Text style={tw`w-8/12 text-center text-[#002662] text-sm mt-2`}>Enter Suitable amount you would like to Withdrawal</Text> */}
                            <View style={tw`flex-row`}>
                                <TextInput
                                    style={tw`mx-5  bg-[#ffffff] text-black border border-[#E8E8E8] bg-white rounded-2 h-12 mt-3 pl-4 w-7/12`}
                                    value={number}
                                    onChangeText={(value) => setNumber(value)}
                                    placeholder={' $ Enter amount'}
                                    keyboardType="numeric"
                                    selectionColor="black"
                                />
                                {isValidNumber &&
                                    <>
                                        <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                            end={{ x: 1.0, y: 0.1 }}
                                            locations={[0.0, 1.0]} style={tw` h-6 w-6  justify-center text-center items-center rounded-[2]  absolute top-1/2 transform -translate-y-1/2 right-20 mt--3  `}
                                        >
                                            <View style={tw`flex-row `}>
                                                <Image
                                                    source={select}
                                                    style={[tw`h-4 w-4  `, { tintColor: 'white' }]}
                                                >
                                                </Image>
                                            </View>
                                        </LinearGradient>
                                    </>
                                }
                            </View>
                            {/* </View> */}
                        </View>
                        <View style={tw`mx-5  bg-[#EBEBEB] text-black border border-[#EBEBEB] rounded-2 h-12 ml-60 mt--12 pl-4 w-1/3.5`}>
                            <Image source={ImageIcons.Dollar} resizeMode='contain' style={tw`h-12 w-10 mt--0.5 ml--3`} />
                            <Text style={tw`ml-6 mt--8 font-bold ml-8`}>USD</Text>
                            <Image source={ImageIcons.down} resizeMode='contain' style={tw`h-5 w-10 mt--5 ml-12`} />
                        </View>

                        {/* <Text style={tw`ml-7 mt-4 font-bold`}>Select type of amount you want to withdrawal</Text> */}
                        <View style={tw` w-11/12 mx-4 my-3 mb-1 justify-center item-center`}>
                            <View style={tw` w-11/12 mx-4 flex-row justify-around my-3 mb-1 item-center`}>
                                {/* <TouchableOpacity
                                    onPress={handleAgressiveClick}
                                    style={{ backgroundColor: agressive }}
                                >
                                    {agressive === 'white' ? (
                                        <View style={tw` h-15 w-20 items-center  bg-[#fff] justify-evenly rounded-[4] shadow-xl shadow-[#7D64FF] `}>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mt-3`}>Agressive Plan</Text>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mb-3`}>Deposit</Text>

                                        </View>
                                    ) : (
                                        <LinearGradient
                                            colors={['#C40730', '#FD5578']}
                                            start={{ x: 0.1, y: 1.0 }}
                                            end={{ x: 1.0, y: 0.1 }}
                                            locations={[0.0, 1.0]} style={tw` h-15 w-20 bg-[#fff]   items-center  justify-evenly rounded-[4]  shadow-xl shadow-[#7D64FF]`}
                                        >
                                            <View style={tw` ml-14`}>
                                                <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                            </View>
                                            <Text style={tw`text-[#fff] font-bold text-2.5 text-center `}>Agressive Plan</Text>
                                            <Text style={tw`text-[#fff] font-bold text-2.5 text-center mb-3`}>Deposit</Text>

                                        </LinearGradient>
                                    )}
                                </TouchableOpacity> */}

                                {/* <TouchableOpacity
                                    onPress={handleConservativeClick}
                                    style={{ backgroundColor: conservative }}
                                >
                                    {conservative === 'white' ? (
                                        <View style={tw` h-15 w-21   items-center  justify-evenly rounded-[4] bg-[#fff]  shadow-xl shadow-[#7D64FF] p-1`}>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mt-3`}>Conservative Plan</Text>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mb-3`}>Deposit</Text>

                                        </View>
                                    ) : (
                                        <LinearGradient
                                            colors={['#C40730', '#FD5578']}
                                            start={{ x: 0.1, y: 1.0 }}
                                            end={{ x: 1.0, y: 0.1 }}
                                            locations={[0.0, 1.0]} style={tw`   items-center h-15 w-21   justify-evenly rounded-[4] p-1 shadow-[#7D64FF]  shadow-2xl`}

                                        >
                                            <View style={tw` ml-14`}>
                                                <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                            </View>
                                            <Text style={tw`text-[#fff] font-bold text-2.5 text-center `}>Conservative Plan</Text>
                                            <Text style={tw`text-[#fff] font-bold text-2.5 text-center mb-3`}> Deposit</Text>

                                        </LinearGradient>
                                    )}
                                </TouchableOpacity> */}

                                {/* <TouchableOpacity
                                    onPress={handleProfitClick}
                                    style={{ backgroundColor: profit }}
                                >
                                    {profit === 'white' ? (
                                        <View style={tw` h-15 w-20  items-center  justify-evenly rounded-[4] bg-[#fff]  shadow-[#7D64FF]  shadow-2xl`}>
                                            <Text style={tw`text-[#000] font-bold text-2.5 text-center mt-3`}>Daily Profits </Text>
                                            <Text style={tw`text-[#000] font-bold text-2.5 text-center mb-3`}>Earned</Text>
                                        </View>
                                    ) : (
                                        <LinearGradient
                                            colors={['#C40730', '#FD5578']}
                                            start={{ x: 0.1, y: 1.0 }}
                                            end={{ x: 1.0, y: 0.1 }}
                                            locations={[0.0, 1.0]} style={tw` h-15 w-20   items-center shadow-[#7D64FF]  shadow-2xl  justify-evenly rounded-[4] p-1 `}

                                        >
                                            <View style={tw` ml-14`}>
                                                <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                            </View>
                                            <Text style={tw`text-[#fff] font-bold text-2.5 text-center `}>Daily Profits</Text>
                                            <Text style={tw`text-[#fff] font-bold text-2.5 text-center mb-3`}>Earned</Text>

                                        </LinearGradient>
                                    )}
                                </TouchableOpacity> */}

                                {/* <TouchableOpacity
                                    onPress={handleRefferalClick}
                                    style={{ backgroundColor: refferal }}
                                >
                                    {refferal === 'white' ? (
                                        <View style={tw` h-15 w-20 shadow-[#7D64FF]  shadow-2xl  items-center bg-[#fff]  justify-evenly rounded-[4]   `}>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mt-3`}>Refer N earn</Text>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mb-3`}> Amount</Text>

                                        </View>
                                    ) : (
                                        <LinearGradient
                                            colors={['#C40730', '#FD5578']}
                                            start={{ x: 0.1, y: 1.0 }}
                                            end={{ x: 1.0, y: 0.1 }}
                                            locations={[0.0, 1.0]} style={tw`h-15 w-20 shadow-[#7D64FF]  shadow-2xl  items-center  justify-evenly rounded-[4] p-1 `}

                                        >
                                            <View style={tw` ml-14`}>
                                                <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                            </View>
                                            <Text style={tw`text-[#fff] text-2.5 text-center font-bold `}>Refer N earn</Text>
                                            <Text style={tw`text-[#fff] text-2.5 text-center font-bold mb-3`}> Amount</Text>
                                        </LinearGradient>
                                    )}
                                </TouchableOpacity> */}
                            </View>
                            <View>
                                <Text style={tw`text-[#848484] mt-1`}> MERCHANT</Text>
                                <TextInput
                                    style={tw`mx-5  bg-[#ffffff] text-black border border-[#E8E8E8] bg-white rounded-2 h-12 mt-3 pl-4 ml-1 w-81`}
                                    // value={amount}
                                    type='text'
                                    placeholder={''}
                                    placeholderTextColor={Colors.GREY}
                                    // selectionColor="#C20A33"
                                    //   onChangeText={handleAmountChange}
                                    keyboardType='numeric'
                                />
                                <Image source={ImageIcons.down} resizeMode='contain' style={tw`h-8 w-10 mt--10 ml-70`} />
                            </View>
                            <View style={tw`mx-5  bg-[#ffffff] text-black border border-[#E8E8E8] bg-white rounded-2 h-12 ml-1 mt-5 pl-4 w-81`}>
                                <Text style={tw`text-[#848484] mt-3 text-base w-7/12`}> Free </Text>
                                <Text style={tw` text-black ml-64 mt--6`}>0.10%</Text>

                            </View>
                            <View style={tw`mx-5  bg-[#ffffff] text-black border border-[#E8E8E8] bg-white rounded-2 h-12 mt-5 ml-1 pl-4 w-81`}>
                                <Text style={tw`text-[#848484] mt-3 text-base w-7/12 `}> Amount Recieved </Text>
                                <Text style={tw` text-black ml-62 mt--6`}>0 USD</Text>
                            </View>

                            <View style={tw`h-50 mt-25`}>
                                <TouchableOpacity onPress={() => { openPanel() }} style={tw` h-13 w-76 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1  mt-3`}>
                                        <View style={tw`flex-row`}>
                                            <Text style={tw`text-black w-89 text-[4.5] px-35`}>Withdraw</Text>
                                        </View>
                                </TouchableOpacity>
                                <Text style={tw`text-[#000000] w-38  h-0.2 text-[4.5] px-35 bg-black justify-center rounded-[2] p-1 mt-5 ml-24`}></Text>
                            </View>
                        </View>

                    </ScrollView>
                }

                <TouchableOpacity onPress={() => { openPanel() }}>
                    {/* <View style={tw`h-14 w-6.5/12 my-50 mx-auto border border-[#C30B34] justify-between rounded-[8]`}
                    >
                        <View style={tw`flex-row mx-2 my-1 items-center`}>
                            <View style={tw`h-11 w-11 rounded-full items-center justify-center bg-[#BD0B30]`}>
                                <Image source={ImageIcons.arrow_login} style={tw`h-4 tint-[#fff]   w-5 `} />
                            </View>
                            <View>
                                <Text style={tw`text-black text-sm ml-3`}>Swipe to Withdraw</Text>
                            </View>
                        </View>
                    </View> */}
                </TouchableOpacity>
                {/* <View style={tw`justify-center items-center mt-5 mb-10`}>
                    <SwipeButton
                        containerStyles={{ borderRadius: 30 }}
                        height={50}
                        width={250}
                        // onSwipeFail={() => updateSwipeStatusMessage('Incomplete swipe!')}
                        // onSwipeStart={() => updateSwipeStatusMessage('Swipe started!')}
                        onSwipeSuccess={() =>
                            openPanel('Submitted successfully!')
                            // alert('Submitted successfuly')
                        }
                        railBackgroundColor="#fff"
                        thumbIconBorderColor={'#BD0B30'}
                        railFillBackgroundColor='#FD5578'
                        //shouldResetAfterSuccess={true}
                        railStyles={{ borderRadius: 30, borderColor: '#BD0B30', marginVertical: '2%', marginHorizontal: '2%' }}
                        thumbIconComponent={CheckoutButton}
                        // thumbIconImageSource={arrowRight}
                        // thumbIconWidth={100} 
                        title="Swipe to Withdrawal"
                        titleFontSize={14}
                        titleStyles={{ color: '#000000', paddingLeft: '10%', zIndex: 1001 }}
                    />
                </View> */}
            </View>

            <SwipeablePanel style={tw` h-151 bg-[#ffffff] `} {...panelProps} isActive={isPanelActive}>
                <View style={tw` bg-[#FFF] `}>
                    <Text style={tw`text-center my-4 font-5 text-sm`}>Selecy your coin for withdrawal</Text>

                    <View style={tw`h-30 w-10.6/12 bg-[#002662] shadow-[#7D64FF]  shadow-2xl rounded-[4] border-2px mx-6 mt-20`}>
                        <View style={tw`p-4 mx-2`}>
                            <Text style={tw`text-[#ffffff]`}>Enter your wallet address</Text>
                        </View>
                        <View style={tw`relative  ml-6 flex-row`}>
                            <TextInput
                                style={tw` w-7/12  bg-[#ffffff] text-black rounded-3 h-11  p-3	`}
                                value={wallet}
                                onChangeText={(value) => setWallet(value)}
                                placeholder={'Wallet Address'}
                                placeholderTextColor={"black"}
                                // onChangeText={handleChange('email')}
                                // onChangeText={handleNumberChange1}
                                // reference={emailInputRef}
                                selectionColor="white"
                            // onSubmitEditing={() => passwordInputRef?.current?.focus()}
                            />
                            {coin &&
                                <>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-6 w-6  justify-center text-center items-center rounded-[2] my-2 absolute mx-35  `}
                                    >
                                        <View style={tw`flex-row `}>
                                            <Image
                                                source={select}
                                                style={[tw`h-4 w-4  `, { tintColor: 'white' }]}
                                            >
                                            </Image>
                                        </View>
                                    </LinearGradient>
                                </>
                            }

                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-9 w-3/12  justify-center text-center items-center rounded-[2]  mx-5   flex-row`}
                            >
                                <TouchableOpacity onPress={() => setShowdrowdoenval(s => !s)} style={tw`flex-row`}>
                                    <Text style={tw`text-[#ffffff]`}>{dropdownval}</Text>
                                    <Image source={ImageIcons.dropdown} style={tw`h-2 w-3 mx-2 mt-2`} />
                                </TouchableOpacity>
                            </LinearGradient>
                        </View>
                    </View>
                    {showdrowdoenval == true &&
                        <ScrollView style={tw`bg-[#000000] border mt-8 absolute z-50 h-40 right-7 top-54`}>
                            {rowdata?.map((data) => {
                                return (
                                    <TouchableOpacity onPress={() => { setDropdownval(data.name); setShowdrowdoenval(false) }} style={tw`mt-2 mb-2 pl-5 pr-5`}><Text style={tw`text-[#ffffff]`}>{data.name}</Text></TouchableOpacity>
                                )
                            })}
                        </ScrollView>
                    }
                    <Text style={tw`text-center text-xs mt-5`}>Note: Withdrawal process may take 04-10 working hours.</Text>
                    <TouchableOpacity onPress={() => handleSubmit1()}>
                        <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw`h-16 w-8/12 mx-auto items-center  justify-center rounded-[8] p-1 mt-40`}
                        >
                            <Text style={tw`text-white text-sm font-bold`}>Proceed</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>


            </SwipeablePanel>

        </>

    )
}




export default (Withdraw_USD);