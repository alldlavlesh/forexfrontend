import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
// import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';

import LinearGradient from 'react-native-linear-gradient';
import { getTransactionsList } from '../../redux/actions/Coupon';

const Portfolio = (props) => {

    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate

    const onChangeDate = (dateTime) => {
        if (dateTime) {
            setShowDatePicker(false)
            if (datePickerFor === "startDate") {
                setIsPlaceholderStartDate(false)
                setStartDate(dateTime);
            } else {
                setIsPlaceholderEndDate(false);
                setEndDate(dateTime);
            }
            setToggleCheckBox(false)
        }
    }
    const Aray = [
        {
            'Name': 'BNB',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'ETH',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'BNB',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'ETH',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'BNB',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'ETH',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        }
    ]
    useEffect(() => {
        props?.getTransactionsList('deposit');

    }, [])
    
    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };
    const DATA = [
        {
            img: ImageIcons.Twitter,
            text: 'TWTR',
            text1: 'Twitter Inc.',
            text2: '$63.98',
            img1: ImageIcons.Chart,


        },
        {
            img: ImageIcons.Google,
            text: 'GOOGL ',
            text1: 'Alphabet Inc.',
            text2: '$2.84k',
            img1: ImageIcons.Chart1,

        },
        {
            img: ImageIcons.Microsoft,
            text: 'MSFT',
            text1: 'Microsoft',
            text2: '$302.1',
            img1: ImageIcons.Chart2,

        },
        {
            img: ImageIcons.Nike,
            text: 'NIKE',
            text1: 'Nike, Inc.',
            text2: '$169.8',
            img1: ImageIcons.Chart3,


        },
        {
            img: ImageIcons.Spotify,
            text: 'SPOT',
            text1: 'Spotify',
            text2: '$226,9',
            img1: ImageIcons.Chart4,

        },

    ]
    const renderCategory = (riskId, title) => {
        var riskCategoryName = title;
        if (title == 'Withdraw') { riskCategoryName = 'Withdrawal' }
        if (title == 'Refferal') { riskCategoryName = 'Refer N earn' }
        if (title == 'adminProfit') { riskCategoryName = 'Daily Profits' }

        if (riskId == '645fdc36d05f11efb18684b3') { riskCategoryName = 'Agressive Plan' }
        if (riskId == '645fdc58d05f11efb18684b4') { riskCategoryName = 'Conservative Plan' }
        return riskCategoryName;
    };

    const renderItem = ({ item, index }) => {
        
        return (
            <View>
                <View style={tw`flex-row justify-around p-3`}>
                    <View style={tw`flex-row w-5/12`}>
                        <LinearGradient colors={['#1C162E', '#1C162E']} start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3]  `}
                        >
                            {(popularOperation == 'deposit') &&
                                <View style={tw`flex-row `}>

                                    <Image
                                        source={ImageIcons.wallet}
                                        style={[tw`h-6 w-6  `, { tintColor: 'white' }]}
                                    >
                                    </Image>
                                </View>
                            }
                            {(popularOperation == 'Withdraw') &&
                                <View style={tw`flex-row `}>

                                    <Image
                                        source={ImageIcons.withdraw_white}
                                        style={[tw`h-6 w-6  `, { tintColor: 'white' }]}
                                    >
                                    </Image>
                                </View>
                            }
                            {(popularOperation == 'Refferal') &&
                                <View style={tw`flex-row `}>

                                    <Image
                                        source={ImageIcons.referral_white}
                                        style={[tw`h-6 w-6  `, { tintColor: 'white' }]}
                                    >
                                    </Image>
                                </View>
                            }
                            {(popularOperation == 'Profit') &&
                                <View style={tw`flex-row `}>

                                    <Image
                                        source={ImageIcons.profit_white}
                                        style={[tw`h-6 w-6  `, { tintColor: 'white' }]}
                                    >
                                    </Image>
                                </View>
                            }
                        </LinearGradient>
                        <View>
                            <Text style={tw`font-bold text-'#1C162E' capitalize text-sm ml-5`}>{renderCategory(item.riskCategory, item.type)}</Text>
                            <Text style={tw`text-'#1C162E' ml-5 text-2.5`}>{moment(item.createdAt)?.format('lll')}</Text>
                        </View>

                    </View>

                    {
                        (item.type == 'adminProfit') &&
                        <View style={tw`h-8 w-12 w-1/12`}>
                            {/* <Text style={tw`text-[#C6C4CA] text-2`}>{item.distributionId.transaction_type}</Text>
                            <Text style={tw`text-[#E33A61] text-3`}>{item.distributionId.percentage}</Text> */}
                        </View>
                    }
                    {
                        (item.type == 'deposit') &&
                        <View style={tw`h-4 mt-2 ml-4 w-1.7/12`}>
                            <Text style={tw`text-[#E33A61] text-2.5 ${(item.status >= 100 && item.status < 400) ? 'text-[#002662]' : 'text-[#ff9900]'}`}>{(item?.status >= 100 && item?.status < 400) ? 'Completed' : (item?.status == 404) ? 'Deduction' : 'Pending'}</Text>
                        </View>
                    }

                    {
                        (item.type == 'withdraw') &&
                        <View style={tw`h-4 mt-2 ml-4 w-1.7/12`}>
                            <Text style={tw` text-2.5 ${(item.status == 2) ? 'text-[#002662]' : 'text-[#ff9900]'} `}>{(item.status == 2) ? 'Completed' : 'Pending'}</Text>
                        </View>
                    }

                    {
                        (item.type == 'Refferal') &&
                        <View style={tw`h-4 mt-2 ml-6 w-3/12`}>
                            <Text style={tw`text-[#002662] text-3`}>{'Joined'}</Text>
                        </View>
                    }

                    <View style={tw`bg-gray-100 h-8 items-center text-center justify-center rounded-[9] w-2.5/12`}>
                        <Text style={tw`text-3 text-[#FF3A79]`}>${parseFloat(item.amount).toFixed(2)}</Text>
                    </View>
                </View>
            </View>

        )
    }


    const renderItem1 = ({ item, index }) => {
        return (
            <TouchableOpacity 
            // onPress={() => props.navigation.navigate("About", { id: item._id })}
            >

                <View style={tw`text-white mt-3.5 mx-6 w-11/12 rounded-2xl `}>
                    <View style={tw`flex flex-row `}>
                        <View style={tw`w-2.5/12 mb-2 `}>
                            <Image source={item.img} style={tw`  mt-3 w-12 h-12`} />
                        </View>
                        <View style={tw`flex flex-column w-2.5/12 mt-5 `}>
                            <Text style={tw`text-base font-bold text-black ml-2 font-[4]`}>{item.text}</Text>
                            <Text style={tw`text-xs text-black ml-2 font-[1] mt--1`}>{item.text1}</Text>
                        </View>
                        <View style={tw`w-4/12 mt-2 ml-2`}>
                            <Image source={item.img1} style={tw`ml-3  mt-3 w-17 h-9`} />
                        </View>
                        <View style={tw`flex flex-column w-2.5/12 mt-5`}>
                            <Text style={tw`text-base  font-bold text-black ml-2 font-[3]`}>{item.text2}</Text>
                            <Text style={tw`text-xs text-black ml-2 font-[1] mt--1`}>{item.text2}</Text>
                        </View>
                    </View>
                </View>

            </TouchableOpacity>
        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>

            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Portfolio'} />

            {/* <View style={tw`mt-2`}>
                <Text style={tw`font-bold mx-7 text-sm`}>Popular Operation</Text>
            </View>

            <View style={tw`flex-row justify-center justify-evenly p-2 `}>
                <TouchableOpacity onPress={() => {
                    setPopularOperation("deposit");
                    props?.getTransactionsList('deposit');
                }} style={tw` justify-center items-center ${(popularOperation == 'deposit') ? 'bg-[#002662]' : 'bg-white'}   w-2.5/12 h-20 rounded-[3]`}>
                    {(popularOperation == 'deposit') ?
                        <Image
                            source={ImageIcons.wallet}
                            style={tw`h-7 w-7  `}
                        >
                        </Image>
                        :
                        <Image
                            source={ImageIcons.depost_red}
                            style={tw`h-7 w-7  `}
                        >
                        </Image>
                    }

                    <Text style={tw` ${(popularOperation == 'deposit') ? 'text-white' : 'text-black'} text-xs font-bold mt-3`}>Investment</Text>

                </TouchableOpacity>
                <TouchableOpacity onPress={() => {
                    setPopularOperation("Withdraw");
                    props?.getTransactionsList('withdraw');
                }} style={tw` justify-center items-center bg-white w-2.5/12 h-20 ${(popularOperation == 'Withdraw') ? 'bg-[#002662]' : 'bg-white'} rounded-[3] `}>
                    {(popularOperation == 'Withdraw') ?
                        <Image
                            source={ImageIcons.withdraw_white}
                            style={tw`h-7 w-7`}


                        />
                        :
                        <Image
                            source={ImageIcons.withdraw_red}
                            style={tw`h-7 w-7`}


                        />
                    }
                    <Text style={tw` text-xs font-bold Profit mt-3 ${(popularOperation == 'Withdraw') ? 'text-white' : 'text-black'}`} >Withdrawal</Text>

                </TouchableOpacity>
                <TouchableOpacity onPress={() => {
                    setPopularOperation("Refferal");
                    props?.getTransactionsList('Refferal');
                }} style={tw` justify-center items-center ${(popularOperation == 'Refferal') ? 'bg-[#002662]' : 'bg-white'}  w-2.5/12 h-20 shadow-2xl shadow-[#7D64FF] rounded-[3]`}>
                    {(popularOperation == 'Refferal') ?

                        <Image
                            source={ImageIcons.referral_white}
                            style={tw`h-7 w-7  `}

                        />
                        :
                        <Image
                            source={ImageIcons.referral_red}
                            style={tw`h-7 w-7  `}

                        />

                    }


                    <Text style={tw` text-xs font-bold mt-3 text-center ${(popularOperation == 'Refferal') ? 'text-white' : 'text-black'}`}>Refer N earn</Text>

                </TouchableOpacity>
                <TouchableOpacity onPress={() => {
                    setPopularOperation("Profit");
                    props?.getTransactionsList('adminProfit')
                }} style={tw` justify-center items-center ${(popularOperation == 'Profit') ? 'bg-[#002662]' : 'bg-white'} shadow-2xl shadow-[#7D64FF] w-2.5/12 h-20 rounded-[3]`}>
                    {(popularOperation == 'Profit') ?
                        <Image
                            source={ImageIcons.profit_white}
                            style={tw`h-7 w-7  `}

                        /> :
                        <Image
                            source={ImageIcons.profit_red}
                            style={tw`h-7 w-7  `}

                        >
                        </Image>


                    }
                    <Text style={tw` text-xs font-bold mt-3 ${(popularOperation == 'Profit') ? 'text-white' : 'text-black'}`}>Daily Profits</Text>

                </TouchableOpacity>
            </View> */}

            <ScrollView style={tw` mb-10 mt-10`}>
                {/* <View style={tw`flex-row justify-between w-11/12`}>
                    <Text style={tw`font-bold mx-7 text-sm `}>Transactions</Text>
                    <TouchableOpacity onPress={() => setShow(s => !s)}>
                        <Image source={ImageIcons.filter_icon} style={[tw`h-5 w-5 mt-2`, { tintColor: isPlaceholderStartDate ? '#000000' : '#7460FF' }]} />

                    </TouchableOpacity>

                </View> */}
                {show == true &&
                    <View style={tw`flex-row justify-between w-5.5/12 mx-6`}>
                        <Text style={tw`text-sm text-[#D3D3D3]`}>From</Text>
                        <Text style={tw`text-sm text-[#D3D3D3]`}>To</Text>
                    </View>
                }
                <DateTimePickerModal
                    isVisible={showDatePicker}
                    mode="date"
                    onConfirm={onChangeDate}
                    onCancel={() => setShowDatePicker(false)}
                    minimumDate={moment(new Date()).toDate()}
                    maximumDate={moment().add(1, 'month').toDate()}
                />
                {show == true &&
                    <View style={tw`flex-1 flex-row justify-evenly items-center w-11.7/12 mt-3`}>
                        {(startDate == undefined) ?
                            <DatePickerButton
                                id={"startDate"}
                                placeholder={"Start Date"}
                                isShowPlaceholder={isPlaceholderStartDate}
                                iconTintColor={'#6BBD46'}
                                value={"Start Date"}
                                theme="white"
                                name="startDate"
                                customStyle={{ borderColor: (submitted == true && startDate == undefined) ? 'red' : 'none', borderWidth: (submitted == true && startDate == undefined) ? 1 : 0 }}
                                onPickDate={() => { setShowDatePicker(!showDatePicker); setDatePickerFor("startDate"); }}
                            />
                            :
                            <DatePickerButton
                                id={"startDate"}
                                placeholder={"Start Date"}
                                isShowPlaceholder={isPlaceholderStartDate}
                                value={moment(startDate).format("MM/DD/YYYY")}
                                iconTintColor={'#6BBD46'}
                                theme="white"
                                name="startDate"
                                customStyle={{ borderColor: (submitted == true && startDate == undefined) ? 'red' : 'none', borderWidth: (submitted == true && startDate == undefined) ? 1 : 0 }}
                                onPickDate={() => { setShowDatePicker(!showDatePicker); setDatePickerFor("startDate"); }}
                            />
                        }

                        {(endtDate == undefined) ?
                            < DatePickerButton
                                id={"endDate"}
                                placeholder={"End Date"}
                                isShowPlaceholder={isPlaceholderEndDate}
                                value={"End Date"}
                                iconTintColor={'#6BBD46'}
                                theme="white"
                                customStyle={{ borderColor: (submitted == true && endtDate == undefined) ? 'red' : 'none', borderWidth: (submitted == true && endtDate == undefined) ? 1 : 0 }}
                                onPickDate={() => { setDatePickerFor("endDate"); setShowDatePicker(true); }}
                            />
                            :
                            < DatePickerButton
                                id={"endDate"}
                                placeholder={"End Date"}
                                isShowPlaceholder={isPlaceholderEndDate}
                                value={moment(endtDate).format("MM/DD/YYYY")}
                                iconTintColor={'#6BBD46'}
                                theme="white"
                                customStyle={{ borderColor: (submitted == true && endtDate == undefined) ? 'red' : 'none', borderWidth: (submitted == true && endtDate == undefined) ? 1 : 0 }}
                                onPickDate={() => { setDatePickerFor("endDate"); setShowDatePicker(true); }}
                            />
                        }
                        <TouchableOpacity onPress={() => setShow(false)}>
                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3.5] `}
                            >
                                <Text style={tw`text-white text-sm`}> Go </Text>
                            </LinearGradient></TouchableOpacity>

                    </View>

                }

                <View>


                    <FlatList
                        data={DATA}
                        renderItem={renderItem1}
                        keyExtractor={item => item?.id}
                        ListEmptyComponent={renderEmptyComponent}

                    />

                </View>

            </ScrollView>



            <CustomBottomTab
                {...props} isActive={true} selected={"Portfolio"} />
        </KeyboardAvoidingView>

    )
}

export default Portfolio;