import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image, ImageBackground } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
// import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';

import LinearGradient from 'react-native-linear-gradient';
import { getTransactionsList } from '../../redux/actions/Coupon';
import { useFocusEffect } from '@react-navigation/native';


const Wallet = (props) => {

    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate
    const [selectedOption, setSelectedOption] = useState('Deposit');
    const [activeTab, setActiveTab] = useState(0);
    const transactionList = props?.transactionStock
    
    console.log('transactionList',transactionList)

    const Aray = [
        {
            'Name': 'BNB',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'ETH',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'BNB',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'ETH',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'BNB',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        },
        {
            'Name': 'ETH',
            'Date': 'sep 26. 10:34',
            'price': '399.00'
        }
    ]
    useEffect(() => {
        // props?.getTransactionsList('deposit');
        // props?.walletBalance();
        // props?.getDepositDetail();
        // props.getTransactionsListStock({
        //     value: 'deposit'
        // })

    }, [])

     useFocusEffect(
        React.useCallback(() => {
            props?.walletBalance();
            props?.getDepositDetail();
            props.getTransactionsListStock({
                value: 'deposit'
            })
        }, [])
      );


    const Tab = ({ label, active, onPress }) => {
        return (
            <TouchableOpacity
                onPress={onPress}
                style={tw`flex-1 py-2 items-center border-r border-gray-300 ${active ? 'bg-[#E0F64B] rounded-[3]' : 'bg-white'}`}
            >
                <Text style={tw`${active ? 'text-black font-bold' : 'text-gray-600'}`}>{label}</Text>
            </TouchableOpacity>
        );
    };


    const tabs = [
        { label: 'Deposit' },
        { label: 'Withdraw' },
        { label: 'Invest' },
    ];

    const handleTabPress = (index) => {
        setActiveTab(index);
        if (index == 0) {
            props?.getTransactionsListStock({
                value: 'deposit'
            });
        } else if (index == 2) {
            props?.getTransactionsListStock({
                value: 'invest'
            });
        } else if (index == 1) {
            props?.getTransactionsListStock({
                value: 'withdraw'
            });
        }  
    };

    const handleOptionSelect = (option) => {
        setSelectedOption(option);
    };

    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };

    const DATA = [
        {
            img: ImageIcons.downarrow_img,
            text: 'Deposit',
            text1: '24-08-2023 | 10:04 AM',
            text2: '$2,782.06',
            text3: 'Completed',
            img1: ImageIcons.Chart,


        },
        {
            img: ImageIcons.downarrow_img,
            text: 'Deposit ',
            text1: '24-08-2023 | 10:04 AM',
            text2: '$2,782.06',
            text3: 'Completed',
            img1: ImageIcons.Chart1,

        },
        {
            img: ImageIcons.downarrow_img,
            text: 'Deposit',
            text1: '24-08-2023 | 10:04 AM',
            text2: '$2,782.06',
            text3: 'Completed',
            img1: ImageIcons.Chart2,

        },
        {
            img: ImageIcons.downarrow_img,
            text: 'Deposit',
            text1: '24-08-2023 | 10:04 AM',
            text2: '$2,782.06',
            text3: 'Completed',
            img1: ImageIcons.Chart3,


        },
        {
            img: ImageIcons.downarrow_img,
            text: 'Deposit',
            text1: '24-08-2023 | 10:04 AM',
            text2: '$2,782.06',
            text3: 'Completed',
            img1: ImageIcons.Chart3,


        },
        {
            img: ImageIcons.downarrow_img,
            text: 'Deposit',
            text1: '24-08-2023 | 10:04 AM',
            text2: '$2,782.06',
            text3: 'Completed',
            img1: ImageIcons.Chart3,


        },

    ]


   
    const renderItem1 = ({ item, index }) => {
        return (
            <View style={tw` w-12/12 rounded-2xl border-2px flex items-center shadow-sm mt-2 shadow-[#CEEBFF]  flex-row p-2   `}>

                <View style={tw` w-2/12 `}>
                    <ImageBackground source={ImageIcons.bg} style={tw` items-center justify-center  h-10 w-10  rounded-full`}>
                        <Image source={ImageIcons.downarrow_img} style={tw` h-8 w-8  rounded-full`} />
                    </ImageBackground>
                </View>
                <View style={tw`w-6/12`}>
                    {item?.title === "wallet_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>Wallet Amount</Text>
                    )}
                    {item?.title === "low_risk_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>Low Risk Investment</Text>
                    )}
                    {item?.title === "high_risk_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>High Risk Investment</Text>
                    )}
                    {!["wallet_amount", "low_risk_amount", "high_risk_amount"].includes(item?.title) && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>{item?.title}</Text>
                    )}
                    <Text style={tw`text-sm font-bold text-black font-[1]`}>{moment(item?.created_at)?.format('lll')}</Text>
                </View>
                <View style={tw` w-4/12 items-end `}>
                <Text style={tw`text-sm  font-bold text-black  font-[4]`}>{item?.amount}</Text>
                    <Text style={tw`text-sm     font-[6] text-[#13C08C] font-bold`}>Completed</Text>
                </View>
            </View>
        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>
            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Wallet'} />
            <ScrollView style={tw`mb-22  `}>
                <View style={tw`flex items-center   `}>
                    <View style={tw` w-11/12 bg-[#171717] items-start p-5 shadow-[#7D64FF]  shadow-2xl rounded-[5] mt-4`}>
                        {/* <ImageBackground source={ImageIcons.image} style={tw`h-35 w-11/12`}> */}

                        <Text style={tw`text-[#B8B8B8] text-left font-bold text-3.5 `}>Available Balance</Text>
                        <View style={tw`flex-row my-1`}>
                            {props?.getwalletBalance != undefined ?
                                <Text style={tw`text-[#2AEFB4] text-left font-bold text-9 `}>$ {parseFloat(props?.getwalletBalance?.amount).toFixed(2)}</Text>
                                :
                                <Text style={tw`text-[#2AEFB4] text-left font-bold text-9`}>$ </Text>
                            }
                        </View>
                        <TouchableOpacity style={tw`flex-row bg-[#2AEFB4] h-9 w-30 flex items-center justify-center my-1  rounded-[3]`}
                         onPress={() => props?.navigation?.navigate("Deposite")}
                        >
                            <Text style={tw`text-black font-bold text-3 `}>Topup Balance</Text>
                        </TouchableOpacity>

                    </View>
                    {/* </View> */}

                    <View style={tw`flex-row w-12/12 justify-around items-center  mt-4`}>

                        <View style={tw`h-18 w-26 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px  `}>
                            <Image source={ImageIcons.Deposit} resizeMode='contain' style={tw`h-6 w-6`} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Deposite")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}>Deposit</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={tw`h-18 w-26 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px  `}>
                            <Image source={ImageIcons.Deposit} resizeMode='contain' style={tw`h-6 w-6`} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Withdraw")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}>Withdraw</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={tw`h-18 w-26 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px  `}>
                            <Image source={ImageIcons.Deposit} resizeMode='contain' style={tw`h-6 w-6`} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Invest")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}>Invest</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={tw`w-11/12 mt-4`}>
                        <Text style={tw`text-[#000000] text-base text-sm font-bold`}> Recent Transactions</Text>
                    </View>
                    <View style={tw` w-11/12 mt-4 flex-row border border-gray-300 rounded-[3] overflow-hidden`}>
                    {tabs.map((tab, index) => (
                            <Tab
                                key={index}
                                label={tab.label}
                                active={index === activeTab}
                                onPress={() => handleTabPress(index)}
                            />
                        ))}
                    </View>

                    {/* <View style={tw` w-11/12  mt-4`}>
                        {tabs[activeTab].label === 'Deposit' && (
                            <FlatList
                                data={DATA}
                                renderItem={renderItem1}
                                keyExtractor={item => item?.id}
                            />
                        )}

                        {tabs[activeTab].label === 'Withdraw' && (
                            <FlatList
                                data={DATA}
                                renderItem={renderItem1}
                                keyExtractor={item => item?.id}
                            />
                        )}

                        {tabs[activeTab].label === 'Invest' && (
                            <FlatList
                                data={DATA}
                                renderItem={renderItem1}
                                keyExtractor={item => item?.id}
                            />
                        )}
                    </View> */}
                    <View style={tw` w-11/12 mt-4  `} >
                        <FlatList
                            data={transactionList?.reverse()}
                            renderItem={renderItem1}
                            keyExtractor={item => item?.id}
                            ListEmptyComponent={renderEmptyComponent}
                        />
                    </View>
                </View>
            </ScrollView>

            <CustomBottomTab
                {...props} isActive={true} selected={"Wallet"} />
        </KeyboardAvoidingView>

    )
}

export default Wallet;