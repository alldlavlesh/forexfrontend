import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
// import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import { getTransactionsList } from '../../redux/actions/Coupon';

const Portfolio = (props) => {

    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");



    //startDate, endDate
    const stocklist = props?.getStocklist1
    




    const onChangeDate = (dateTime) => {
        if (dateTime) {
            setShowDatePicker(false)
            if (datePickerFor === "startDate") {
                setIsPlaceholderStartDate(false)
                setStartDate(dateTime);
            } else {
                setIsPlaceholderEndDate(false);
                setEndDate(dateTime);
            }
            setToggleCheckBox(false)
        }
    }

    useEffect(() => {
        props?.getstocklist({
            value: 'stock'
        });

    }, [])
    
    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };


    // const [show, setShow] = useState(false);
    const [activeTab, setActiveTab] = useState(0);





    const Tab = ({ label, active, onPress }) => {
        return (
            <TouchableOpacity
                onPress={onPress}
                style={tw`flex-1 py-2 items-center border-r border-gray-300 ${active ? 'bg-[#E0F64B] rounded-[3]' : 'bg-white'}`}
            >
                <Text style={tw`${active ? 'text-black font-bold' : 'text-gray-600'}`}>{label}</Text>
            </TouchableOpacity>
        );
    };


    const tabs = [
        { label: 'Stock' },
        // { label: 'Commodity' },
        { label: 'Forex' },
    ];

    const handleTabPress = (index) => {
        setActiveTab(index);
        if (index == 0) {
            props?.getstocklist({
                value: 'stock'
            });
        } else if (index == 2) {
            props?.getstocklist({
                value: 'commodity'
            });
        } else if (index == 1) {
            props?.getstocklist({
                value: 'forex'
            });
        }
    };




    const renderCategory = (riskId, title) => {
        var riskCategoryName = title;
        if (title == 'Withdraw') { riskCategoryName = 'Withdrawal' }
        if (title == 'Refferal') { riskCategoryName = 'Refer N earn' }
        if (title == 'adminProfit') { riskCategoryName = 'Daily Profits' }

        if (riskId == '645fdc36d05f11efb18684b3') { riskCategoryName = 'Agressive Plan' }
        if (riskId == '645fdc58d05f11efb18684b4') { riskCategoryName = 'Conservative Plan' }
        return riskCategoryName;
    };

    const renderItem1 = ({ item, index }) => {
        return (

            <TouchableOpacity
            // onPress={() => props.navigation.navigate("About", { id: item._id })}
            >
                <View style={tw`text-white  w-12/12 rounded-2xl flex justify-center flex-row items-center mt-4 `}>                    
                        <View style={tw` w-6/12  justify-center items-center `}>
                            <Text style={tw`text-base font-bold text-black  font-[4]`}>{item.product_name}</Text>                            
                        </View>

                        <View style={tw` w-6/12 justify-center items-center  `}>
                            <Text style={tw`text-base  font-bold text-black font-[3]`}>{item.quantity}</Text>
                            <Text style={tw`text-xs font-bold text-black  font-[1]`}>{item.price}</Text>
                        </View>                   
                </View>

            </TouchableOpacity>
        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>
            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Portfolio'} />

            <ScrollView style={tw`mb-22`}>
                <View style={tw`flex justify-center items-center mt-4 `}>
                    <View style={tw` w-11/12 bg-[#171717] items-start p-5 shadow-[#7D64FF]  shadow-2xl rounded-[5] `}>
                        <Text style={tw`text-[#B8B8B8] text-left font-bold text-3.5  ml-5`}>Portfolio Balance</Text>
                        <View style={[tw`flex-row items-center w-12/12  `, {justifyContent: 'space-around'}]}>
                            <View style={[tw`flex-col`]}>
                                <View>
                                    {props?.getwalletBalance != undefined ?
                                        <Text style={tw`text-[#2AEFB4]  font-bold text-10 `}>$ {props?.getwalletBalance?.amount}</Text>
                                        :
                                        <Text style={tw`text-[#2AEFB4]  font-bold text-10`}>$ 0.000</Text>
                                    }
                                </View>
                                
                            </View>
                            <View style={tw` `}>
                                <TouchableOpacity style={tw`flex-row bg-[#2AEFB4] flex justify-evenly items-center h-7   w-20 rounded-[3]`}>
                                    <Image source={ImageIcons.Fill} resizeMode='contain' style={tw`h-2 w-2`} />
                                    <Text style={tw`text-[#F61C7A] font-bold text-3`}>18.05%</Text>
                                </TouchableOpacity>
                            </View>

                        </View>
                        <Text style={tw`text-[#B8B8B8] text-left font-bold text-5 ml-5`}>$ 1208.24(Gain)</Text>

                    </View>
                    <View style={tw` w-12/12  flex justify-center items-center mt-4`} >
                        <View style={tw` w-11/12   flex-row border border-gray-300 rounded-[3] overflow-hidden`}>
                            {tabs.map((tab, index) => (
                                <Tab
                                    key={index}
                                    label={tab.label}
                                    active={index === activeTab}
                                    onPress={() => handleTabPress(index)}
                                />
                            ))}
                        </View>
                        <View style={tw` w-11/12  `} >
                            <FlatList
                                data={stocklist}
                                renderItem={renderItem1}
                                keyExtractor={item => item?.id}

                            />
                        </View>
                    </View>
                </View>
            </ScrollView>
            <CustomBottomTab
                {...props} isActive={true} selected={"Portfolio"} />
        </KeyboardAvoidingView>

    )
}

export default Portfolio;