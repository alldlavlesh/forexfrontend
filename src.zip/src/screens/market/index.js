import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
// import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';

import LinearGradient from 'react-native-linear-gradient';
import { getTransactionsList } from '../../redux/actions/Coupon';

const Market = (props) => {

    const [show, setShow] = useState(false);
    const [activeTab, setActiveTab] = useState(0);

    useEffect(() => {
        props?.stockListing({
            value: 'stock'
        });

    }, [])
    

    const Tab = ({ label, active, onPress }) => {
        return (
            <TouchableOpacity
                onPress={onPress}
                style={tw`flex-1 py-2 items-center border-r border-gray-300 ${active ? 'bg-[#E0F64B] rounded-[3]' : 'bg-white'}`}
            >
                <Text style={tw`${active ? 'text-black font-bold' : 'text-gray-600'}`}>{label}</Text>
            </TouchableOpacity>
        );
    };

    const tabs = [
        { label: 'Stock' },
        { label: 'Forex' },
        { label: 'Commodity' },
    ];

    const handleTabPress = (index) => {

        setActiveTab(index);
        if (index == 0) {
            props?.stockListing({
                value: 'stock'
            });
        } else if (index == 2) {
            props?.stockListing({
                value: 'Commodity'
            });
        } else if (index == 1) {
            props?.stockListing({
                value: 'forex'
            });
        }
    };

    const DATA = [
        {
            img: ImageIcons.Twitter,
            text: 'TWTR',
            text1: 'Twitter Inc.',
            text2: '$63.98',
            img1: ImageIcons.Chart,


        },
        {
            img: ImageIcons.Google,
            text: 'GOOGL ',
            text1: 'Alphabet Inc.',
            text2: '$2.84k',
            img1: ImageIcons.Chart1,

        },
        {
            img: ImageIcons.Microsoft,
            text: 'MSFT',
            text1: 'Microsoft',
            text2: '$302.1',
            img1: ImageIcons.Chart2,

        },
        {
            img: ImageIcons.Nike,
            text: 'NIKE',
            text1: 'Nike, Inc.',
            text2: '$169.8',
            img1: ImageIcons.Chart3,


        },
        {
            img: ImageIcons.Spotify,
            text: 'SPOT',
            text1: 'Spotify',
            text2: '$226,9',
            img1: ImageIcons.Chart4,

        },

    ]

    const renderItem = ({ item, index }) => {
        return (
            <>
                {activeTab == 0 &&
                    <TouchableOpacity onPress={() => props?.navigation?.navigate("BuySell", { item: item, value: "stock" })}
                    // onPress={() => props.navigation.navigate("About", { id: item._id })}
                    >

                        <View style={tw`text-white  w-12/12 rounded-2xl `}>
                            <View style={tw`flex flex-row justify-between items-center p-2  `}>
                                {/* <View style={tw`w-2/12 mb-2 ml--2 `}>
                                    <Image source={ImageIcons.Twitter} style={tw`  mt-3 w-12 h-12`} />
                                </View> */}

                                <View style={tw`w-4/12  flex justify-center items-center `}>
                                    <Text style={tw`text-base font-bold text-black  font-[4]`}>{item.symbol}</Text>
                                    <Text style={tw`text-xs text-black font-[1]`}>{item.name}</Text>
                                </View>

                                <View style={tw`w-4/12  flex justify-center items-center `}>
                                    {item.changesPercentage < 0 ?
                                        <Image source={ImageIcons.Chart3} style={tw`   w-17 h-9`} />
                                        :
                                        <Image source={ImageIcons.Chart4} style={tw`   w-17 h-9`} />
                                    }
                                </View>
                                <View style={tw`w-4/12  flex justify-center items-center  `}>
                                    <Text style={tw`text-base  font-bold text-black  font-[3]`}>${item.price.toFixed(6)}</Text>
                                    {item.changesPercentage < 0 ?
                                        <TouchableOpacity style={tw`flex-row text-green  flex items-center   `}>
                                            <Image source={ImageIcons.dropdown} resizeMode='contain' style={[tw`h-4 w-2 `, { tintColor: '#ffa500' }]} />
                                            <Text style={[tw`text-black font-bold text-3.5 `, { color: '#ffa500' }]}>{item.changesPercentage.toFixed(2)}%</Text>
                                        </TouchableOpacity>
                                        :

                                        <TouchableOpacity style={tw`flex-row text-green flex items-center  `}>
                                            <Image source={ImageIcons.Fill} resizeMode='contain' style={[tw`h-4 w-2 `, { tintColor: '#3cb371' }]} />
                                            <Text style={[tw`text-black font-bold text-3.5 `, { color: '#3cb371' }]}>{item.changesPercentage.toFixed(2)}% </Text>
                                        </TouchableOpacity>
                                        // <View style={tw`flex justify-center text-center p-1 bg-green-500 `}>
                                        //     <Text style={tw`text-xs text-white font-[1] text-right`}>{item.changesPercentage}%</Text>
                                        // </View>
                                    }

                                </View>
                            </View>
                        </View>

                    </TouchableOpacity>
                }
                {activeTab == 2 &&
                    <TouchableOpacity onPress={() => props?.navigation?.navigate("BuySell", { item: item, value: "commodity" })}
                    // onPress={() => props.navigation.navigate("About", { id: item._id })}
                    >

                        <View style={tw`text-white mx-6 w-11/12 rounded-2xl `}>
                            <View style={tw`flex flex-row justify-between mt-5 p-3`}>
                                <View style={tw`w-2/12 mb-2 ml--2 `}>
                                    <Image source={ImageIcons.Twitter} style={tw`  mt-3 w-12 h-12`} />
                                </View>

                                <View style={tw`flex flex-column w-3/12 mt-3.5 `}>
                                    <Text style={tw`text-base font-bold text-black  font-[4]`}>{item.symbol}</Text>
                                    <Text style={tw`text-xs text-black font-[1]`}>{item.name}</Text>
                                </View>

                                <View style={tw` w-3.5/12 mb-2 `}>
                                    {item.changesPercentage < 0 ?
                                        <Image source={ImageIcons.Chart3} style={tw`  mt-4 w-17 h-9`} />
                                        :
                                        <Image source={ImageIcons.Chart4} style={tw`  mt-4 w-17 h-9`} />
                                    }
                                </View>
                                <View style={tw`flex flex-column w-2.5/12 mt-3.5 mr-2 `}>
                                    <Text style={tw`text-base  font-bold text-black  font-[3]`}>${item.price.toFixed(2)}</Text>
                                    {item.changesPercentage < 0 ?
                                        <TouchableOpacity style={tw`flex-row text-green  h-9 w-24 `}>
                                            <Image source={ImageIcons.Fill} resizeMode='contain' style={[tw`h-4 w-2 my-1`, { tintColor: '#ffa500' }]} />
                                            <Text style={[tw`text-black font-bold text-3.5 ml-2  my-.5`, { color: '#ffa500' }]}>{item.changesPercentage.toFixed(2)}%</Text>
                                        </TouchableOpacity>
                                        :

                                        <TouchableOpacity style={tw`flex-row text-green  h-9 w-24`}>
                                            <Image source={ImageIcons.Fill} resizeMode='contain' style={[tw`h-4 w-2 my-1`, { tintColor: '#3cb371' }]} />
                                            <Text style={[tw`text-black font-bold text-3.5 ml-2  my-.5`, { color: '#3cb371' }]}>{item.changesPercentage.toFixed(2)}%</Text>
                                        </TouchableOpacity>
                                        // <View style={tw`flex justify-center text-center p-1 bg-green-500 `}>
                                        //     <Text style={tw`text-xs text-white font-[1] text-right`}>{item.changesPercentage}%</Text>
                                        // </View>
                                    }

                                </View>
                            </View>
                        </View>

                    </TouchableOpacity>
                }

                {activeTab == 1 &&
                    <TouchableOpacity onPress={() => props?.navigation?.navigate("BuySell", { item: item, value: "forex" })}
                    // onPress={() => props.navigation.navigate("About", { id: item._id })}
                    >

                        <View style={tw`text-white  w-12/12 rounded-2xl `}>
                            <View style={tw`flex flex-row justify-between items-center p-2  `}>
                                {/* <View style={tw`w-2/12 mb-2 ml--2 `}>
                                    <Image source={ImageIcons.Twitter} style={tw`  mt-3 w-12 h-12`} />
                                </View> */}

                                <View style={tw`w-4/12  flex justify-center items-center `}>
                                    <Text style={tw`text-base font-bold text-black  font-[4]`}>{item.symbol}</Text>
                                    <Text style={tw`text-xs text-black font-[1]`}>{item.name}</Text>
                                </View>

                                <View style={tw`w-4/12  flex justify-center items-center `}>
                                    {item.changesPercentage < 0 ?
                                        <Image source={ImageIcons.Chart3} style={tw`   w-17 h-9`} />
                                        :
                                        <Image source={ImageIcons.Chart4} style={tw`   w-17 h-9`} />
                                    }
                                </View>
                                <View style={tw`w-4/12  flex justify-center items-center  `}>
                                    <Text style={tw`text-base  font-bold text-black  font-[3]`}>${item.price.toFixed(6)}</Text>
                                    {item.changesPercentage < 0 ?
                                        <TouchableOpacity style={tw`flex-row text-green  flex items-center   `}>
                                            <Image source={ImageIcons.dropdown} resizeMode='contain' style={[tw`h-4 w-2 `, { tintColor: '#ffa500' }]} />
                                            <Text style={[tw`text-black font-bold text-3.5 `, { color: '#ffa500' }]}>{item.changesPercentage.toFixed(2)}%</Text>
                                        </TouchableOpacity>
                                        :

                                        <TouchableOpacity style={tw`flex-row text-green flex items-center  `}>
                                            <Image source={ImageIcons.Fill} resizeMode='contain' style={[tw`h-4 w-2 `, { tintColor: '#3cb371' }]} />
                                            <Text style={[tw`text-black font-bold text-3.5 `, { color: '#3cb371' }]}>{item.changesPercentage.toFixed(2)}% </Text>
                                        </TouchableOpacity>
                                        // <View style={tw`flex justify-center text-center p-1 bg-green-500 `}>
                                        //     <Text style={tw`text-xs text-white font-[1] text-right`}>{item.changesPercentage}%</Text>
                                        // </View>
                                    }

                                </View>
                            </View>
                        </View>
                    </TouchableOpacity>
                }
            </>
        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>
            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} Search={false} name={'Market'} />
            <ScrollView style={tw` mb-22`}>

                <View style={tw` w-12/12  flex justify-center items-center mt-4`} >
                    <View style={tw` w-11/12   flex-row border border-gray-300 rounded-[3] overflow-hidden`}>
                        {tabs.map((tab, index) => (
                            <Tab
                                key={index}
                                label={tab.label}
                                active={index === activeTab}
                                onPress={() => handleTabPress(index)}
                            />
                        ))}
                    </View>
                    <View style={tw` w-11/12  `} >
                        <FlatList
                            data={props?.getStocklist}
                            renderItem={renderItem}
                            keyExtractor={item => item?.id}

                        />
                    </View>

                </View>

            </ScrollView>

            <CustomBottomTab
                {...props} isActive={true} selected={"Market"} />
        </KeyboardAvoidingView>

    )
}

export default Market;