import React, { useRef, useState } from 'react';
import { Text, View, ScrollView, Alert, StatusBar, LogBox, KeyboardAvoidingView, Platform, Keyboard, Modal, Button, Image, ImageBackground, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, ImageIcons, CommonStrings } from '../../common'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import select from '../../common/select.png'
import { SwipeablePanel } from 'rn-swipeable-panel';
import SwipeButton from 'rn-swipe-button';

const Withdraw = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const [number, setNumber] = useState('')
    const [isValidNumber, setIsValidNumber] = useState(false);
    const [modalvisible, setmodalVisible] = React.useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [coin, setCoin] = React.useState(false);
    const [wallet, setWallet] = useState('');
    const defaultStatusMessage = 'swipe status appears here';
    const [swipeStatusMessage, setSwipeStatusMessage] = useState(
        defaultStatusMessage,
    );
    const [panelProps, setPanelProps] = useState({
        fullWidth: true,
        openLarge: true,
        showCloseButton: false,
        onClose: () => closePanel(),
        onPressCloseButton: () => closePanel(),
        // ...or any prop you want
    });
    const [isPanelActive, setIsPanelActive] = useState(false);

    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [agressive, setAgressive] = useState(['#C10932', '#FD5578']);
    const [conservative, setConservative] = useState('white');
    const [withdrawType, setWithdrawType] = useState('conservative');
    const [profit, setProfit] = useState('white');
    const [refferal, setRefferal] = useState('white');

    const rowdata = [
        { name: 'LTCT' },
        { name: 'GRS' },
        { name: 'GUAP' },
        { name: 'ILC' },
        { name: 'KMD' },
        { name: 'QXEN' },
        { name: 'PIVX' },
        { name: 'QTUM' },
        { name: 'RVN' },
        { name: 'SMART' },
        { name: 'SOL' },
        { name: 'SYS' },
        { name: 'TLOS' },
        { name: 'TRX' },
        { name: 'USDT.SOL' },
        { name: 'USDT.TRC 20' },
        { name: 'VTC' },
        { name: 'WAVES' },
        { name: 'XEM' },
        { name: 'XMR' },

    ]

    const handleSubmit1 = () => {
        if (wallet == '') {
            alert('Enter the Walled Address')
        } else if (number == '') {
            alert('Enter the Amount')
        } else {
            let request = {
                coin: dropdownval,
                withdrawType: withdrawType,
                wallet: wallet,
                amount: number,
                type: "withdraw"
            }
            setIsPanelActive(false)
            setNumber(null)
            
            props?.initiateWithdrawRequest(request)

        }
    }
    const handleNumberChange = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {
            setNumber(value);
            setIsValidNumber(true)
        }
    };
    const handleNumberChange1 = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {

            setCoin(value);
            setWallet(true)

        }
    };

    const openPanel = () => {
        if (number == "") {
            alert("Please Enter Amount")
        } else if (number < 10) {
            alert("Minimum Amount should be $10")
        } else {
            let request = {
                coin: 'USDT',
                withdrawType: withdrawType,
                wallet: 'wallet',
                amount: number,
                type: "withdraw"
            }
            setIsPanelActive(false)
            setNumber('')
            
            props?.initiateWithdrawRequest(request, props.navigation)

            //setIsPanelActive(true);
        }
    }
    const handleAgressiveClick = () => {
        setAgressive(['#C40730', '#FD5578']);
        setConservative('white');
        setRefferal('white');
        setProfit('white')
        setWithdrawType('agressive');
    };

    const handleConservativeClick = () => {
        setConservative(['#C40730', '#FD5578']);
        setAgressive('white');
        setRefferal('white');
        setProfit('white');
        setWithdrawType('conservative');

    };
    const handleProfitClick = () => {
        setProfit(['#C40730', '#FD5578']);
        setRefferal('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('admitprofit');
    };

    const handleRefferalClick = () => {
        setRefferal(['#C40730', '#FD5578']);
        setProfit('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('refer');
    };
    // const closemodal = () => {
    //     setmodalVisible(false)
    // }
    const closePanel = () => {
        setIsPanelActive(false);
    };

    // const openPanel = () => {
    //     setIsPanelActive(true);
    // };
    const CheckoutButton = () => {
        return (
            <View style={tw`h-18 w-18 bg-white items-center justify-center`}>
                <Image source={ImageIcons.arrow_both} style={tw`h-4 bg-white absolute mt-3.5 w-5 ml-3 `} />
            </View>
        );
    }
    const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);
    return (
        <>
            <View style={{ backgroundColor: '#FFFFFF'}}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Withdraw'} />
                {isPanelActive == false &&
                    <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps='handled'>
                        <View style={tw`flex items-center justify-center w-12/12 `}>
                            <View style={tw`bg-[#171717]  p-4 w-11/12 justify-center items-center flex rounded-[8] mt-3 shadow-2xl  shadow-[#7D64FF] z`}>
                                <View style={tw`w-11/12`}>
                                    {/* bg-[#171717] */}
                                    <Text style={tw`text-white opacity-70 mt-[1.5] font-bold`}>Admin Profit</Text>
                                </View>
                                {/* <Text style={tw`text-white font-bold text-5 mt-4`}>$14,590.20</Text> */}
                                <View style={tw`w-11/12 mt-4 flex items-start mr-8`}>
                                    {/* <TextInput style={tw`text-white font-bold text-xl `}>{props?.dashboarddata?.totalBalance?.toFixed(2)}</TextInput> */}
                                    {/* <Text style={tw`text-[#2AEFB4] font-bold text-5xl `}> ${(parseFloat(props?.dashboarddata?.wallet?.conservativeAmount) + parseFloat(props?.dashboarddata?.wallet?.amount)).toFixed(2)}</Text> */}
                                    <Text style={tw`text-[#2AEFB4] font-bold text-4xl `}> $0</Text>
                                </View>

                            </View>
                            <View style={tw` w-11/12   bg-white justify-between flex items-center shadow-xl shadow-[#7D64FF]  rounded-[3] mt-4 flex-row`}>
                                <View style={tw`w-5.5/12 flex-row  items-center justify-center p-2 `}>
                                    <Image source={ImageIcons.Frame_71} style={tw`h-12 w-12 `} />
                                    <View style={tw` flex-1 p-2 `}>
                                        <Text style={tw`text-sm font-bold text-[#030303]`}>Low Risk</Text>
                                        <Text style={tw`text-2xl text-[#3D6670] font-bold`}>
                                            ${parseFloat(props?.dashboarddata?.otherData?.low_risk_amount)}
                                        
                                        </Text>
                                    </View>
                                </View>

                                {/* ${parseFloat(props?.dashboarddata?.wallet?.adminProfitAmount).toFixed(2)} */}

                                <View style={tw`w-5.5/12 flex-row  items-center justify-center p-2`}>
                                    <Image source={ImageIcons.Frame_71} style={tw`h-12 w-12 `} />
                                    <View style={tw` flex-1 p-2 `}>
                                        <Text style={tw`text-sm font-bold text-[#030303]`}>High Risk</Text>
                                        <Text style={tw`text-2xl text-[#3D6670] font-bold`}>
                                            ${parseFloat(props?.dashboarddata?.otherData?.high_risk_amount)}
                                        </Text>
                                    </View>
                                </View>
                            </View>
                            {/* ${parseFloat(props?.dashboarddata?.wallet?.refferalWalletAmount).toFixed(2)} */}

                            <View style={tw`bg-[#fff] border-[#000000]  p-4  items-center w-11/12 flex justify-center rounded-[6] border  mt-4 shadow-2xl shadow-[#7D64FF] z`}>
                                <Text style={tw`w-9/12 text-center text-[#002662] text-base`}>Enter Suitable amount you would like to Withdraw</Text>
                                <View style={tw`flex-row items-center border border-gray-300 rounded-2xl mt-5`}>
                                    {/* <Text style={tw`text-4xl font-bold text-[#030303]`}>$</Text> */}
                                    <TextInput
                                        style={tw` text-4xl font-bold flex text-[#030303] h-15 w-10/12`}
                                        value={`$${number}`}
                                        onChangeText={(value) => setNumber(value.replace(/\$/g, ''))} // Remove $ before setting the value
                                        placeholder={'Enter Amount'}
                                        keyboardType="numeric"
                                        selectionColor="Black"
                                    />
                                </View>
                            </View>
                            <View  style={tw`w-11/12`} >
                                <Text style={tw`mt-3 font-bold`}>Select type of amount you want to withdrawal</Text>
                            </View>
                            <View style={tw` w-11/12 mx-3 my-3  mb-1 justify-center item-center`}>
                                <View style={tw` w-11/12 mx-4 flex-row justify-between my-3 mb-1 item-center`}>
                                    <TouchableOpacity
                                        onPress={handleConservativeClick}
                                        style={{ backgroundColor: conservative }}
                                    >
                                        {conservative === 'white' ? (
                                            <View style={[tw` h-15 w-20  items-center  justify-evenly rounded-[4] bg-[#fff]  `, {elevation:1}]}>
                                                <Text style={tw`text-black text-2.5 text-center font-bold mt-3`}>Low risk</Text>
                                                <Text style={tw`text-black text-2.5 text-center font-bold mb-3`}>Deposit</Text>

                                            </View>
                                        ) : (
                                            <LinearGradient
                                                colors={['#171717', '#171717']}
                                                start={{ x: 0.1, y: 1.0 }}
                                                end={{ x: 1.0, y: 0.1 }}
                                                locations={[0.0, 1.0]} style={tw` h-15 w-20 bg-[#fff]   items-center  justify-evenly rounded-[4]  shadow-xl shadow-[#7D64FF]`}
                                            >
                                                <View style={tw` ml-14`}>
                                                    <Image source={ImageIcons.vector} style={tw`h-3 w-3 mr-2  mt-1`} />
                                                </View>
                                                <Text style={tw`text-[#fff] font-bold text-2.5 text-center `}>Low risk</Text>
                                                <Text style={tw`text-[#fff] font-bold text-2.5 text-center mb-3`}>Deposit</Text>

                                            </LinearGradient>
                                        )}
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        onPress={handleAgressiveClick}
                                        style={{ backgroundColor: agressive }}
                                    >
                                        {agressive === 'white' ? (
                                            <View style={[tw` h-15 w-20  items-center  justify-evenly rounded-[4] bg-[#fff]  `, {elevation:1}]}>
                                                <Text style={tw`text-black text-2.5 text-center font-bold mt-3`}>High risk</Text>
                                                <Text style={tw`text-black text-2.5 text-center font-bold mb-3`}>Deposit</Text>

                                            </View>
                                        ) : (
                                            <LinearGradient
                                                colors={['#171717', '#171717']}
                                                start={{ x: 0.1, y: 1.0 }}
                                                end={{ x: 1.0, y: 0.1 }}
                                                locations={[0.0, 1.0]} style={tw`   items-center h-15 w-21   justify-evenly rounded-[4] p-1 shadow-[#7D64FF]  shadow-2xl`}

                                            >
                                                <View style={tw` ml-14`}>
                                                    <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                                </View>
                                                <Text style={tw`text-[#fff] font-bold text-2.5 text-center `}>High risk</Text>
                                                <Text style={tw`text-[#fff] font-bold text-2.5 text-center mb-3`}> Deposit</Text>

                                            </LinearGradient>
                                        )}
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        onPress={handleProfitClick}
                                        style={{ backgroundColor: profit }}
                                    >
                                        {profit === 'white' ? (
                                            <View style={[tw` h-15 w-20  items-center  justify-evenly rounded-[4] bg-[#FFFFFF]  `, {elevation:1}]}>
                                                <Text style={tw`text-[#000] font-bold text-2.5 text-center mt-3`}>Profit you </Text>
                                                <Text style={tw`text-[#000] font-bold text-2.5 text-center mb-3`}>Earned</Text>
                                            </View>
                                        ) : (
                                            <LinearGradient
                                                colors={['#171717', '#171717']}
                                                start={{ x: 0.1, y: 1.0 }}
                                                end={{ x: 1.0, y: 0.1 }}
                                                locations={[0.0, 1.0]} style={tw` h-15 w-20   items-center shadow-[#7D64FF]  shadow-2xl  justify-evenly rounded-[4] p-1 `}

                                            >
                                                <View style={tw` ml-14`}>
                                                    <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                                </View>
                                                <Text style={tw`text-[#fff] font-bold text-2.5 text-center `}>Profit you</Text>
                                                <Text style={tw`text-[#fff] font-bold text-2.5 text-center mb-3`}>Earned</Text>

                                            </LinearGradient>
                                        )}
                                    </TouchableOpacity>

                                    {/* <TouchableOpacity
                                    onPress={handleRefferalClick}
                                    style={{ backgroundColor: refferal }}
                                >
                                    {refferal === 'white' ? (
                                        <View style={tw` h-15 w-20 shadow-[#7D64FF]  shadow-2xl  items-center bg-[#fff]  justify-evenly rounded-[4]   `}>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mt-3`}>Refer N earn</Text>
                                            <Text style={tw`text-black text-2.5 text-center font-bold mb-3`}> Amount</Text>

                                        </View>
                                    ) : (
                                        <LinearGradient
                                            colors={['#C40730', '#FD5578']}
                                            start={{ x: 0.1, y: 1.0 }}
                                            end={{ x: 1.0, y: 0.1 }}
                                            locations={[0.0, 1.0]} style={tw`h-15 w-20 shadow-[#7D64FF]  shadow-2xl  items-center  justify-evenly rounded-[4] p-1 `}

                                        >
                                            <View style={tw` ml-14`}>
                                                <Image source={ImageIcons.vector} style={tw`h-3 w-3   mt-1`} />
                                            </View>
                                            <Text style={tw`text-[#fff] text-2.5 text-center font-bold `}>Refer N earn</Text>
                                            <Text style={tw`text-[#fff] text-2.5 text-center font-bold mb-3`}> Amount</Text>
                                        </LinearGradient>
                                    )}
                                </TouchableOpacity> */}
                                </View>

                            </View>
                            {/* <TouchableOpacity onPress={() => { openPanel() }}>
                            <View style={tw`h-14 w-6.5/12 mt--10 my-10 mx-auto border border-[#C30B34] justify-between rounded-[8]`}
                            >
                                <View style={tw`flex-row mx-2 my-1 items-center`}>
                                    <View style={tw`h-11 w-11 rounded-full items-center justify-center bg-[#BD0B30]`}>
                                        <Image source={ImageIcons.arrow_login} style={tw`h-4 tint-[#fff]   w-5 `} />
                                    </View>
                                    <View>
                                        <Text style={tw`text-black text-sm ml-3`}>Swipe to Withdraw</Text>
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity> */}
                            <View style={tw`justify-center items-center my-13`}>
                                <SwipeButton
                                    containerStyles={{ borderRadius: 10 }}
                                    height={50}
                                    width={320}
                                    // onSwipeFail={() => updateSwipeStatusMessage('Incomplete swipe!')}
                                    // onSwipeStart={() => updateSwipeStatusMessage('Swipe started!')}
                                    onSwipeSuccess={() =>
                                        openPanel('Submitted successfully!')
                                        // alert('Submitted successfuly')
                                    }
                                    railBackgroundColor="#171717"
                                    railFillBackgroundColor='#FD5578'
                                    shouldResetAfterSuccess={true}
                                    railStyles={{ borderRadius: 10, borderColor: 'white', backgroundColor: 'white', marginVertical: '2%', marginHorizontal: '2%' }}
                                    thumbIconComponent={CheckoutButton}
                                    thumbIconBorderColor={'white'}
                                    // thumbIconImageSource={arrowRight}
                                    // thumbIconWidth={100} 
                                    title="Swipe to Withdraw"
                                    titleFontSize={20}
                                    titleStyles={{ color: 'white', paddingLeft: '10%', zIndex: 1001 }}
                                />
                            </View>
                        </View>
                    </ScrollView>
                }


            </View>

            <SwipeablePanel style={tw` h-151 bg-[#ffffff] `} {...panelProps} isActive={isPanelActive}>
                <View style={tw` bg-[#FFF] `}>
                    <Text style={tw`text-center my-4 font-5 text-sm`}>Select your coin for withdrawal</Text>

                    <View style={tw`h-30 w-10.6/12 bg-[#002662] shadow-[#7D64FF]  shadow-2xl rounded-[4] border-2px mx-6 mt-20`}>
                        <View style={tw`p-4 mx-2`}>
                            <Text style={tw`text-[#ffffff]`}>Enter your wallet address</Text>
                        </View>
                        <View style={tw`relative  ml-6 flex-row`}>
                            <TextInput
                                style={tw` w-7/12  bg-[#ffffff] text-black rounded-3 h-11  p-3	`}
                                value={wallet}
                                onChangeText={(value) => setWallet(value)}
                                placeholder={'Wallet Address'}
                                placeholderTextColor={"black"}
                                // onChangeText={handleChange('email')}
                                // onChangeText={handleNumberChange1}
                                // reference={emailInputRef}
                                selectionColor="white"
                            // onSubmitEditing={() => passwordInputRef?.current?.focus()}
                            />
                            {coin &&
                                <>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-6 w-6  justify-center text-center items-center rounded-[2] my-2 absolute mx-35  `}
                                    >
                                        <View style={tw`flex-row `}>
                                            <Image
                                                source={select}
                                                style={[tw`h-4 w-4  `, { tintColor: 'white' }]}
                                            >
                                            </Image>
                                        </View>
                                    </LinearGradient>
                                </>
                            }

                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-9 w-3/12  justify-center text-center items-center rounded-[2]  mx-5   flex-row`}
                            >
                                <TouchableOpacity onPress={() => setShowdrowdoenval(s => !s)} style={tw`flex-row`}>
                                    <Text style={tw`text-[#ffffff]`}>{dropdownval}</Text>
                                    <Image source={ImageIcons.dropdown} style={tw`h-2 w-3 mx-2 mt-2`} />
                                </TouchableOpacity>
                            </LinearGradient>
                        </View>
                    </View>
                    {showdrowdoenval == true &&
                        <ScrollView style={tw`bg-[#000000] border mt-8 absolute z-50 h-40 right-7 top-54`}>
                            {rowdata?.map((data) => {
                                return (
                                    <TouchableOpacity onPress={() => { setDropdownval(data.name); setShowdrowdoenval(false) }} style={tw`mt-2 mb-2 pl-5 pr-5`}><Text style={tw`text-[#ffffff]`}>{data.name}</Text></TouchableOpacity>
                                )
                            })}
                        </ScrollView>
                    }
                    <Text style={tw`text-center text-xs mt-5`}>Note: Withdrawal process may take 04-10 working hours.</Text>
                    <TouchableOpacity onPress={() => handleSubmit1()}>
                        <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw`h-16 w-8/12 mx-auto items-center  justify-center rounded-[8] p-1 mt-40`}
                        >
                            <Text style={tw`text-white text-sm font-bold`}>Proceed</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>


            </SwipeablePanel>

        </>

    )
}




export default (Withdraw);