import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView, KeyboardAvoidingView } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';

import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import splash from '../../common/unsplash.png'
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';


const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const Notification = (props) => {


    const Aray = [
        {
            'Name': 'SALE IS LIVE',
            'Time': '1m',
            'Para': 'loram generated Lorem Ipsum is am  this is not therefore always free from repetition.'
        },
        {
            'Name': 'SALE IS LIVE',
            'Time': '1m',
            'Para': 'loram generated Lorem Ipsum is am  this is not therefore always free from repetition.'
        },
        {
            'Name': 'SALE IS LIVE',
            'Time': '1m',
            'Para': 'loram generated Lorem Ipsum is am  this is not therefore always free from repetition.'
        },
    ]
    useEffect(() => {

        props?.getnotificationlist()
    }, [])
    const renderItem = ({ item, index }) => {
        return (
            <View>
                <View style={tw`flex-row w-12/12 justify-evenly p-3  `}>
                    {/* <View>
                        <Image
                            source={splash}
                            style={tw`h-14 w-14  `}

                        >
                        </Image>
                    </View> */}
                    {/* <View style={tw `w-7/12`} >
                        <Text style={tw`text-sm font-bold`}>{item?.type}</Text>
                        <Text style={tw`text-[2.5] text-gray-500`}>{item?.description}</Text>
                    </View> */}
                    {/* <View style={tw`w-1/12 mt-3`}>
                        <Text style={tw`text-xs text-gray-500`}>{moment(item?.createdAt)?.format('MM,DD')} ago </Text>
                    </View> */}

                    <View style={tw`h-17 w-12/12 bg-white items-center  justify-around  shadow-xl shadow-[#7D64FF] my--1 rounded-[4]  flex-row`}>
                        <View style={tw`h-13 w-13 rounded-[3] bg-[#002669] justify-center items-center`}>
                            <Image source={ImageIcons.Notification_image} style={tw` tint-[#fff] h-9 w-9`}/>
                        </View>
                        <View style={tw`w-6/12`}>
                        <Text style={tw` text-'#1C162E' capitalize text-sm `}>{item.description}</Text>
                        </View>
                        <View style={tw`bg-gray-100 h-8 items-center text-center justify-center rounded-[9] w-2.5/12`}>
                        <Text style={tw`text-[#FF3A79] text-xs `}>{moment(item.createdAt)?.format('MMM DD')}</Text>
                    </View>
                       
                    </View>
                </View>
            </View>

        )
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>


            <ScrollView style={tw`bg-white`}>
                <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Notification'} />

                {/* <View style={tw`flex-row w-12/12 justify-evenly p-3 `}>
                    <View>
                        <Image
                            source={splash}
                            style={tw`h-14 w-14  `}

                        >
                        </Image>
                    </View>
                    <View style={tw `w-7/12`} >
                        <Text style={tw`text-sm font-bold`}>SALE IS LIVE</Text>
                        <Text style={tw`text-[2.5] text-gray-500`}>loram generated Lorem Ipsum is am  this is not therefore always free from repetition.</Text>
                    </View>
                    <View style={tw`w-1/12 mt-3`}>
                        <Text style={tw`text-xs text-gray-500`}>1m ago </Text>
                    
                    </View>
                    
                </View> */}
                <View>
                    <FlatList
                        data={props?.notificationlist}
                        renderItem={renderItem}
                        keyExtractor={item => item.id}
                    />
                </View>




            </ScrollView>



            {/* <CustomBottomTab {...props} isActive={true} selected={"Insights"} /> */}
        </KeyboardAvoidingView>


    )
}

export default Notification;