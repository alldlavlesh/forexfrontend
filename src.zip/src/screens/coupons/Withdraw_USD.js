import React, { useRef, useState,useEffect } from 'react';
import { Text, View, ScrollView, Alert, StatusBar, LogBox, KeyboardAvoidingView, Platform, Keyboard, Modal, Button, Image, ImageBackground, TextInput, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, ImageIcons, CommonStrings } from '../../common'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import LinearGradient from 'react-native-linear-gradient';
import select from '../../common/select.png'
import { SwipeablePanel } from 'rn-swipeable-panel';
import SwipeButton from 'rn-swipe-button';

const Withdraw_USD = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;
    const [number, setNumber] = useState('')
    const [isValidNumber, setIsValidNumber] = useState(false);
    const [modalvisible, setmodalVisible] = React.useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [coin, setCoin] = React.useState(false);
    const [wallet, setWallet] = useState('');
    const defaultStatusMessage = 'swipe status appears here';
    const [swipeStatusMessage, setSwipeStatusMessage] = useState(
        defaultStatusMessage,
    );
    const [panelProps, setPanelProps] = useState({
        fullWidth: true,
        openLarge: true,
        showCloseButton: false,
        onClose: () => closePanel(),
        onPressCloseButton: () => closePanel(),
        // ...or any prop you want
    });
    const [isPanelActive, setIsPanelActive] = useState(false);

    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [agressive, setAgressive] = useState(['#C10932', '#FD5578']);
    const [conservative, setConservative] = useState('white');
    const [withdrawType, setWithdrawType] = useState('agressive');
    const [profit, setProfit] = useState('white');
    const [refferal, setRefferal] = useState('white');

    const rowdata = [
        { name: 'LTCT' },
        { name: 'GRS' },
        { name: 'GUAP' },
        { name: 'ILC' },
        { name: 'KMD' },
        { name: 'QXEN' },
        { name: 'PIVX' },
        { name: 'QTUM' },
        { name: 'RVN' },
        { name: 'SMART' },
        { name: 'SOL' },
        { name: 'SYS' },
        { name: 'TLOS' },
        { name: 'TRX' },
        { name: 'USDT.SOL' },
        { name: 'USDT.TRC 20' },
        { name: 'VTC' },
        { name: 'WAVES' },
        { name: 'XEM' },
        { name: 'XMR' },

    ]

    const handleSubmit1 = () => {
        if (wallet == '') {
            alert('Enter the Walled Address')
        } else if (number == '') {
            alert('Enter the Amount')
        } else {
            let request = {
                coin: dropdownval,
                withdrawType: withdrawType,
                wallet: wallet,
                amount: number,
                type: "withdraw"
            }
            setIsPanelActive(false)
            setNumber(null)
            
            props?.initiateWithdrawRequest(request)

        }
    }
    const handleNumberChange = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {
            setNumber(value);
            setIsValidNumber(true)
        }
    };
    const handleNumberChange1 = (value) => {
        // Validate input to allow maximum of four digits
        if (value.length <= 5) {

            setCoin(value);
            setWallet(true)

        }
    };

    const openPanel = () => {
        if (number == "") {
            alert("Please Enter Amount")
        } else if (number < 10) {
            alert("Minimum Amount should be $10")
        } else {
            setIsPanelActive(true);
        }
    }
    const handleAgressiveClick = () => {
        setAgressive(['#C40730', '#FD5578']);
        setConservative('white');
        setRefferal('white');
        setProfit('white')
        setWithdrawType('agressive');
    };

    const handleConservativeClick = () => {
        setConservative(['#C40730', '#FD5578']);
        setAgressive('white');
        setRefferal('white');
        setProfit('white');
        setWithdrawType('conservative');

    };
    const handleProfitClick = () => {
        setProfit(['#C40730', '#FD5578']);
        setRefferal('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('admitprofit');
    };

    const handleRefferalClick = () => {
        setRefferal(['#C40730', '#FD5578']);
        setProfit('white');
        setConservative('white');
        setAgressive('white');
        setWithdrawType('refer');
    };
    // const closemodal = () => {
    //     setmodalVisible(false)
    // }
    const closePanel = () => {
        setIsPanelActive(false);
    };

    // const openPanel = () => {
    //     setIsPanelActive(true);
    // };
    const currencyFormat = (num) => {
        return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    }
    useEffect(() => {
        // props?.getTransactionsList('deposit');
        props?.walletBalance();
       

    }, [])
    const CheckoutButton = () => {
        return (
            <View style={tw`h-11 w-11 rounded-full bg-[#BD0B30] items-center justify-center `}>
                <Image source={ImageIcons.arrow_login} style={tw`h-4 tint-[#fff]  absolute mt-3.5 w-5 ml-3 `} />
            </View>
        );
    }
    const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);
    return (
        <>
            <View style={{ backgroundColor: '#FFFFFF' }}>
                <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
                <CustomHeaderTab {...props} isActive={false} selected={"Withdraw USD"} parent={false} name={'Withdraw USD'} />
                {isPanelActive == false &&
                    <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps='handled'>
                        <View style={tw` w-12/12  flex justify-center items-center p-3`}>
                            <View style={tw`bg-[#171717] flex p-5 justify-center items-center w-12/12 h-30  rounded-[8]  shadow-2xl  shadow-[#7D64FF] z`}>
                                <View style={tw`flex-row items-center justify-left  w-11/12`} >
                                    <Text style={tw`text-white opacity-70  font-bold `}>Available Balance</Text>
                                </View>
                                <View style={tw`flex-row items-center justify-left  w-11/12 mt-2`}>
                                    {/* <Text style={tw`text-[#2AEFB4] font-bold text-5xl`}>${(parseFloat(props?.dashboarddata?.wallet?.conservativeAmount) + parseFloat(props?.dashboarddata?.wallet?.amount)).toFixed(2)}</Text> */}
                                    {props?.getwalletBalance != undefined ?
                                        <Text style={tw`text-[#2AEFB4] text-left font-bold text-9 `}>${currencyFormat (props?.getwalletBalance?.amount)}</Text>
                                        :
                                        <Text style={tw`text-[#2AEFB4] text-left font-bold text-9`}>$ </Text>
                                    }
                                </View>
                            </View>

                            <Text style={tw`text-[#848484] text-left  w-11/12 mt-2  `}>AMOUNT</Text>

                            <View style={tw`flex flex-row w-11/12 items-center justify-between  mt-2`}>
                                <View style={tw`w-8/12 `}>
                                    <TextInput
                                        style={tw`  bg-[#ffffff] text-black border border-[#E8E8E8] bg-white rounded-2 h-13  `}
                                        value={number}
                                        type='text'
                                        placeholder={' $ Enter amount'}
                                        placeholderTextColor={Colors.GREY}
                                        // selectionColor="#C20A33"
                                        onChangeText={(value) => setNumber(value)}
                                        keyboardType='numeric'
                                    />
                                    {isValidNumber &&
                                        <>
                                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                                end={{ x: 1.0, y: 0.1 }}
                                                locations={[0.0, 1.0]} style={tw` h-6 w-6  justify-center text-center items-center rounded-[2]  absolute top-1/2 transform -translate-y-1/2 right-20 mt--3  `}
                                            >
                                                <View style={tw`flex-row `}>
                                                    <Image
                                                        source={select}
                                                        style={[tw`h-4 w-4  `, { tintColor: 'white' }]}
                                                    >
                                                    </Image>
                                                </View>
                                            </LinearGradient>
                                        </>
                                    }
                                </View>
                                <View style={tw` bg-[#EBEBEB] text-black  rounded-2 h-13 flex-row flex items-center justify-around w-3.5/12  `}>
                                    <Image source={ImageIcons.Dollar} resizeMode='contain' style={tw`h-5 w-7 `} />
                                    <Text style={tw` font-bold `}>USD</Text>
                                    <Image source={ImageIcons.down} resizeMode='contain' style={tw`h-5 w-7 `} />
                                </View>
                            </View>
                            <Text style={tw`text-[#848484] text-left  w-11/12 mt-2  `}>MERCHANT</Text>

                            <View style={tw` flex-row items-center w-11/12 mt-2`}>
                                <TextInput
                                    style={tw`bg-[#ffffff] text-black border border-[#E8E8E8] bg-white rounded-2 h-13   w-full flex-1 pr-10`}
                                    placeholder={'Crypto via coinpayments'}
                                    type='text'
                                    placeholderTextColor={Colors.GREY}
                                    keyboardType='string' // Change to 'default' for text input
                                />
                                <Image source={ImageIcons.down} resizeMode='contain' style={tw`h-8 w-10 absolute right-2`} />
                            </View>


                            <View style={tw` bg-[#ffffff] text-black border-b border-[#E8E8E8] bg-white rounded-2 h-12 flex-row flex items-center  w-11/12 justify-between mt-2 `}>
                                <Text style={tw`text-[#848484]  text-base `}> Free :</Text>
                                <Text style={tw` text-black `}>0.10%</Text>

                            </View>
                            <View style={tw` bg-[#ffffff] text-black border-b border-[#E8E8E8] bg-white rounded-2 h-12 flex-row flex items-center w-11/12 justify-between mt-2  `}>
                                <Text style={tw`text-[#848484]  text-base `}> Amount Recieved </Text>
                                <Text style={tw` text-black `}>0 USD</Text>
                            </View>


                            <View style={tw`w-11/12 h-50 mt-50`}>
                                <TouchableOpacity style={tw` h-15 bg-[#E0F64B] items-center  justify-center rounded-[4]`} onPress={() => { openPanel() }} >
                                    <Text style={tw`text-black  text-[4.5]  `}>Continue</Text>
                                </TouchableOpacity>

                            </View>



                        </View>
                    </ScrollView>
                }

                <TouchableOpacity onPress={() => { openPanel() }}>
                    {/* <View style={tw`h-14 w-6.5/12 my-50 mx-auto border border-[#C30B34] justify-between rounded-[8]`}
                    >
                        <View style={tw`flex-row mx-2 my-1 items-center`}>
                            <View style={tw`h-11 w-11 rounded-full items-center justify-center bg-[#BD0B30]`}>
                                <Image source={ImageIcons.arrow_login} style={tw`h-4 tint-[#fff]   w-5 `} />
                            </View>
                            <View>
                                <Text style={tw`text-black text-sm ml-3`}>Swipe to Withdraw</Text>
                            </View>
                        </View>
                    </View> */}
                </TouchableOpacity>
                {/* <View style={tw`justify-center items-center mt-5 mb-10`}>
                    <SwipeButton
                        containerStyles={{ borderRadius: 30 }}
                        height={50}
                        width={250}
                        // onSwipeFail={() => updateSwipeStatusMessage('Incomplete swipe!')}
                        // onSwipeStart={() => updateSwipeStatusMessage('Swipe started!')}
                        onSwipeSuccess={() =>
                            openPanel('Submitted successfully!')
                            // alert('Submitted successfuly')
                        }
                        railBackgroundColor="#fff"
                        thumbIconBorderColor={'#BD0B30'}
                        railFillBackgroundColor='#FD5578'
                        //shouldResetAfterSuccess={true}
                        railStyles={{ borderRadius: 30, borderColor: '#BD0B30', marginVertical: '2%', marginHorizontal: '2%' }}
                        thumbIconComponent={CheckoutButton}
                        // thumbIconImageSource={arrowRight}
                        // thumbIconWidth={100} 
                        title="Swipe to Withdrawal"
                        titleFontSize={14}
                        titleStyles={{ color: '#000000', paddingLeft: '10%', zIndex: 1001 }}
                    />
                </View> */}
            </View>

            <SwipeablePanel style={tw` h-151 bg-[#ffffff] `} {...panelProps} isActive={isPanelActive}>
                <View style={tw` bg-[#FFF] `}>
                    <Text style={tw`text-center my-4 font-5 text-sm`}>Selecy your coin for withdrawal</Text>

                    <View style={tw`h-30 w-10.6/12 bg-[#002662] shadow-[#7D64FF]  shadow-2xl rounded-[4] border-2px mx-6 mt-20`}>
                        <View style={tw`p-4 mx-2`}>
                            <Text style={tw`text-[#ffffff]`}>Enter your wallet address</Text>
                        </View>
                        <View style={tw`relative  ml-6 flex-row`}>
                            <TextInput
                                style={tw` w-7/12  bg-[#ffffff] text-black rounded-3 h-11  p-3	`}
                                value={wallet}
                                onChangeText={(value) => setWallet(value)}
                                placeholder={'Wallet Address'}
                                placeholderTextColor={"black"}
                                // onChangeText={handleChange('email')}
                                // onChangeText={handleNumberChange1}
                                // reference={emailInputRef}
                                selectionColor="white"
                            // onSubmitEditing={() => passwordInputRef?.current?.focus()}
                            />
                            {coin &&
                                <>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-6 w-6  justify-center text-center items-center rounded-[2] my-2 absolute mx-35  `}
                                    >
                                        <View style={tw`flex-row `}>
                                            <Image
                                                source={select}
                                                style={[tw`h-4 w-4  `, { tintColor: 'white' }]}
                                            >
                                            </Image>
                                        </View>
                                    </LinearGradient>
                                </>
                            }

                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-9 w-3/12  justify-center text-center items-center rounded-[2]  mx-5   flex-row`}
                            >
                                <TouchableOpacity onPress={() => setShowdrowdoenval(s => !s)} style={tw`flex-row`}>
                                    <Text style={tw`text-[#ffffff]`}>{dropdownval}</Text>
                                    <Image source={ImageIcons.dropdown} style={tw`h-2 w-3 mx-2 mt-2`} />
                                </TouchableOpacity>
                            </LinearGradient>
                        </View>
                    </View>
                    {showdrowdoenval == true &&
                        <ScrollView style={tw`bg-[#000000] border mt-8 absolute z-50 h-40 right-7 top-54`}>
                            {rowdata?.map((data) => {
                                return (
                                    <TouchableOpacity onPress={() => { setDropdownval(data.name); setShowdrowdoenval(false) }} style={tw`mt-2 mb-2 pl-5 pr-5`}><Text style={tw`text-[#ffffff]`}>{data.name}</Text></TouchableOpacity>
                                )
                            })}
                        </ScrollView>
                    }
                    <Text style={tw`text-center text-xs mt-5`}>Note: Withdrawal process may take 04-10 working hours.</Text>
                    <TouchableOpacity onPress={() => handleSubmit1()}>
                        <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw`h-16 w-8/12 mx-auto items-center  justify-center rounded-[8] p-1 mt-40`}
                        >
                            <Text style={tw`text-white text-sm font-bold`}>Proceed</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>


            </SwipeablePanel>

        </>

    )
}




export default (Withdraw_USD);