import React, { useEffect, useRef, useState } from 'react';
import { Text, Image, View, ScrollView, ImageBackground, Alert, StatusBar, TouchableOpacity, KeyboardAvoidingView, Platform, Keyboard, TextInput, Dimensions } from 'react-native';
import { withFormik } from 'formik';
// import DateTimePicker from '@react-native-community/datetimepicker';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CheckBox from '@react-native-community/checkbox';
import ImagePicker from 'react-native-image-crop-picker';
import moment from 'moment';
import momentzone from 'moment-timezone';
import Video from 'react-native-video';
import * as Yup from 'yup';
import CustomBottomTab from '../../components/CustomBottomTab';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import styles from './styles';
import { Colors, ImageIcons, CommonStrings } from '../../common'
import InputField from '../../components/forms/inputField';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import Loader from '../../components/modals/Loader';
import DropdownButton from '../../components/dropdown';
import { discountOptions } from '../../common/StaticData';
import PercentagePicker from '../../components/dropdown/PercentagePicker';
import { RadioButton, Provider, Portal, Button, } from 'react-native-paper';
import Modal from 'react-native-modal';
import tw from 'twrnc';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
const AddcouponServices = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    //Reference
    const titleRef = useRef();
    const descriptionRef = useRef();
    const discountRef = useRef();

    // Local states
    const [expireDate, setExpireDate] = useState(moment().add(30, 'day'));
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [couponId, setCouponId] = useState();
    const [couponStatus, setCouponStatus] = useState("Draft");
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [discountType, setDiscountType] = useState(null);
    const [items, setItems] = useState(discountOptions);
    const [discount, setDiscount] = useState();
    const [open, setOpen] = useState(false);
    const [isOpenDiscountPicker, setIsOpenDiscountPicker] = useState(false);
    const [toggleCheckBox, setToggleCheckBox] = useState(false);
    const [currentDate, setCurrentDate] = useState('');
    const [modalvisible, setmodalVisible] = React.useState(false);
    const [alreadyPublish, setAlreadyPublish] = React.useState(false);
    const [submitted, setSubmit] = React.useState(false);


    let shareddate = props?.route?.params?.shared;

    useEffect(() => {
        props?.couponsList.map((item) => {
            if (item?.status == "Published" && submitted == false) {
                setAlreadyPublish(true)
            }
        });

    }, [props?.couponsList])

    useEffect(() => {

        props.getCouponList()

        setTimeout(() => {
            if (props?.route?.params && props?.route?.params?.couponData) {
                let couponData = props?.route?.params?.couponData;

                setCouponId(couponData?._id);
                values.couponTitle = couponData?.title || "";
                values.description = couponData?.description || "";
                // values.discount = String(couponData?.discount);
                let fileName = couponData?.couponImage?.split('/').pop();
                let mimeType = couponData?.couponImage?.split('.').pop();
                let file = {
                    'uri': couponData?.couponImage,
                    'type': `image/${mimeType}`,
                    'name': fileName
                }
                setFieldValue("couponImage", file);
                values.couponImage = file;
                setCouponStatus(couponData?.status);
                if (couponData?.discountType) setDiscountType(couponData?.discountType?.discountType);
                setTimeout(() => {
                    if (couponData?.discount) setDiscount(couponData?.discount);
                }, 500);
                setDiscount(couponData?.discount);
                setIsPlaceholderStartDate(false);
                setIsPlaceholderEndDate(false);
                if (shareddate == true) { } else {
                    setStartDate(moment(couponData?.startDate).toDate());
                    setEndDate(moment(couponData?.dateOfExpiration).toDate());
                }
                setToggleCheckBox(couponData?.noExpiration);
            } else {
                values.dateOfExpiration = moment().add(30, 'day').toDate();
                setFieldValue("dateOfExpiration", moment().add(30, 'day').toDate());
            }
        }, 500);

    }, [])


    const openmodal = () => {
        setmodalVisible(true)
    }

    const closemodal = () => {
        setmodalVisible(false)
    }

    // Change expiration date
    const onChangeDate = (dateTime) => {
        if (dateTime) {
            setShowDatePicker(false)
            if (datePickerFor === "startDate") {
                setIsPlaceholderStartDate(false)
                setStartDate(dateTime);
            } else {
                setIsPlaceholderEndDate(false);
                setEndDate(dateTime);
            }
            setToggleCheckBox(false)
        }
    }

    // Select coupon image
    const onSelectImage = () => {
        ImagePicker.openPicker({
            width: 400,
            cropping: true,
            mediaType: 'photo',
            compressImageQuality: 0.5,
            height: 400,
        }).then(image => {
            if (image?.path) {
                let fileName = image?.path?.split('/').pop();
                let mimeType = image?.path?.split('.').pop();
                let file = {
                    'uri': image?.path,
                    'type': `image/${mimeType}`,
                    'name': fileName
                }
                setFieldValue("couponImage", file);
            }
        }).catch((error) => {
        });
    }

    // Select coupon image
    //video: {"creationDate": null, "cropRect": null, "data": null, "duration": 12000, "exif": null, "filename": "IMG_6017.MOV", "height": 320, "localIdentifier": "60CD15A8-D599-48AC-A552-3DB505EDFE04/L0/001", "mime": "video/mp4", "modificationDate": null, "path": "file:///private/var/mobile/Containers/Data/Application/AF63C634-BC83-4F14-A7E1-2ED1E62F539F/tmp/react-native-image-crop-picker/D37CDA81-BB75-42BB-975B-5FBBF9CA8FD7.mp4", "size": 1297961, "sourceURL": "file:///var/mobile/Media/DCIM/126APPLE/IMG_6017.MOV", "width": 568}

    const onSelectVideo = () => {
        ImagePicker.openPicker({
            mediaType: 'video',
            // height: 400,
            // width: 300,
            // cropping: true,
            duration: 30
        }).then(video => {
            
            if (video.duration < 15001) {
                if (video?.path) {
                    let fileVideoName = video?.path?.split('/').pop();
                    let fileVideoMimeType = video?.path?.split('.').pop();
                    let fileVideo = {
                        'uri': video?.path,
                        'type': `video/${fileVideoMimeType}`,
                        'name': fileVideoName
                    }
                    setFieldValue("couponVideo", fileVideo);
                }
            } else {
                Alert.alert(CommonStrings.AppName, "Too large video, duration must be less then 15 sec.");
            }
        }).catch((error) => {
            
        });
    }

    // Add Coupon request submission
    const handleAddCouponSubmit = (buttonType) => {
        setSubmit(true)
        Keyboard.dismiss();
        if (moment(endtDate).isBefore(startDate, 'day')) {
            Alert.alert(CommonStrings.AppName, "Expiration date must be after start date of coupon");
            return;
        }
        let discountvalue = discount || "";
        let message = buttonType === "Published" ? "All field's value needs to be filled before publishing this coupon" : "At least 1 input needs to be filled in to save this coupon as a draft";
        if (buttonType === "Draft") {
            if (values.couponTitle || values.description || discountvalue || (startDate && endtDate)) {
                message = "";
            }
        } else if (buttonType === "Published") {
            // if (startDate && moment(startDate).add(1, 'day').isBefore(new Date())) {
            //     Alert.alert(CommonStrings.AppName, "Please select start date of today date");
            //     return;
            // }
            if (values.couponTitle && values.description && values.couponImage?.uri && (!isPlaceholderStartDate && startDate && endtDate && discountvalue !== "" && discountType) || toggleCheckBox) {
                message = ""
            }
        }
        setTimeout(() => {
            if (!message || message === "") {
                onSubmission(buttonType);
            } else {
                Alert.alert(CommonStrings.AppName, message)
            }

        }, 500);
    }

    const onSubmission = (couponStatus) => {
        // let request = {
        //     "title": values.couponTitle,
        //     "description": values.description,
        //     "discount": discount || 1,
        //     "discountType": discountType,
        //     "dateOfExpiration": moment(endtDate).toISOString(),
        //     "startDate": moment(startDate).toISOString(),
        //     "couponImage": values.couponImage,
        //     "status": couponStatus
        // }
        const formData = new FormData();
        if (!errors.couponTitle) {
            formData.append("title", values.couponTitle);
        }
        if (!errors.description) {
            formData.append("description", values.description);
        }
        if (discount && discountType) {
            formData.append("discount", String(discount));
            formData.append("discountType", discountType);
        }
        if (toggleCheckBox) {
            formData.append("noExpiration", toggleCheckBox);
        } else {
            if (endtDate) {
                formData.append("dateOfExpiration", moment(endtDate).add(1, 'hour').toISOString());
            }
        }
        formData.append("startDate", moment(startDate || new Date()).toISOString());
        if (values.couponImage?.uri) {
            formData.append("couponImage", values.couponImage);
        }

        if (values.couponVideo?.uri) {
            formData.append("couponVideo", values.couponVideo);
        }
        formData.append("status", couponStatus);
        // formData.append("isEditMode", couponStatus === "Published" ? true : false) // 'Draft', 'Published', 'Deactivated' 
        props.createNewCoupon(formData, props.navigation, couponId);
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={80}
            onResponderReject={() => setShowDatePicker(false)}
            style={tw` flex-1 bg-white`}>
            <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
            <ScrollView
                keyboardShouldPersistTaps="handled"
                nestedScrollEnabled={true}
            // keyboardDismissMode='on-drag'
            //onScroll={() => { setShowDatePicker(false); datePickerFor === "startDate" ? setStartDate(startDate || moment(new Date()).toDate()) : setEndDate(endtDate || moment(new Date()).toDate()) }}
            >




                {/*<View style={{ marginTop: '1%', paddingHorizontal: '22%' }}>
                        <RoundedButton
                            text="Draft"
                            onPress={() => handleAddCouponSubmit("Draft")}
                            isOutline={true}
                        />
                    </View> */}

                <View styles={tw`flex-row justify-center`}>

                    <View style={tw`mt-45 px-2`}>
                        <View>
                            <Text style={tw ` text-center mb-3 text-4`}>Coupon: (if your business is able to offer a discount, e.g., restaurant, hairdresser, plumber, etc.)
                            </Text>
                        </View>
                        <RoundedButton
                            text="Add Coupons"
                            // onPress={() => props?.navigation?.navigate("AddCoupon")}
                        />
                    </View>
                    <Text style={tw`text-center font-bold text-5 m-6`}>Or</Text>
                    <View style={tw`px-2`}>
                    <View>
                            <Text style={tw ` text-center mb-3 text-3.8`}>Service: (if your business is unable to offer a discount/coupon, e.g., realtors, attorneys, financial services, etc.)



                            </Text>
                        </View>
                        <RoundedButton
                            text="Add Services"
                            onPress={() => props?.navigation?.navigate("AddServices")}
                        />
                    </View>
                </View>

            </ScrollView>


            {/* {
                showDatePicker && (
                    <DateTimePicker
                        testID="dateTimePicker"
                        value={datePickerFor === "startDate" ? startDate || moment(new Date()).toDate() : endtDate || moment(new Date()).toDate()}
                        mode={"date"}
                        display="spinner"
                        // disabled={true}
                        onChange={(nativeEvent) => onChangeDate(nativeEvent)}
                        minimumDate={moment(new Date()).toDate()}
                        maximumDate={moment().add(30, 'day').toDate()}
                    />
                )
            } */}



            <Loader isVisible={props?.createCouponLoader} />
            {/* <CustomBottomTab {...props} isActive={true} selected={"AddCoupon"} /> */}
        </KeyboardAvoidingView>
    )
}

const formikEnhancer = withFormik({
    // validateOnMount: true,
    validationSchema: Yup.object().shape({
        couponTitle: Yup.string().required('Please enter coupon title'),
        description: Yup.string().required('Please enter description'),
        discount: Yup.string().required('Please enter discount'),
        dateOfExpiration: Yup.date(moment().add(30, 'day')).required('Please enter expiration date'),
        couponImage: Yup.object().required(),
        couponVideo: Yup.object()
    }),
    mapPropsToValues: (props) => {
        return {
            couponTitle: '',
            description: '',
            discount: '',
            dateOfExpiration: new Date(),
            couponImage: null,
            couponVideo: null
        };
    },
    handleSubmit: (payload, { props }) => {
        
    },
});


export default formikEnhancer(AddcouponServices);