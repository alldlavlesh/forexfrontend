import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import ToggleSwitch from 'toggle-switch-react-native'
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';


const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const SuccessPayment = (props) => {



    return (
        <View style={tw`flex-1 bg-[#002662]`}>

            <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} />
            <ScrollView>


                <View style={tw`items-center`}>
                <View style={tw` z-1 absolute `}>
                <Image source={ImageIcons.landing_img2} resizeMode='contain' style={tw` h-100 `}/>
              </View>
                    <View style={tw`h-91 w-12/12 bg-[#ffffff]  rounded-t-[8] justify-center items-center mt-90`}>
                        
                            <Text style={tw`font-bold text-2xl text-yellow-500`}>Thank you!!</Text>
                    
                        <Text style={tw `w-9/12 text-center text-sm mt-3`}><Text style={tw `font-bold text-4`}>Congratulations!</Text> Your deposit of $800 has been made successfully</Text>
                        <TouchableOpacity>
                <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                    end={{ x: 1.0, y: 0.1 }}
                    locations={[0.0, 1.0]} style={tw` h-16 w-65  mx-16 mt-13  items-center  justify-center rounded-[8] p-1 `}
                >
                    <Text style={tw`text-white text-sm font-bold  `}>Dashboard</Text>
                </LinearGradient>
            </TouchableOpacity>
                    </View>
                    
            
                </View>

                <Loader isVisible={props?.couponsListLoader} />
            </ScrollView>

            {/* <CustomBottomTab {...props} isActive={true} selected={"Coupon"} /> */}
        </View>
    )
}

export default SuccessPayment;