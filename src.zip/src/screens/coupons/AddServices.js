import React, { useEffect, useRef, useState } from 'react';
import { Text, Image, View, ScrollView,ImageBackground, Alert, StatusBar, TouchableOpacity, KeyboardAvoidingView, Platform, Keyboard, TextInput, Dimensions } from 'react-native';
//import { withFormik } from 'formik';
import { Formik } from 'formik'

// import DateTimePicker from '@react-native-community/datetimepicker';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CheckBox from '@react-native-community/checkbox';
import ImagePicker from 'react-native-image-crop-picker';
import moment from 'moment';
import momentzone from 'moment-timezone';
import Video from 'react-native-video';
import CustomBottomTab from '../../components/CustomBottomTab';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import styles from './styles';
import { Colors, ImageIcons, CommonStrings } from '../../common'
import InputField from '../../components/forms/inputField';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import Loader from '../../components/modals/Loader';
import DropdownButton from '../../components/dropdown';
import { discountOptions } from '../../common/StaticData';
import PercentagePicker from '../../components/dropdown/PercentagePicker';
import { RadioButton, Provider, Portal, Button, } from 'react-native-paper';
import Modal from 'react-native-modal';
import tw from 'twrnc';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
const AddServices = (props) => {

    const {
        navigation,    
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    //Reference
    const titleRef = useRef();
    const descriptionRef = useRef();
    const discountRef = useRef();

    // Local states
    const [expireDate, setExpireDate] = useState(moment().add(30, 'day'));
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [couponId, setCouponId] = useState();
    const [couponStatus, setCouponStatus] = useState("Draft");
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [discountType, setDiscountType] = useState('discountType1');
    const [couponTitle, setCouponTitle] = useState(undefined);
    const [description, setDescription] = useState(undefined);
    const [couponImage, setCouponImage] = useState(false);
    const [couponVideo, setCouponVideo] = useState(false);
    const [items, setItems] = useState(discountOptions);
    const [discount, setDiscount] = useState();
    const [open, setOpen] = useState(false);
    const [isOpenDiscountPicker, setIsOpenDiscountPicker] = useState(false);
    const [toggleCheckBox, setToggleCheckBox] = useState(false);
    const [currentDate, setCurrentDate] = useState('');
    const [modalvisible, setmodalVisible] = React.useState(false);
    const [alreadyPublish, setAlreadyPublish] = React.useState(false);
    const [submitted, setSubmit] = React.useState(false);


    let shareddate = props?.route?.params?.shared;

    useEffect(() => {
        props?.couponsList.map((item) => {
            if(item?.status == "Published" && submitted == false) {
                setAlreadyPublish(true)
            }
        });
        
    }, [props?.couponsList])

    useEffect(() => {

        props.getCouponList()
    
        setTimeout(() => {
            if (props?.route?.params && props?.route?.params?.couponData) {
                let couponData = props?.route?.params?.couponData;

                setCouponId(couponData?._id);
                setCouponTitle(couponData?.title)
                setDescription(couponData?.description)
                
                let fileName = couponData?.couponImage?.split('/').pop();
                let mimeType = couponData?.couponImage?.split('.').pop();
                let file = {
                    'uri': couponData?.couponImage,
                    'type': `image/${mimeType}`,
                    'name': fileName
                }                
                setCouponImage(file)
                setCouponStatus(couponData?.status);                                
            } else {
                //values.dateOfExpiration = moment().add(30, 'day').toDate();
                //setFieldValue("dateOfExpiration", moment().add(30, 'day').toDate());
            }
        }, 500);

    }, [])


    const openmodal = () => {
        setmodalVisible(true)
    }

    const closemodal = () => {
        setmodalVisible(false)
    }

    // Change expiration date
    const onChangeDate = (dateTime) => {
        if (dateTime) {
            setShowDatePicker(false)
            if (datePickerFor === "startDate") {
                setIsPlaceholderStartDate(false)
                setStartDate(dateTime);
            } else {
                setIsPlaceholderEndDate(false);
                setEndDate(dateTime);
            }
            setToggleCheckBox(false)
        }
    }

    // Select coupon image
    const onSelectImage = () => {
        ImagePicker.openPicker({
            width: 400,
            cropping: true,
            mediaType: 'photo',
            compressImageQuality: 0.5,
            height: 400,
        }).then(image => {
            if (image?.path) {
                let fileName = image?.path?.split('/').pop();
                let mimeType = image?.path?.split('.').pop();
                let file = {
                    'uri': image?.path,
                    'type': `image/${mimeType}`,
                    'name': fileName
                }
                setCouponImage(file); 
            }
        }).catch((error) => {
            
        });
    }


    const onSelectVideo = () => {
        ImagePicker.openPicker({
            mediaType: 'video',
            // height: 400,
            // width: 300,
            // cropping: true,
            duration: 30
        }).then(video => {
            if (video.duration < 15001) {
                if (video?.path) {
                    let fileVideoName = video?.path?.split('/').pop();
                    let fileVideoMimeType = video?.path?.split('.').pop();
                    let fileVideo = {
                        'uri': video?.path,
                        'type': `video/${fileVideoMimeType}`,
                        'name': fileVideoName
                    }
                }
            } else {
                Alert.alert(CommonStrings.AppName, "Too large video, duration must be less then 15 sec.");
            }
        }).catch((error) => {
            
        });
    }

    // Add Coupon request submission
    const handleAddCouponSubmit = (buttonType) => {
        setSubmit(true)
        Keyboard.dismiss();        
        if(couponTitle == undefined || description == undefined || couponImage == false || couponTitle == '' || description == '' || couponImage == '') {
            return;
        }
        openmodal();
    }

    const onSubmission = (couponStatus) => {
        const formData = new FormData();
        formData.append("couponType", "service");
        if(couponId!=''){
            formData.append("_id", couponId);
        }
        
        formData.append("title", couponTitle);
        formData.append("description", description);
        
        if(couponImage?.uri) {
            formData.append("couponImage", couponImage);
        }

        if (couponVideo?.uri) {
            formData.append("couponVideo", couponVideo);
        }
        formData.append("status", couponStatus);
        
        props.createNewService(formData, props.navigation, couponId);
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={80}
            onResponderReject={() => setShowDatePicker(false)}
            style={tw` flex-1 bg-white`}>
            <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
            <ScrollView
                keyboardShouldPersistTaps="handled"
                nestedScrollEnabled={true}
            // keyboardDismissMode='on-drag'
            //onScroll={() => { setShowDatePicker(false); datePickerFor === "startDate" ? setStartDate(startDate || moment(new Date()).toDate()) : setEndDate(endtDate || moment(new Date()).toDate()) }}
            >
                <View style={tw `flex-1 mt-2`}>
                    <InputField
                        id="couponTitle"
                        title="Title"
                        value={couponTitle}
                        onChangeText={(value)=> setCouponTitle(value)}
                        theme="white"
                        placeholder="Service Title"
                        maxLength={70}
                        reference={titleRef}
                        onSubmitEditing={() => descriptionRef?.current?.focus()}
                        returnKeyType="next"
                        customOuterStyle={{ borderColor : (submitted == true && (couponTitle == undefined || couponTitle == '')) ? 'red' : 'none', borderWidth:(submitted == true && couponTitle == undefined || couponTitle == '') ? 1 : 0 }}
                    />
                    <InputField
                        id="description"
                        title="Description"
                        value={description}
                        onChangeText={(value)=>setDescription(value)}
                        theme="white"
                        iconTintColor={Colors.DARK_GREY}
                        inputHeight={100}
                        multiline={true}
                        placeholder="Service Description"
                        underlineColorAndroid="transparent"
                        numberOfLines={5}
                        maxLength={250}                        
                        reference={descriptionRef}
                        onSubmitEditing={() => discountRef?.current?.focus()}
                        returnKeyType="next"
                        style={tw `justify-start text-4 mb-13`} 
                        customOuterStyle={{ borderColor : (submitted == true && (description == undefined || description == '')) ? 'red' : 'none', borderWidth:(submitted == true && (description == undefined || description == '')) ? 1 : 0 }}
                    />
        
                    <Text style={tw `relative text-gray-500 mt--5 ml-80`}>{`Limit: ${350 - String(description).length}`}</Text>
                    
                    <View style={tw `flex-1 items-center`}>
                        <Text style={[tw `text-[#323435] py-3 pl-5 text-4`,{fontFamily: Fonts.RalewayExtraBold}]}>{"Upload an Image"}</Text>
                        {
                            couponImage ?
                                <TouchableOpacity
                                    style={tw `mx-3 w-90 h-32 rounded-xl justify-center items-center border-2 border-gray-500 border-dashed`}
                                    onPress={() => onSelectImage()}
                                >
         
      
                                    <Image source={{ uri: couponImage?.uri }} style={styles.couponImage} />
                                </TouchableOpacity> :
                                <TouchableOpacity
                                    style={tw `mx-3 w-90 h-32 rounded-xl justify-center items-center border-2  ${(submitted == true && couponImage == false) ? 'border-red-500' : 'border-gray-500'}  border-dashed`}
                                    onPress={() => onSelectImage()}
                                >
                                    <Image source={ImageIcons.addIcon} style={tw `h-8 w-8 tint-gray-500 mt-4`} />
                                    <Text style={[tw `mt-8 text-center text-4 text-gray-300 `,{fontFamily: Fonts.QuestrialRegular}]}>Optimal image size is 300px by 300px. Upload here</Text>
                                </TouchableOpacity>
                        }
                    </View>

                    <View style={tw `flex-1 items-center`}>
                        <Text style={[tw `text-[#323435] py-3 pl-5 text-4`,{fontFamily: Fonts.RalewayExtraBold}]}>{"Upload an Video"}</Text>
                        {
                            values?.couponVideo ?
                                <TouchableOpacity
                                    style={tw `mx-3 w-90 h-27 rounded-xl justify-center items-center border-2 border-gray-500 border-2`}
                                    onPress={() => onSelectVideo()}
                                >
                                    <Video source={{ uri: values?.couponVideo?.uri }}   // Can be a URL or a local file.
                                        // ref={(ref) => {
                                        //   this.player = ref
                                        // }}                                      // Store reference
                                        onBuffer={this.onBuffer}                // Callback when remote video is buffering
                                        onError={this.videoError}               // Callback when video cannot be loaded
                                        style={tw `absolute`} />


                                </TouchableOpacity> :
                                <TouchableOpacity
                                    style={tw `mx-3 w-90 h-27 rounded-xl justify-center items-center border-2 border-gray-500 border-dashed`}
                                    onPress={() => onSelectVideo()}
                                >
                                    <Image source={ImageIcons.addIcon} style={tw `h-8 w-8 tint-gray-500 mt-4`} />
                                    <Text style={[tw `mt-7 text-center text-4 text-gray-300 `,{fontFamily: Fonts.QuestrialRegular}]}>Optimal video size is 30 sec. Upload here</Text>
                                </TouchableOpacity>
                        }
                    </View>

                    <View style={tw `mt-10 mx-4 mb-3`}>
                        <Text style={[tw `text-center text-blue-800 text-5`, {fontFamily: Fonts.RalewaySemiBold}]} onPress={() => props?.navigation?.goBack()}>Cancel</Text>
                    </View>
                    <View style={tw `mt-4 px-2 mb-20`}>
                        <RoundedButton
                            text="Publish"
                            onPress={() => handleAddCouponSubmit('Published')}
                        />
                    </View>                   
            </View>
        </ScrollView>

            <DateTimePickerModal
                isVisible={showDatePicker}
                mode="date"
                onConfirm={onChangeDate}
                onCancel={() => setShowDatePicker(false)}
                minimumDate={moment(new Date()).toDate()}
                maximumDate={moment().add(1, 'month').toDate()}
            />
            
            {openmodal &&
                <Provider>
                    <Portal>
                        <Modal transparent={true} visible={modalvisible} style={tw `bg-[#333333] mx--5 opacity-95 my--4`} onDismiss={closemodal} contentContainerStyle={tw `bg-[#000000] p-2 mx-5 rounded-xl py-3`}>
                            <View style={tw `ml-10 mr-10 mb-30`}>
                                <View style={tw `rounded-xl bg-white`}>    
                                    <View style={tw `bg-[#f2f2f2] p-4 self-center mt-3 rounded-lg`}>
                                        <Text style={tw `text-4 text-center text-[#231F20] mt-4 ml-2`}>You can NOT edit the service once published, it will be live until un published.</Text>
                                    </View>
                                    <View style={tw `mx-5 mb-8`}>
                                        <TouchableOpacity onPress={() => { closemodal(), onSubmission("Published") }} style={tw `bg-black rounded-xl p-2 justify-center`}>
                                            <Text style={tw `text-white text-center text-5 py-2`}>Publish</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        </Modal>
                    </Portal>
                </Provider>
            }

            {alreadyPublish &&

                <Provider>
                    <Portal>
                        <Modal transparent={true} visible={alreadyPublish} style={tw `bg-[#333333] mx--5 opacity-95 my--4`} onDismiss={closemodal} contentContainerStyle={tw `bg-[#ffffff] p-2 mx-5 rounded-xl py-3`}>
                            <View style={tw `ml-10 mr-10 mb-30`}>
                                <View style={tw `rounded-xl bg-white`}>
                                    <View style={tw `bg-[#f2f2f2] p-4 self-center mt-3 rounded-lg`}>
                                        <Text style={tw `text-4 text-center text-[#231F20] mt-4 ml-2`}>You already have a published Coupon/Services, you can only publish one coupon at a time.</Text>
                                    </View>
                                    <View style={tw `mx-5 mb-8`}>
                                        <TouchableOpacity onPress={() => { navigation.navigate('Coupons') }} style={tw `bg-black rounded-xl p-2 justify-center`}>
                                            <Text style={tw `text-white text-center text-5 py-2`}>Go Back</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        </Modal>
                    </Portal>
                </Provider>
            }

            <Loader isVisible={props?.createCouponLoader} />
            {/* <CustomBottomTab {...props} isActive={true} selected={"AddCoupon"} /> */}
        </KeyboardAvoidingView>
    )
}

export default AddServices;