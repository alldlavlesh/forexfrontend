import React, { useEffect, useState, useRef } from 'react';
import { Text, View, ScrollView, Dimensions, Image, Animated, Linking, ImageBackground, Easing, Alert ,TouchableOpacity} from 'react-native';
import { RoundedButton } from '../../components/forms/button';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import styles from './styles';
import moment from 'moment';
import tw from 'twrnc';
import Video from 'react-native-video';
import Loader from '../../components/modals/Loader';
import { Colors, CommonStrings, ImageIcons } from '../../common';
const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

const CouponDetail = (props) => {

    //Local states
    const [couponDetail, setCouponDetail] = useState();
    const [imageLoading, setImageLoading] = useState(true);
    const imgBgRefAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        if (props?.route?.params && props?.route?.params?.couponData) {
            let { couponData } = props?.route?.params;
            setCouponDetail(couponData);
        }
        animateShimmer();
    }, [])

    

    const currentdate = moment().format("MM/DD/YYYY");
    const now = moment()
    
    const didCall = (phoneNo) => {
        let phoneNumber = '';
        if (Platform.OS === 'android') {
            phoneNumber = `tel:${phoneNo}`;
        }
        else {
            phoneNumber = `tel://${phoneNo}`;
        }

        Linking.openURL(phoneNumber);
    }

    // Preloading animation for coupon image
    const animateShimmer = () => {
        Animated.loop(
            Animated.timing(imgBgRefAnim, {
                toValue: 0.7,
                duration: 3000,
                delay: 1000,
                easing: Easing.linear,
                useNativeDriver: false
            })
        ).start()
    }

    const handleAddCouponSubmit = (couponStatus) => {
        
        let message = "All field's value needs to be filled before publishing this coupon";
        if (couponStatus === "Deactivated") {
            onSubmission(couponStatus);
            return;
        }

        if (couponDetail?.title && couponDetail?.description) {
            message = ""
        }
        if (message === "") {
            onSubmission(couponStatus);
        } else {
            Alert.alert(
                CommonStrings.AppName,
                message,
                [
                    {
                        text: 'Cancel',
                        onPress: () => props?.navigation?.goBack(),
                        style: 'cancel'
                    },
                    { text: 'OK', onPress: () => props?.navigation?.navigate("AddCoupon", { couponData: couponDetail }) }
                ],
                { cancelable: false }
            );
        }
    }

    const onSubmission = (couponStatus) => {

        const formData = new FormData();
        // let fileName = couponDetail?.couponImage?.split('/').pop();
        // let mimeType = couponDetail?.couponImage?.split('.').pop();
        // let file = {
        //     'uri': couponDetail?.couponImage,
        //     'type': `image/${mimeType}`,
        //     'name': fileName
        // }
        formData.append("_id", couponDetail?._id)
        formData.append("title", couponDetail?.title)
        formData.append("description", couponDetail?.description)
        // if(couponDetail.couponType == 'coupon'){
        //     formData.append("discount", String(couponDetail?.discount))
        //     formData.append("startDate", moment(couponDetail?.startDate).toISOString())
        //     formData.append("discountType", couponDetail?.discountType?.discountType);
        // }
        
        // if (couponDetail.noExpiration) {
        //     formData.append("noExpiration", couponDetail.noExpiration);
        // } else {
        //     if (couponDetail?.dateOfExpiration) {
        //         formData.append("dateOfExpiration", moment(couponDetail?.dateOfExpiration).toDate().toISOString())
        //     }
        // }
        // formData.append("couponImage", file)
        formData.append("status", couponStatus) // 'Draft', 'Published', 'D eactivated' 
        // formData.append("isEditMode",true) // 'Draft', 'Published', 'Deactivated' 

        if(couponDetail.couponType == 'coupon'){
            props.createNewCoupon(formData, props.navigation, couponDetail?._id);
        } else {
            props.createNewService(formData, props.navigation, couponDetail?._id);
        }            
    }

    
    return (
        <View style={styles.root}>
            <ScrollView keyboardShouldPersistTaps="always">
                <ImageBackground source={ImageIcons.detailbacground} resizeMode="stretch" style={tw`flex-1	items-center justify-center w-full h-auto py-2 mb-9 `}>

                    <View>
                        <View style={[styles.heading, { paddingBottom: '5%', marginTop: 20 }]}>
                            <View style={styles.imageContainer}>
                                {couponDetail?.couponVideo &&
                                    <View style={{ backgroundColor: '#000000', justifyContent: 'center', alignItems: 'center' }}>
                                        <Video source={{ uri: couponDetail?.couponVideo }} repeat={true}
                                            resizeMode='cover'
                                            style={{ width: deviceWidth / 1.2 + 25, height: deviceWidth / 2 }} />
                                    </View>
                                }
                                <Image source={{ uri: couponDetail?.couponImage }} style={[styles.couponImage, { height: imageLoading ? 1 : hp('35%'), marginTop: '4%', borderRadius: 10 }]} onLoadEnd={() => setImageLoading(false)} />
                                {imageLoading && (
                                    <Animated.View
                                        style={[styles.couponImage, {
                                            backgroundColor: imgBgRefAnim.interpolate({
                                                inputRange: [0, 0.5, 1],
                                                outputRange: [Colors.GREY, Colors.LIGHT_GREY, Colors.LIGHTER_GREY]
                                            })
                                        }]}
                                    />
                                )}
                            </View>
                        </View>
                        <View >
                            <Image source={ImageIcons.Linevertical} style={[tw`w-4/5 mx-4 ml-10`, { tintColor: '#000' }]}></Image>
                        </View>
                        
                            <View style={tw`ml-12 mt-5`}>
                                <Text style={tw`align-middle font-semibold capitalize text-[#000000] text-4`}>{couponDetail?.title}</Text>
                            </View>
                            <View>
                                <Text style={tw`text-base  text-gray-500 align-middle ml-12 mt-2 capitalize`} numberOfLines={1} ellipsizeMode='tail' >{(couponDetail?.store && couponDetail?.store?.doingBusinessas && couponDetail?.store?.doingBusinessas != "") ? couponDetail?.store?.doingBusinessas : couponDetail?.store?.businessName}</Text>
                            </View>
                            
                            
                            {couponDetail?.couponType == "coupon" &&
                                <View style={tw`ml-12`}>
                                    <Text style={tw`align-middle font-bold text-[#2F479D] text-xs mt-4`} numberOfLines={1} ellipsizeMode='tail'>
                                        {couponDetail?.discountType?.discountType == 'discountType3' ? couponDetail?.discount + `% Off` : couponDetail?.discountType?.discountType == 'discountType4' ? `$` + couponDetail?.discount : couponDetail?.discount}</Text>
                                </View>
                            }
                        
                        
                        <View style={tw`ml-12 mt-4 w-10/12`}>
                            <Text style={tw`font-normal capitalize text-[#323435] text-3 text-left `}>{couponDetail?.description}</Text>
                        </View>

                        <View style={tw`ml-12 mt-4 w-10/12`}>
                            {couponDetail?.couponType && <Text style={tw`font-normal capitalize text-[#323435] text-3 text-left `}>{'Coupon Type: '+couponDetail?.couponType}</Text>}
                        </View>

                        <View style={tw`flex-row ml-12 mt-5 items-center`}>

                            {couponDetail?.couponType == "coupon" &&
                                <View style={tw`flex-row items-center w-1/3`}>
                                    <Image source={ImageIcons.calculater} style={[tw`w-4 h-4`, { tintColor: '#000' }]}></Image>
                                    <Text style={tw`align-middle font-normal text-[#767676] text-sm pl-2`}>{''}Exp: {moment(couponDetail?.dateOfExpiration)?.format('MM-DD-YY')}</Text>
                                </View>
                            }
                        </View>
                        <View style={tw`flex-row ml-12 mt-2 items-center`}>
                            {couponDetail?.store?.phone && 
                            <TouchableOpacity style={tw`flex-row items-center `} onPress={() => didCall(couponDetail.store.countryCode + couponDetail?.store?.phone)}>
                                <Image source={ImageIcons.phone} resizeMode={'contain'} style={[tw`h-4`, { tintColor: '#000' }]}></Image>
                                <Text style={tw`align-middle font-normal text-[#767676] text-sm pl-2`}>{couponDetail.store.countryCode +"-"+ couponDetail?.store?.phone}</Text>
                            </TouchableOpacity>
                            }
                            
                            
                            {couponDetail?.couponType == "coupon" &&
                            <TouchableOpacity style={tw`ml-3 flex-row items-center w-1/3`}>
                                <Image source={ImageIcons.reviewrating} style={[tw`h-5 w-5`,{tintColor:'#000'}]}></Image>
                                <Text style={tw`align-middle font-bold text-[#767676] text-[3] pl-1`} >{(couponDetail?.store?.totalLureScore > 0) ? couponDetail?.store?.totalLureScore.toFixed(2) : 0}</Text>
                            </TouchableOpacity>
                             }
                        </View>
                        
                        <View style={tw`flex-row ml-12 mt-2 items-center`}>
                            {couponDetail?.store && couponDetail?.store?.website &&
                                <TouchableOpacity style={tw`flex-row items-center`} onPress={() => Linking.openURL(`https://${couponDetail.store.website}`)}>
                                    <Image source={ImageIcons.globe} style={[tw`w-5 h-5`, { tintColor: '#000' }]}></Image>
                                    <Text style={tw`align-middle font-normal text-[#767676] text-sm pl-2`} numberOfLines={1} ellipsizeMode='tail' >{couponDetail?.store?.website}</Text>
                                </TouchableOpacity>
                            }
                        </View>
                        {/* <RowItem label="Title" value={couponDetail?.title || "-"} style={tw`align-middle font-semibold capitalize text-[#000] text-xs`}/> */}
                        {/* <RowItem label="Description" value={couponDetail?.description || "-"} /> */}
                        {/* {couponDetail?.couponType == "coupon" &&
                    
                        <RowItem label="Discount" value={couponDetail?.discount || "-"} />
                    } */}
                        {/* {couponDetail?.couponType == "coupon" &&
                            <RowItem label="Expiration" value={couponDetail?.dateOfExpiration ? moment(couponDetail?.dateOfExpiration).format("MM/DD/YYYY") : "-"} />
                        }
                        <RowItem label="Status" value={couponDetail?.status || "-"} /> */}
                    </View>

                
                {
                    (couponDetail?.couponType == 'service') && 
                    <View style={{ marginTop: '10%' }}>
                        <RoundedButton
                            text={(couponDetail?.status == "Expired") ? "Publish" : "UnPublish"}
                            onPress={() => handleAddCouponSubmit((couponDetail?.status == "Expired") ? "Published" : "Deactivated")}
                            //disabled={couponDetail?.status === "Deactivated" ? true : false}
                            customStyle={{ opacity: 1, padding:20 }}
                        />
                    </View>
                }


{/* 
                    {now.isAfter(couponDetail?.dateOfExpiration) || couponDetail?.status === "Expired" &&
                        <View style={{ marginTop: '20%', paddingHorizontal: '22%' }}>
                            <RoundedButton
                                text={couponDetail?.status === "Expired" ? "Publish" : "Unpublish"}
                                onPress={() => handleAddCouponSubmit(couponDetail?.status === "Published" ? "Deactivated" : "Published")}
                                disabled={couponDetail?.status === "Deactivated" ? true : false}
                                customStyle={{ opacity: couponDetail?.status === "Deactivated" ? 0.5 : 1 }}
                            />
                        </View>
                    } */}
                </ImageBackground>

            </ScrollView>
            <Loader isVisible={props?.createCouponLoader} />
        </View>
    )
}

const RowItem = ({ label, value }) => {
    return (
        <View style={styles.trnsDetailRow}>
            <Text style={{ width: '45%' }}>{label}</Text>
            <Text style={[styles.valueText, { width: '45%' }]}>{value}</Text>
        </View>
    )
}

export default CouponDetail;