import React, { useEffect, useState, useRef } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, ScrollView, Alert, Dimensions, Image, ImageBackground, TextInput, Keyboard } from 'react-native';
import { Fonts, Colors, ImageIcons, CommonStrings } from '../../common';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import InputField from '../../components/forms/inputField';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import { BarChart } from "react-native-chart-kit";
import styles from './styles';
import InsightFilterModal from '../../components/modals/InsightFilterModal';
import moment from 'moment';
import Loader from '../../components/modals/Loader';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import { WebView } from 'react-native-webview';
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

const DoneShare = (props) => {
    var amount = props.initiateReqData.amount;
    var transactionId = props.initiateReqData._id;
    //Staging: <script src="https://epay.me/v2sdk/directsdk.js"></script> 

    function onMessage(data) {
        alert(data.nativeEvent.data);
    }

    function sendDataToWebView() {
        webviewRef.current.postMessage('Data from React Native App');
    }

    const webviewRef = useRef();

    const {
        navigation,
    } = props;
    const jsCode = `myFunction()`;
    return (
        <WebView javaScriptEnabledAndroid={true} injectedJavaScript={jsCode} ref={webviewRef} onMessage={onMessage} source={{
            html: `<!DOCTYPE html><html lang="en" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">       
        <head> 
    <script src="https://epay.me/sdk/v2/stage-websdk.js"></script>     
    <script> 
    function myFunction(){ 
    const options = { 
    channelId:"WEB", 
    customerId:"12", 
    merchantType:"ECOMMERCE", 
    merchantId:"62a99db7ee0ca8d01246f53c", 
    orderID:"${transactionId}", 
    orderDescription:"test", 
    orderAmount:"${amount}", 
    orderCurrency:"USD", 
    email:"${props.loginCredentials.email}", 
    countrycode:"971", 
    mobilenumber:"0000000000", 
    name:"${props.loginCredentials.name}", 
    successHandler: async function(response) { 
              // Handle success response 
              window.location.href = "http://44.211.128.126:6565/v1/users/getTransactionDetail";
            }, 
    failedHandler: async function(response) { 
              // Handle failure response 
              window.location.href = "http://44.211.128.126:6565/v1/users/getTransactionDetail"; 
            } 
    } 
          const epay = new Epay(options); 
          epay.open(options);  
        } 

        const openButton = document.getElementById("openButton");
    openButton.addEventListener("click", myFunction);
      </script> 
    </head>   
        <body style="background-color: #FFF; margin: auto; text-align: center; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;">
          
            
        </body>
        
        </html>` }} style={{ flex: 1, width: screenWidth, height: 400 }} />

    )
}

export default DoneShare;

