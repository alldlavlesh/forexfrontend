import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, ImageBackground, TouchableOpacity, Image, ScrollView } from 'react-native';
import { Fonts, Colors, ImageIcons, Api } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import Modal from 'react-native-modal';
//import messaging from '@react-native-firebase/messaging';
//import { firebase, ShortcutBadge } from '@react-native-firebase/app';
//import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';
import AppIntroSlider from 'react-native-app-intro-slider';
import branch from 'react-native-branch';


const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const Coupons = (props) => {
    const slider = useRef();
    const [selectedButton, setSelectedButton] = useState(null);
    const handleButtonPress = (buttonType) => {

        setSelectedButton(buttonType);
        setTimeout(() => {
            if (buttonType === 'Verification') {
                props.navigation.navigate('Verification'); // Navigate to the verification screen
            }
        }, 100);
    };


    // useEffect(() => {
    //     if (props.navigation.isFocused()) {
    //         props?.dashboardData();
    //     }
    // }, [props.navigation.isFocused()]);
    useEffect(() => {

       

    }, []);

    useFocusEffect(
        React.useCallback(() => {
           props?.dashboardData();
           props?.getBannerList();
        }, [])
      );

    useEffect(() => {
        var i = 0;
        const interval = setInterval(() => {
            slider.current.goToSlide(i % props?.bannerList?.length, true)
            i++;
        }, 3000);

        return () => {
            clearInterval(interval);
        };
    }, [props?.bannerList]);

    const slides = [
        {
            key: 's1',
            image: ImageIcons.Banner,
            backgroundColor: '#1F1F1F',
        },
        {
            key: 's2',
            image: ImageIcons.Banner,
            backgroundColor: '#1F1F1F',
        },
        {
            key: 's3',
            image: ImageIcons.Banner,
            backgroundColor: '#1F1F1F',
        },

    ];


    const RenderItem = ({ item }) => {
        return (
            <View style={{ flex: 1, }}>
                {/* source={{ uri: Api.fileUrl + item?.image }} */}
                <Image style={tw`h-45  w-11/12 rounded-[5] bg-[#171717] mx-auto  mt-6 `} source={ImageIcons.Banner} />
            </View>
        );
    };
    
    const currencyFormat = (num) => {
        return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    }

    return (
        <View style={tw`flex-1 bg-white`}>


            <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
            <CustomHeaderTab  {...props} isActive={false} selected={"Coupon"} parent={true} name={`Hi, ${(props?.loginCredentials?.userName)?.split('@')[0]?.toUpperCase()}`} />

            <ScrollView>
                <AppIntroSlider
                    ref={(ref) => (slider.current = ref)}
                    data={slides}
                    data={props?.bannerList}
                    renderItem={RenderItem}
                    autoPlay={true}
                    nextLabel={false}
                    doneLabel={false}
                    dotStyle={{
                        backgroundColor: "#8E8E8E",
                        top: 60,
                        height: 8,
                        width: 8,
                    }}
                    activeDotStyle={{
                        backgroundColor: "#171717",
                        top: 60,
                        width: 8,
                        height: 8
                    }}
                />
                <View style={tw`mb-20  flex justify-center items-center `}>
                    {/* <View> */}

                    {/* </View> */}
                    <View style={tw`h-37 w-11/12 bg-[#171717] shadow-[#7D64FF]  shadow-2xl rounded-[5]   mt-10 `}>
                        {/* {/ <ImageBackground source={ImageIcons.image} style={tw`h-35 w-11.5/12  mt-1`}> /} */}
                        <View style={tw`flex-row justify-around p-2`}>
                            <View style={tw`flex-column`}>
                                <Text style={tw`text-[#B8B8B8] text-center font-bold text-3.5 p-1`}>Total Portfolio Amount</Text>
                                <View style={tw`flex-row`}>
                                    <Text style={tw`text-[#ffffff] text-center font-bold text-5 p-1`}>{currencyFormat(props?.dashboarddata?.portfolioAmount)}</Text>
                                    <Text style={tw`text-[#B8B8B8] text-center font-bold text-3.5 mt-2.5 ml-1.5`}>USD</Text>
                                </View>
                                <Text style={tw`text-[#B8B8B8] text-center font-bold text-3.5 p-1`}>Total Invested Amount</Text>
                                {props?.dashboarddata?.investedAmount!=null &&
                                    <View style={tw`flex-row`}>
                                        <Text style={tw`text-[#ffffff] text-center font-bold text-5 p-1`}>{currencyFormat(props?.dashboarddata?.investedAmount)}</Text>
                                        <Text style={tw`text-[#B8B8B8] text-center font-bold text-3.5 mt-2.5 ml-1.5`}>USD</Text>
                                    </View>
                                }
                            </View>


                            <View style={tw`flex-row mt-15`}>
                                <TouchableOpacity style={tw`flex-row bg-[#2AEFB4] h-9 w-27 mt-6 rounded-[3]`}
                                // onPress={() => props?.navigation?.navigate("Deposite")}
                                >
                                    <Image source={ImageIcons.Fill} resizeMode='contain' style={tw`h-4 w-4 my-2.5 ml-3.5`} />
                                    <Text style={tw`text-black font-bold text-3.5 ml-2  my-2`}>+18.05%</Text>
                                </TouchableOpacity>

                            </View>
                        </View>
                        {/* {/ </ImageBackground> /} */}
                    </View>


                    {/* {/ style={tw`h-45  w-11/12 rounded-[5] bg-[#171717] mx-auto  mt-6 `} /} */}

                    <Text style={tw`text-[#000000] text-left text-5.5 p-1 mt-4  w-11/12  `}>Actions</Text>
                    <View style={tw`flex-row w-11/12 justify-between  flex items-center`}>

                        <View style={tw`flex-row h-14  w-5.7/12 bg-white shadow-[#7D64FF] shadow-2xl  justify-around rounded-[3] border-2px items-center  `}>
                            <Image source={ImageIcons.Deposit} resizeMode='contain' style={tw`h-6 w-6  `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Deposite")}>
                                <Text style={tw`text-[#000000] text-base  text-sm  `}>Deposit</Text>
                            </TouchableOpacity>
                            <Image source={ImageIcons.pathRight} resizeMode='contain' style={tw`h-2.5 w-2.5 `} />
                        </View>


                        <View style={tw`flex-row h-14  w-5.7/12 bg-white shadow-[#7D64FF] shadow-2xl  justify-around rounded-[3] border-2px items-center  `}>
                            <Image source={ImageIcons.Recieved} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Market")}>
                                <Text style={tw`text-[#000000] text-base  text-sm  `}>Explore Assets</Text>
                            </TouchableOpacity>
                            <Image source={ImageIcons.pathRight} resizeMode='contain' style={tw`h-2.5 w-2.5 `} />
                        </View>


                    </View>

                    <View style={tw`flex-row w-11/12 justify-between  items-center flex mt-4`}>
                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px  `}>
                            <Image source={ImageIcons.Withdraw} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Withdraw_USD")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> Withdraw</Text>
                            </TouchableOpacity>

                        </View>
                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.Refresh} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Market")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> Forex</Text>
                            </TouchableOpacity>
                            {/* {/ <Text style={tw`text-[#000000]  text-base mx-5 text-sm`}> Forex</Text> /} */}
                        </View>

                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.Staking} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Market")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> Stock</Text>
                            </TouchableOpacity>
                            {/* {/ <Text style={tw`text-[#000000]  text-base mx-5 text-sm`}> Stock</Text> /} */}
                        </View>
                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.NFT} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Sell")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> Sell USDT</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={tw`flex-row w-11/12 justify-between  items-center flex mt-4 `}>

                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.AML} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Portfolio")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> Ledger</Text>
                            </TouchableOpacity>
                        </View>



                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.Cup} resizeMode='contain' style={tw`h-6 w-6 `} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("News")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> News</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.Invite} resizeMode='contain' style={tw`h-6 w-6`} />
                            <TouchableOpacity onPress={() => props?.navigation?.navigate("Refferal")}>
                                <Text style={tw`text-[#000000]  text-base  text-sm`}> Invite</Text>
                            </TouchableOpacity>
                            {/* {/ <Text style={tw`text-[#000000]  text-base mx-5 text-sm`}> Invite</Text> /} */}
                        </View>
                        <View style={tw`h-18.5 w-18.5 bg-white shadow-[#7D64FF]  justify-center flex items-center shadow-2xl rounded-[4] border-2px `}>
                            <Image source={ImageIcons.Support} resizeMode='contain' style={tw`h-6 w-6`} />
                            <Text style={tw`text-[#000000]  text-base  text-sm`}> Support</Text>
                        </View>
                    </View>



                    <View style={tw`h-45 w-11/12 bg-[#171717] shadow-[#7D64FF]  shadow-2xl rounded-[4] border-2px mx-3.5 mt-8 `}>
                        <ImageBackground source={ImageIcons.image} style={tw`h-40 w-11.5/12 mx-2 mt-1`}>
                            <Text style={tw`text-white text-left font-bold text-5.5 p-1 ml-5 mt-3 mr-7`}>Get Profit up to 30% per month USD with our AI managed accounts</Text>
                            <View style={tw`flex-row ml-5 mt-2`}>
                                <TouchableOpacity onPress={() => props.navigation.navigate("Totalinvest")}>
                                    <LinearGradient colors={['#E0F64B', '#E0F64B']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw`h-9 w-30 mt-2 rounded-[3]    `}>
                                        <Text style={tw`text-black text-center font-bold text-3.5 p-2`}>Invest Now</Text>
                                    </LinearGradient>
                                </TouchableOpacity>
                            </View>
                        </ImageBackground>
                    </View>


                </View>

                <View style={tw`mt-5 w-11/12`}>

                    <Loader isVisible={props?.couponsListLoader} />

                </View>
            </ScrollView>



            <CustomBottomTab {...props} isActive={true} selected={"Coupon"} />
        </View>
    )
}

export default Coupons;