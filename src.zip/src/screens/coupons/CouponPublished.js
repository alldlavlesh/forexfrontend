import React, { useEffect, useState, useRef } from 'react';
import { Text, View, ScrollView, Image, Dimensions, Animated, Platform, Easing, Linking, Alert, TouchableOpacity } from 'react-native';
import { RoundedButton } from '../../components/forms/button';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import styles from './styles';
import moment from 'moment';
import Loader from '../../components/modals/Loader';
import { Colors, CommonStrings, ImageIcons } from '../../common';
const screenHeight = Dimensions.get('window').height;
const CouponPublished = (props) => {

    //Local states
    const [couponDetail, setCouponDetail] = useState();
    const [imageLoading, setImageLoading] = useState(true);
    const imgBgRefAnim = useRef(new Animated.Value(0)).current;



    const currentdate = moment().format("MM/DD/YYYY");
    const now = moment()

    // Preloading animation for coupon image


    // const shareCouponStatic = async () => {            
    //     let buo = await branch.createBranchUniversalObject('content/12345', {
    //         title: 'My Content Title',
    //         contentDescription: 'My Content Description',
    //         contentImageUrl: "https://wallpon.s3.amazonaws.com/167093223663463905b2d8ff6dd5e1b430e63.jpg",
    //         canonicalUrl: "https://wallpon.s3.amazonaws.com/167093223663463905b2d8ff6dd5e1b430e63.jpg",
    //         contentMetadata: {
    //             customMetadata: {
    //                 key1: 'value1'
    //             }
    //         }
    //     })

    //     let linkProperties = {
    //         feature: 'sharing',
    //         channel: 'facebook',
    //         campaign: 'content 123 launch'  
    //     }
            
    //     let controlParams = {
    //         $desktop_url: 'https://example.com/home',
    //         custom: 'data'   
    //     }
            
    //     let {url} = await buo.generateShortUrl(linkProperties, controlParams)
    //     
            
    //     let shareOptions1 = { 
    //         messageHeader: 'Check this out', 
    //         messageBody: 'No really, check this out!' 
    //     }
            
    //     let linkProperties1 = {
    //         feature: 'sharing', 
    //         channel: 'facebook' 
    //     }
            
    //     let controlParams1 = { 
    //         $desktop_url: url, 
    //         $ios_url: url
    //     }
            
    //     let {channel, completed, error} = await buo.showShareSheet(shareOptions1, linkProperties1, controlParams1)

    // }
    
    

    // const shareCoupon = async (item) => {
    //     
    //     let messageCaption = "Check out this coupon on WallPon\n" + item.title + "\n\n" + item.description;
    //     let sharedByUser = item.title;
        
    //     let linkShare = "http://coupons.wallpon.com/coupondetail/" + item._id;

    //     let buo = await branch.createBranchUniversalObject('content/12345', {
    //         title: 'Check out this coupon on WallPon',
    //         contentDescription: item.title + "-" + item.description,
    //         contentImageUrl: item.couponImage,
    //         canonicalUrl: item.couponImage,
    //         contentMetadata: {
    //             ratingAverage: 5,
    //             customMetadata: {
    //                 itemType: 'coupon',
    //                 itemId: item._id,
    //                 contentImageUrl: item.couponImage,
    //                 itemDetails: "Check out this coupon on WallPon\n\n" + item.title + "\n\n-\n\n" + item.description
    //             }
    //         }
    //     })

    //     let linkProperties = {
    //         feature: 'sharing',
    //         channel: 'social',
    //         campaign: "Check out this coupon on WallPon\n\n" + item.title + "\n\n-\n\n" + item.description
    //     }
            
    //     let controlParams = {
    //         $desktop_url: linkShare,
    //         $ios_url: linkShare,
    //         custom: "Check out this coupon on WallPon\n\n" + item.title + "\n\n-\n\n" + item.description
    //     }
            
    //     let {url} = await buo.generateShortUrl(linkProperties, controlParams)
        
        
    //     let shareOptions = { messageHeader: sharedByUser, messageBody: messageCaption }
    //     let {channel, completed, error} = await buo.showShareSheet(shareOptions, linkProperties, controlParams)

   
    // }


    const downloadwallponsads = (id) => {

        let linkShare = "https://o3i5v.app.link?coupon=" + id;
        Linking.openURL(linkShare);
        // if (Platform.OS === 'android') {
        //     Linking.openURL('https://play.google.com/store/apps/details?id=com.wallpon.user');
        // }
        // else {
        //     Linking.openURL('https://apps.apple.com/in/app/wallpon/id1573454624') ;
        // }
    }

    return (

        <View style={[styles.congrates_root]}>
                
                <View style={{ height:150 }}>
                    <View style={{ position:'absolute', top: 45, marginLeft:'5%' }}>
                        <Image source={ImageIcons.social1} style={{ height: 55, width: 55 }} />
                    </View>                

                    <View style={{ position:'absolute', top: 45, marginLeft:'82%' }}>
                        <Image source={ImageIcons.social15} style={{ borderRadius:27.5, height: 55, width: 55 }} />
                    </View>
                    
                    <View style={{ position:'absolute', top: 5, marginLeft:'25%' }}>
                        <Image source={ImageIcons.social3} style={{ height: 55, width: 55 }} />
                    </View>                

                    <View style={{ position:'absolute', top: 5, marginLeft:'65%' }}>
                        <Image source={ImageIcons.social4} style={{ height: 55, width: 55 }} />
                    </View>
                   
                    <View style={{ position:'absolute', top: 80, marginLeft:'25%' }}>
                        <Image source={ImageIcons.social5} style={{ height: 55, width: 55 }} />
                    </View>
                    <View style={{ position:'absolute', top: 80, marginLeft:'65%' }}>
                        <Image source={ImageIcons.social6} style={{ height: 55, width: 55 }} />
                    </View>
                    <View style={{ position:'absolute', top: 45, marginLeft:'45%' }}>
                        <Image source={ImageIcons.social7} style={{ height: 55, width: 55 }} />
                    </View>
                </View>


                <View style={{ }}>
                    <View style={{ alignSelf:'center' }}>
                        <Image source={ImageIcons.greenmark} style={{ height: 55, width: 55, tintColor: "#219653" }} />
                    </View>
                    <View style={{  alignItems: "center" }}>
                        <Text style={{ textAlign: "center", fontSize: 30, fontWeight: "bold", color: "#231F20" }}>
                            Congrats!
                        </Text>
                    </View>
                    
                    <View style={{  textAlign: "center" }}>
                    { Platform.OS === 'ios' &&
                        <Text style={{ fontSize: 16,lineHeight:20,textAlign:'center' }}>
                            Now let's share your coupon with customers, friends and family to start driving redemptions!!  
                            {"\n"}
                            {"\n"}
                            Click on the Share button
                        </Text>
                    }
                    { Platform.OS === 'android' &&
                        <Text style={{ fontSize: 16,lineHeight:20,textAlign:'center' }}>
                            Now let's share your coupon with customers from WallPon App, friends and family to start driving redemptions!!                              
                        </Text>
                    }
                    </View>
                    { Platform.OS === 'ios' &&
                    <TouchableOpacity
                        style={{ marginVertical: "5%" }}>
                        <RoundedButton onPress={() => shareCoupon(props.createCouponSuccess)} text='Share Coupon' />
                    </TouchableOpacity>
                    }
                    <TouchableOpacity
                        style={{ marginVertical: "5%" }}>
                            { Platform.OS === 'ios' &&
                        <RoundedButton onPress={() => props.navigation.navigate('DoneShare') } text='Done Sharing' />} 
                        { Platform.OS === 'android' && <RoundedButton onPress={() => props.navigation.navigate('DoneShare') } text='Done' />} 
                    </TouchableOpacity>
                </View>


                
                    {/*<View style={{ position:'absolute', top: 550, marginLeft:'60%' }}>
                        <Image source={ImageIcons.social8} style={{ height: 55, width: 55 }} />
                    </View>*/}

                    <View style={{ position:'absolute', top: 550, marginLeft:'10%' }}>
                        <Image source={ImageIcons.social9} style={{ height: 55, width: 55 }} />
                    </View>
                    <View style={{ position:'absolute', top: 550, marginLeft:'82%' }}>
                        <Image source={ImageIcons.social10} style={{ height: 55, width: 55 }} />
                    </View>
                    <View style={{ position:'absolute', top: 500, marginLeft:'25%' }}>
                        <Image source={ImageIcons.social11} style={{ height: 55, width: 55 }} />
                    </View>
                    
                    <View style={{ position:'absolute', top: 500, marginLeft:'65%' }}>
                        <Image source={ImageIcons.social12} style={{ borderRadius:27.5, height: 55, width: 55 }} />
                    </View>
                    <View style={{ position:'absolute', top: 600, marginLeft:'25%' }}>
                        <Image source={ImageIcons.social13} style={{ height: 55, width: 55, borderRadius:27.5 }} />
                    </View>
                    <View style={{ position:'absolute', top: 600, marginLeft:'65%', borderRadius:27.5 }}>
                        <Image source={ImageIcons.social14} style={{ height: 65, width: 65, borderRadius:27.5 }} />
                    </View>
                
                
               

            <Loader isVisible={props?.createCouponLoader} />
        </View>
    )
}

const RowItem = ({ label, value }) => {
    return (
        <View style={styles.trnsDetailRow}>
            <Text style={{ width: '45%' }}>{label}</Text>
            <Text style={[styles.valueText, { width: '45%' }]}>{value}</Text>
        </View>
    )
}

export default CouponPublished;