// React Native App Intro Slider using AppIntroSlider
// https://aboutreact.com/react-native-app-intro-slider/
// Intro slider with a button in the center

// import React in our code
import React, { useState, useRef, useEffect } from 'react';
import { Fonts, Colors, ImageIcons, CommonStrings,Api } from '../../common';
import tw from 'twrnc'
import Loader from '../../components/modals/Loader';
import { WebView } from 'react-native-webview';
const screenWidth = Dimensions.get('window').width;
// import LinearGradient from 'react-native-linear-gradient';

// import Icon from 'react-native-vector-icons/FontAwesome';
// import all the components we are going to use
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  Image,
  Button,
  FlatList,
  ImageBackground,
  TouchableOpacity,
  StatusBar,
  Dimensions,
  ScrollView,
  Alert
} from 'react-native';

//import AppIntroSlider to use it
import LinearGradient from 'react-native-linear-gradient';
import AppIntroSlider from 'react-native-app-intro-slider';
import { SwipeablePanel } from 'rn-swipeable-panel';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import { batch } from 'react-redux';
import CheckBox from '@react-native-community/checkbox';
import select from '../../common/select.png'
import { TextInput } from 'react-native-gesture-handler';
import { addTransaction } from '../../redux/actions/Coupon';
import SwipeButton from 'rn-swipe-button';
import ImagePicker from 'react-native-image-crop-picker';

// import Deposite from '../../../^/untitled/ts-nul-authority/Untitled-1';


const Deposite = (props) => {

  const {
    navigation,
    values,
    errors,
    handleChange,
    handleSubmit,
  } = props;
  const listRef = useRef();
  const [showRealApp, setShowRealApp] = useState(false);
  let [ShowComment, setShowModelComment] = useState(true);
  let [animateModal, setanimateModal] = useState(false);
  const [currentIndex, setcurrentIndex] = useState(0);
  const [type, setType] = useState('')
  const [scannedImage,setScannedImage] = useState('')
  const [displayscannedImage,setDisplayscannedImage] = useState('')
  const [disableCBButton, setDisableCBButton] = useState(false)
  const defaultStatusMessage = 'swipe status appears here';
  const [swipeStatusMessage, setSwipeStatusMessage] = useState(
    defaultStatusMessage,
  );
  const [amount, setAmount] = useState('')
  const [calamount, setCalamount] = useState('0')
  const [show, setShow] = useState('HighRisk')
  const SCREEN_HEIGHT = Dimensions.get('screen').height;
  const [panelProps, setPanelProps] = useState({
    fullWidth: true,
    openLarge: true,
    showCloseButton: false,
    onClose: () => closePanel(),
    onPressCloseButton: () => closePanel(),
    // ...or any prop you want
  });
  const [isPanelActive, setIsPanelActive] = useState(false);
  const [interestCategory, setInterestCategory] = useState('High Risk');
  const [riskCategory, setRiskCategory] = useState('645fdc36d05f11efb18684b3');
  const [rememberMe, setRememberMe] = useState(false)
  const [slide, setSlide] = useState(false)
  const [firstLoad, setFirstLoad] = useState(false)

  function onMessage(data) {
    alert(data.nativeEvent.data);
  }

  function sendDataToWebView() {
    webviewRef.current.postMessage('Data from React Native App');
  }

  const webviewRef = useRef();

  // useEffect(() => {
  //   if (firstLoad == true) {
  //     //handleTransaction()
  //   }
  //   setFirstLoad(true)
  // }, [slide]);

  const handleTransaction = () => {
    if (amount == "") {
      Alert.alert(CommonStrings.AppName, 'Please Enter Amount')
    } else if (amount < 10) {
      Alert.alert(CommonStrings.AppName, 'Minimum Amount should be $10.')
    } else if (rememberMe == false) {
      Alert.alert(CommonStrings.AppName, 'Please select the terms & conditions.')
    } else {

      var data = {
        type: "deposit",
        title: interestCategory,
        amount: amount,
        riskCategory: riskCategory
      }
      
      props.initiateTransaction(data, navigation)
    }
  }
  const closePanel = () => {
    setIsPanelActive(false);
  };


  const onDone = () => {
    props.navigation.navigate("Login")
  };

  const slides = [
    {
      key: 1,
      title: 'Select your payment gateway',
      image: ImageIcons.BitcoinBadge,
      text: "Wallet connectivity",
      backgroundColor: '#ffffff',
    },


  ];


  const onViewableItemsChanged = ({ viewableItems, changed }) => {
    if (viewableItems[0]?.isViewable) {
      setcurrentIndex(viewableItems[0]?.index);
    }
  }

  const viewabilityConfigCallbackPairs = useRef([
    {
      onViewableItemsChanged,
      viewabilityConfig: {
        waitForInteraction: true,
        minimumViewTime: 60,
        itemVisiblePercentThreshold: 6
      },
    },
  ]);


  const onSelectImage = () => {
      ImagePicker.openPicker({
          width: 400,
          cropping: true,
          mediaType: 'photo',
          compressImageQuality: 0.5,
          height: 400,
      }).then(image => {
          if (image?.path) {
              let fileName = image?.path?.split('/').pop();
              let mimeType = image?.path?.split('.').pop();
              let file = {
                  'uri': image?.path,
                  'type': `image/${mimeType}`,
                  'name': fileName
              }
              setScannedImage(file); 
              setDisplayscannedImage(image?.path)
          }
      }).catch((error) => {
          
      });
  }

  const handleAmountChange = (text) => {
      setAmount(text);
      var result = (parseFloat(text) / 100) * 10000;
      const tenPercent = parseFloat(text) * 0.001;
      const remainingAmount = parseFloat(text) - tenPercent;
      setCalamount(remainingAmount)
  }

  const handleAddWallet = (text) => {
    if (amount == "") {
      Alert.alert(CommonStrings.AppName, 'Please Enter Amount')
    }else if (scannedImage == "" || scannedImage==undefined || scannedImage==null) {
      Alert.alert(CommonStrings.AppName, 'Please upload payment recipt')
    }else{
      let amountData = calamount ? calamount:  amount;
      const formData = new FormData();
      formData.append("amount", amountData);
      formData.append("image", scannedImage);
      props.depositAmount(formData, navigation);
    }
  }


  const CheckoutButton = () => {
    return (
      <View style={tw`h-11 w-11 rounded-full broder bg-[#BD0B30] items-center justify-center `}>
        <Image source={ImageIcons.arrow_login} style={tw`h-4 tint-[#fff]  absolute mt-3.5 w-5 ml-3 `} />
      </View>
    );
  }
  const updateSwipeStatusMessage = (message) => setSwipeStatusMessage(message);

  return (
    <>
      <View style={{ backgroundColor: (isPanelActive == true) ? 'black' : 'white' }}>

        <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
        <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} name={'Deposit USD'} />


        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps='handled'>
          {isPanelActive == false &&

            <View style={tw`mt-1 w-12/12  flex justify-center items-center p-2`}>

              <Text style={tw`text-[#848484] text-left  w-11/12 ml-2  `}>AMOUNT</Text>
              <View style={tw`flex flex-row w-11/12 items-center justify-between  mt-2`}>
                <View style={tw`w-8/12 `}>
                  <TextInput
                    style={tw`  bg-[#FFFFFF] px-3 text-black border border-[#E8E8E8] bg-white rounded-2 h-13  `}
                    value={amount}
                    type='text'
                    placeholder={'Enter Amount'}
                    placeholderTextColor={Colors.GREY}
                    onChangeText={handleAmountChange}
                    keyboardType='numeric'
                  />
                </View>
                <View style={tw` bg-[#EBEBEB] text-black  rounded-2 h-13 flex-row flex items-center justify-around w-3.5/12  `}>
                  <Image source={ImageIcons.Dollar} resizeMode='contain' style={tw`h-7 w-7 `} />
                  <Text style={tw` font-bold  text-base `}>USD</Text>
                  <Image source={ImageIcons.down} resizeMode='contain' style={tw`h-5 w-7 `} />
                </View>
              </View>


              <Text style={tw`text-[#848484] text-left  w-11/12 mt-5  ml-2 `}>MERCHANT <Text style={tw`text-xs`}> (Please pay on below QR code and upload screenshot of payment)</Text></Text>

              <View style={tw` flex-row items-center w-11/12 mt-2`}>
                 <Image source={{ uri: Api.fileUrl + props?.loginCredentials?.assignedQRCode }} style={tw`w-70 h-55`}></Image>
              </View>

              <View style={tw` bg-[#ffffff] text-black  bg-white rounded-2 h-12 flex-row flex items-center  w-11/12 justify-between mt-2 `}>
                <Text style={tw`text-[#848484]  text-base `}> Upload Payment Receipt:</Text>
                  
                <Image source={{ uri: displayscannedImage }} style={tw`w-15 h-15 mt-2`}></Image>
                 <TouchableOpacity onPress={() =>{ onSelectImage()}}>
                    <Text style={tw` text-white bg-[#000000] p-2 rounded-2 `}>Upload</Text>
                 </TouchableOpacity>
              </View>

              <View style={tw` bg-[#ffffff] text-black  bg-white rounded-2 h-12 flex-row flex items-center  w-11/12 justify-between mt-2 `}>
                <Text style={tw`text-[#848484]  text-base `}> Handling Fees :</Text>
                <Text style={tw` text-black `}>0.10%</Text>
              </View>
              <View style={tw`bg-[#E8E8E8] h-.4 w-11/12`}></View>
              <View style={tw` bg-[#ffffff] text-black bg-white rounded-2 h-12 flex-row flex items-center w-11/12 justify-between mt-2  `}>
                <Text style={tw`text-[#848484]  text-base `}> Amount Recieved </Text>
                <Text style={tw` text-black `}>{calamount} USD</Text>
              </View>
              <View style={tw`w-11/12 h-50 mt-10`}>
                <TouchableOpacity style={tw` h-15 bg-[#E0F64B] items-center  justify-center rounded-[4]   `} onPress={() => handleAddWallet()} >
                  <Text style={tw`text-black  text-[4.5]  `}>Continue</Text>
                </TouchableOpacity>
              </View>
              {interestCategory == 'High Risk' &&
                <View style={tw`flex-row justify-evenly w-12/12`}>
                  <TouchableOpacity style={tw`w-5/12`} onPress={() => {
                    setInterestCategory("High Risk");
                    setRiskCategory('645fdc36d05f11efb18684b3');
                  }}>
                  </TouchableOpacity>

                </View>
              }
              {interestCategory == 'Low Risk' &&
                <View style={tw`flex-row justify-evenly w-12/12`}>

                  <TouchableOpacity style={tw`w-5/12 h-50  bg-white shadow-[#7D64FF]   shadow-2xl rounded-[3] border-2px  my-5`} onPress={() => setInterestCategory("High Risk")} >
                    <View >

                      <Image source={ImageIcons.script} style={[tw`h-6 w-6 mx-4 my-4 `, { tintColor: 'black' }]} />
                      <View style={tw` my-12`}>
                        <Text style={tw` mx-4 text-black font-bold text-2xl`}>15-30%</Text>
                        <Text style={tw`text-sm mx-4 my-2 text-black `}>Agressive Plan</Text>
                      </View>

                    </View>
                  </TouchableOpacity>

                  <TouchableOpacity style={tw`w-5/12`} onPress={() => setInterestCategory("Low Risk")}>
                    <View>
                      <LinearGradient colors={['#C40730', '#FD5578']} start={{ x: 0.0, y: 0.0 }}
                        end={{ x: 1.0, y: 0.0 }}
                        locations={[0.0, 1.0]} style={tw`h-50  bg-white shadow-[#7D64FF]   shadow-2xl rounded-[3] border-2px  my-5`}>
                        <View style={tw`flex-row`}>



                          <Image source={ImageIcons.arrow_down} style={[tw`h-6 w-6 mx-4 my-4`, { tintColor: 'white' }]} />
                          {/* <Image source={ImageIcons.vector} style={tw`h-3 w-4 m-18 my-7`} /> */}
                        </View>
                        <View style={tw` my-10`}>
                          <Text style={tw` mx-4 text-white font-bold text-2xl`}>5-15%</Text>
                          <Text style={tw` mx-4 my-2 text-white text-sm`}>Conservative Plan</Text>
                        </View>
                      </LinearGradient>
                    </View>
                  </TouchableOpacity>

                </View>
              }

            </View>
          }
        </ScrollView>
      </View>
    </>

  );
};


export default Deposite;

