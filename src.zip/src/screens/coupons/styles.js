
import React from 'react';
import { Platform, StyleSheet,Dimensions,PixelRatio } from 'react-native';
import { Colors, Fonts } from '../../common';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const styles = StyleSheet.create({
    root: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    congrates_root: {
        flex: 1,
        
        backgroundColor: Colors.WHITE
    },
    topBlueView: {
        width: '100%',
        height: 40,
        backgroundColor: Colors.BLUE,
        zIndex: -1
    },
    titleText: {
        fontSize: 16,
        fontFamily: Fonts.RalewayExtraBold
    },
    titleSubText: {
        fontSize: 12,
        fontFamily: Fonts.QuestrialRegular,
        marginTop: 5,
        lineHeight: 15
    },
    img: {
        width: wp('18%'),
        height: hp('12%'),
        resizeMode: 'contain'
    },
    couponList: {
        flex: 1,
        //paddingHorizontal: 15,
    },
    error:{ fontSize: 10, color: 'red', marginLeft:15 },
    // couponListItem: {
    //     flexDirection: 'row',
    //     // alignItems: 'center',
    //     width: '100%',
    //     marginTop: 20,
    //     backgroundColor: Colors.COUPON_DRAFT,
    //     borderRadius: 8,
    //     shadowOffset: { width: 0, height: 2 },
    //     shadowColor: Platform.OS === "ios" ? Colors.LIGHT_GREY : Colors.GREY,
    //     shadowOpacity: 0.3,
    //     elevation: 3,
    //     zIndex: 999,
    //     justifyContent: 'space-between',
    //     paddingHorizontal: '2%'
    // },
    imgCoupon: {
        width: wp('28%'),
        height: hp('10%'),
        resizeMode: 'cover',
        // resizeMode: 'contain',
    },
    emptyListText: {
        fontSize: 16,
        color: Colors.LIGHT_GREY,
        fontFamily: Fonts.QuestrialRegular
    },
    emptyList: {
        flex: 1,
        justifyContent: 'center',
        height: hp('60%'),
        alignItems: 'center'
    },
    emptyIcon: {
        width: wp('80%'),
        height: hp('20%'),
        resizeMode: 'contain',
    },
    iconContainer: {
        padding: '5%',
        backgroundColor: '#D4ED97',
        width: '100%',
        borderTopRightRadius: 5,
        borderTopLeftRadius: 5,
        // justifyContent: 'center',
        alignItems: 'center',
        paddingTop: '10%',
        paddingBottom: '15%',
        zIndex: 0
    },
    leftSection: {
        width: '50%',
        paddingHorizontal: '2%',
        paddingVertical: '2%'
    },
    rightSection: {
        width: '38%',
        paddingVertical: '2%',
        paddingHorizontal: '2%',
        alignItems: 'flex-end',
        justifyContent: 'space-between'
    },
    couponTitle: {
        fontSize: 16,
        color: Colors.BLACK,
        // fontWeight:'bold',
        textAlign: 'center'
    },
    descText: {
        color: Colors.BLACK,
        textAlign: 'center',
        opacity: 0.7,
        lineHeight: 18,
        marginTop: 8
    },
    expireText: {
        color: Colors.DARK_GREY,
        textAlign: 'center',
        marginTop: 5
    },                         // Add coupon styles
    imageContainer: {
        marginHorizontal: '5%',
        width: wp('90%'),
        //height: hp('16%'),
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        borderStyle: 'dashed',
        borderWidth: 2,
        borderColor: Colors.GREY,
    },
    imageSelectText: {
        marginTop: 10,
        textAlign: 'center',
        fontSize: 16,
        color: Colors.LIGHT_GREY,
        fontFamily: Fonts.QuestrialRegular,
        paddingHorizontal:10
    },
    imageSelectButton: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    plusIcon: {
        width: wp('8%'),
        height: hp('8'),
        resizeMode: 'contain',
        tintColor: Colors.GREY
    },
    title: {
        color: '#323435',
        paddingVertical: 5,
        fontSize: 16,
        paddingLeft: '5%',
        fontFamily: Fonts.RalewayExtraBold
    },
    couponImage: {
        marginHorizontal: '5%',
        width: wp('90%'),
        height: hp('16%'),
        borderRadius: 5,
    },
    statusText: {
        fontFamily: Fonts.RalewayLight,
        // color: Colors.WHITE,
        fontSize: 12,
        paddingVertical: 5
    },
    couponTitleText: {
        fontFamily: Fonts.HomepageBaukastenBold,
        // color: Colors.WHITE,
        fontSize: 24,
        // height: Platform.OS === "ios" ? hp('3.5%') : hp('5%'),
        textAlignVertical: 'center',
    },
    discountText: {
        color: Colors.LIGHT_BLACK,
        fontSize: 12,
        paddingVertical: 5
    },
    trnsDetailRow: {
        width: '100%',
        // height:hp('15%'),
        paddingVertical: 5,
        flexDirection: 'row',
        // alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: 10,
        paddingHorizontal: 20
    },
    valueText: {
        color: Colors.BLACK,
        fontWeight: 'bold',
        textAlign: 'left',
    },
    heading: {
        paddingVertical: '2%',
        alignItems: 'center',
        marginTop: hp('5%'),
        // paddingBottom:hp('5%')
    },
    viewIcon: {
        width: wp('5%'),
        height: hp('3%'),
        resizeMode: 'contain',
        alignSelf: 'flex-start'
    },
    editIcon: {
        width: wp('4%'),
        height: hp('3%'),
        resizeMode: 'contain',
        alignSelf: 'flex-start'
    },
    optionsIcons: {
        flexDirection: 'row',
        // paddingBottom:5
        // alignItems:'center',
    },
    rightViewButton: {
        marginRight: wp('5%'),
    },
    rightEditButton: {
        // marginRight:'3%'
    },
    datePicker: {
        paddingHorizontal: 15,
        paddingTop: 10
    },
    datePickerContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    expTitleText: {
        color: Colors.BLACK,
        paddingVertical: 5,
        fontSize: 16,
        fontFamily: Fonts.RalewayExtraBold
    },
    cancelText: {
        textAlign: 'center',
        paddingVertical: 10,
        color: Colors.BLUE,
        fontSize: 18,
        fontFamily: Fonts.RalewaySemiBold,
    },
    discountTitle: {
        color: Colors.BLACK,
        marginTop: 15,
        fontSize: 16,
        fontFamily: Fonts.RalewayExtraBold,
        paddingHorizontal: 15,
    },
    textInput: {
        backgroundColor: '#f2f2f2',
        borderColor: Colors.GREY,
        borderWidth: 0.5,
        height:50,
        borderRadius: 10,
        marginTop:10
    },
    textIn:{
        flex: 1,
        color: Colors.BLACK,
        paddingLeft: 10,
        fontSize: 16,
        backgroundColor:'#767676'
    },
    rememberMeContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: '8%',
        // paddingHorizontal:'5%',
    },
    rememberMeText: {
        color: Colors.BLACK,
        fontSize: 16,
        fontFamily: Fonts.RalewayExtraBold,
        paddingLeft:20
    },

    listbackgrounimg: {
        flexDirection: 'row',
        height: 'auto',
        width: screenWidth / 1,
        justifyContent: 'center',
        paddingHorizontal: 5,
        paddingVertical: 20,
        
    },
    titleitem: {
        // fontSize:18,
        fontSize: (PixelRatio.get() <= 2) ? 16 : 16,
        color: '#323435',
        textTransform: 'uppercase',
        //paddingRight: 10,
        fontWeight: 'bold',
        //fontFamily:'Montserrat',
        textTransform: 'capitalize'
    },
    greentext_new: {
        //color: '#6BBD46',
        color: '#2F479D',
        fontSize: 10,
        paddingTop: 5,
        fontWeight: 'bold',
        marginRight:5
        //width: deviceWidth - 120
    },
    tittletext_coupon: {
        //color: '#6BBD46',
       // color: '#323435',
       color:'#333',
        fontSize: 14,
        paddingTop: 5,
        fontWeight: '400',
        //width: deviceWidth - 120

    },
    infoBox: {
        flexDirection: 'row', alignItems: 'center', marginTop: 5
    },
    infoBox1: {
        flexDirection: 'row', alignItems: 'center', width: 80, marginTop: 5
    },
    infoBox2: {
        flexDirection: 'row', alignItems: 'center', width: 60, marginTop: 5
    },
    infoIcon1: {
        height: 15,
        width: 15,
        tintColor: '#000000'
    },
    infoIcon2: {
        height: 17,
        width: 15,
        tintColor: '#000000'
    },
    smalltext: {
        fontSize: (PixelRatio.get() <= 2) ? 14 : 14,
        // fontSize:14,
        paddingLeft: 4,
        color: '#000'
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22,
        backgroundColor: 'rgba(0, 0, 0, 0.5)'
        //backgroundColor:'#000000', opacity:0.1
    },
    modalView: {
        margin: 20,
       // backgroundColor: "#fff",
        borderRadius: 20,
        padding: 35,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5
    },
    flatlist_horizontal:{
elevation:5
    },
    tax_service:{
        height:90, width:98,backgroundColor:"#E6E6FA",borderRadius:10, borderColor:'#000000'
    },
    tax_service1:{
        height:90, width:95,backgroundColor:"#E6E6FA",borderRadius:10, borderColor:'#000000',marginLeft:6
    }

})

export default styles;
