import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image, ImageBackground } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';

import LinearGradient from 'react-native-linear-gradient';
import { getTransactionsList } from '../../redux/actions/Coupon';

const Transaction = (props) => {

    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate
    const [activeTab, setActiveTab] = useState(0);

    
    const transactionList = props?.transactionStock


    const onChangeDate = (dateTime) => {
        if (dateTime) {
            setShowDatePicker(false)
            if (datePickerFor === "startDate") {
                setIsPlaceholderStartDate(false)
                setStartDate(dateTime);
            } else {
                setIsPlaceholderEndDate(false);
                setEndDate(dateTime);
            }
            setToggleCheckBox(false)
        }
    }

    useEffect(() => {
        // props?.getTransactionsList('deposit');
        props.getTransactionsListStock({
            value: 'deposit'
        })

    }, [])

    const Tab = ({ label, active, onPress }) => {
        return (
            <TouchableOpacity
                onPress={onPress}
                style={tw`flex-1 py-2 items-center justify-center border-r border-gray-300 ${active ? 'bg-[#E0F64B]' : 'bg-white'}`}
            >
                <Text style={tw`${active ? 'text-black font-bold' : 'text-gray-600'}`}>{label}</Text>
            </TouchableOpacity>
        );
    };


    const tabs = [
        { label: 'Deposit' },

        { label: 'Withdraw' },
        { label: 'Invest' },
        // { label: 'Profit' },
        // { label: 'Refferal' },

    ];

    const handleTabPress = (index) => {
        setActiveTab(index);
        if (index == 0) {
            props?.getTransactionsListStock({
                value: 'deposit'
            });
        } else if (index == 2) {
            props?.getTransactionsListStock({
                value: 'invest'
            });
        } else if (index == 1) {
            props?.getTransactionsListStock({
                value: 'withdraw'
            });
        }
        else if (index == 3) {
            props?.getTransactionsListStock({
                value: 'adminProfit'
            });
        }
        else if (index == 4) {
            props?.getTransactionsListStock({
                value: 'refferal'
            });
        }

    };

    const currencyFormat = (num) => {
        return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    }

    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };

    const renderCategory = (riskId, title) => {
        var riskCategoryName = title;
        if (title == 'Withdraw') { riskCategoryName = 'Withdrawal' }
        if (title == 'Refferal') { riskCategoryName = 'Refer N earn' }
        if (title == 'adminProfit') { riskCategoryName = 'Daily Profits' }

        if (riskId == '645fdc36d05f11efb18684b3') { riskCategoryName = 'Agressive Plan' }
        if (riskId == '645fdc58d05f11efb18684b4') { riskCategoryName = 'Conservative Plan' }
        return riskCategoryName;
    };




    const renderItem1 = ({ item, index }) => {
        
        return (
            <View style={tw` w-12/12 rounded-2xl border-2px flex items-center shadow-sm mt-2 shadow-[#CEEBFF]  flex-row p-2   `}>

                <View style={tw` w-2/12 `}>
                    <ImageBackground source={ImageIcons.bg} style={tw` items-center justify-center  h-10 w-10  rounded-full`}>
                        <Image source={ImageIcons.downarrow_img} style={tw` h-8 w-8  rounded-full`} />
                    </ImageBackground>
                </View>
                <View style={tw`w-6/12`}>
                    {item?.title === "wallet_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>Wallet Amount</Text>
                    )}
                    {item?.title === "low_risk_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>Low Risk Investment</Text>
                    )}
                    {item?.title === "high_risk_amount" && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>High Risk Investment</Text>
                    )}
                    {!["wallet_amount", "low_risk_amount", "high_risk_amount"].includes(item?.title) && (
                        <Text style={tw`text-sm font-bold text-black font-[4]`}>{item?.title}</Text>
                    )}
                    <Text style={tw`text-sm font-bold text-black font-[1]`}>{moment(item?.created_at)?.format('lll')}</Text>
                </View>
                <View style={tw` w-4/12 items-end p-1`}>
                    <Text style={tw`text-sm  font-bold text-black  font-[4]`}>${currencyFormat(item?.amount)}</Text>
                    <Text style={tw`text-sm  font-[6] text-[#13C08C] font-bold`}>Completed</Text>
                </View>
            </View>

        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>
            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Transactions'} />
            <ScrollView style={tw` `}>
                <View style={tw` w-12/12  flex justify-center items-center mt-4`} >
                    <View style={tw` w-11/12 mt-4 flex-row border border-gray-300 rounded-[3] overflow-hidden`}>
                        {tabs.map((tab, index) => (
                            <Tab
                                key={index}
                                label={tab.label}
                                active={index === activeTab}
                                onPress={() => handleTabPress(index)}
                            />
                        ))}
                    </View>
                    <View style={tw` w-11/12  `} >
                        <FlatList
                            data={transactionList?.reverse()}
                            renderItem={renderItem1}
                            keyExtractor={item => item?.id}
                            ListEmptyComponent={renderEmptyComponent}
                        />
                    </View>
                </View>

            </ScrollView>
            {/* <CustomBottomTab
                {...props} isActive={true} selected={"Transaction"} /> */}
        </KeyboardAvoidingView>

    )
}

export default Transaction;