import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { BarChart } from "react-native-chart-kit";
import styles from './styles';
import InsightFilterModal from '../../components/modals/InsightFilterModal';
import moment from 'moment';
import Loader from '../../components/modals/Loader';
import tw from 'twrnc';

const DailyLabels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const HourlyLabels = ["12 am", "02 am", "04 am", "06 am", "08 am", "10 am", "12 pm", "02 pm", "04 pm", "06 pm", "08 pm", "10 pm"];

const SingleCouponInsight = (props) => {

    // Local states
    const [coupon, setCoupon] = useState()
    const [openFilterModal, setOpenFilterModal] = useState(false);
    const [filterType, setFilterType] = useState("Hourly"); //Hourly , Daily
    const [hourlyValues, setHourlyValues] = useState([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
    const [dailyValues, setDailyValues] = useState([0, 0, 0, 0, 0, 0, 0]);
    const [graphData, setGraphData] = useState({
        labels: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        datasets: [
            {
                data: [0, 0, 0, 0, 0, 0, 0],
            }
        ]
    });

    useEffect(() => {
        const { couponDetail } = props.route?.params;
        if (couponDetail) {
            setCoupon(couponDetail)
            getCouponTrackingData(couponDetail?._id)
        }
    }, [])

    useEffect(() => {
        if (props?.redeemedCouponTrackingData) {
            setTimeout(() => {
                let data = {
                    labels: HourlyLabels,
                    datasets: [
                        {
                            data: props?.redeemedCouponTrackingData?.hourly,
                        }
                    ]
                };
                setGraphData(data);
                setHourlyValues(props?.redeemedCouponTrackingData?.hourly);
                setDailyValues(props?.redeemedCouponTrackingData?.daily);
            }, 500);
        }
    }, [props.redeemedCouponTrackingData])

    // get redeemed coupons tracking data
    const getCouponTrackingData = (couponId) => {
        props.getRedeemedTrackingData(couponId);
    }

    // filter graph data by (Daily/Hourly)
    const prepareGraphData = (filterBy) => {
        if (filterBy === "Hourly") {
            let data = {
                labels: HourlyLabels,
                datasets: [
                    {
                        data: hourlyValues,
                    }
                ]
            };
            setGraphData(data);
            setOpenFilterModal(false)
        } else {
            let data = {
                labels: DailyLabels,
                datasets: [
                    {
                        data: dailyValues,
                    }
                ]
            };
            setGraphData(data);
            setOpenFilterModal(false)
        }
    }

    return (
        <View style={tw`flex-1 bg-white`}>
            <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
            <ScrollView>

                <View style={tw`my-2.5 mx-2.5 rounded bg-white flex-row justify-between z-40 shadow-gray-800 shadow-xl`}>
                    <View style={tw`w-98`}>

                        <View style={tw`w-98 h-11 rounded-t bg-[#323435] justify-center px-3`}>
                            <Text style={[tw`text-4 text-white pl-3`, { fontFamily: Fonts.HomepageBaukastenBold }]}>{coupon?.title || "-"}</Text>
                        </View>

                        <View style={tw`px-4 flex-row justify-between mt-2`}>
                            <Text style={[tw`text-3 text-black leading-6`, { fontFamily: Fonts.HomepageBaukastenBold }]}>{coupon?.description}</Text>
                        </View>

                        <View style={tw`px-4 flex-row justify-between mt-3 pb-3`}>
                            <Text style={[tw`text-3 text-black`, { fontFamily: Fonts.HomepageBaukastenBold }]}>{`DISCOUNT: ${coupon?.discount || "-"}%`}</Text>
                            <Text style={[tw`text-3 text-gray-500`, { fontFamily: Fonts.QuestrialRegular }]}>{`Expires: ${moment(coupon?.dateOfExpiration).format("MM/DD/YYYY") || "-"}`}</Text>
                        </View>
                    </View>

                </View>

                <View style={tw`h-80  bg-white m-2.5 rounded-xl shadow-gray-500 shadow-lg`} >
                    <View style={tw`w-98 justify-between px-2 items-center py-2 flex-row`}>
                        <Text>Times Redeemed</Text>
                        <TouchableOpacity
                            style={tw`flex-row items-center`}
                            onPress={() => setOpenFilterModal(true)}
                        >
                            <Text >{filterType}</Text>
                            <Image source={ImageIcons.dropDownIcon} style={tw`w-3 h-3 ml-2`} />
                        </TouchableOpacity>
                    </View>

                    <BarChart
                        style={tw`flex-1 pl--3 items-center`}
                        data={graphData}
                        width={wp('90%')}
                        height={hp('35%')}
                        yLabelsOffset={40}
                        // withCustomBarColorFromData={true}
                        chartConfig={{
                            // barRadius:10,
                            backgroundColor: Colors.WHITE,
                            backgroundGradientFrom: Colors.WHITE,
                            backgroundGradientTo: Colors.WHITE,
                            fillShadowGradient: Colors.GREEN,
                            fillShadowGradientOpacity: 1,
                            decimalPlaces: 0, // optional, defaults to 2dp
                            color: (opacity = 1) => `#D5D5D5`,
                            barPercentage: filterType === "Hourly" ? 0.2 : 0.8,
                            labelColor: (opacity = 1) => `#D5D5D5`,
                            style: {
                                borderRadius: 16,
                                paddingRight: 15
                            },
                            propsForLabels: {
                                strokeWidth: "1",
                                stroke: Colors.DARK_GREY,
                                // wordSpacing: 10,
                                fontSize: 10.5,
                                rotation: 90,

                            },
                        }}
                        bezier
                    />

                </View>

                <View style={tw`w-98 h-15 rounded-lg flex-row justify-between items-center mt-5 mb-6 ml-2.5 bg-white px-4 z-40 shadow-gray-500 shadow-md`}>
                    <Text style={[tw`text-3.5 font-bold`, { fontFamily: Fonts.HomepageBaukastenBold }]}>Total Times Redeemed</Text>
                    <Text style={[tw`text-3.5 font-bold w-20 text-right`, { fontFamily: Fonts.HomepageBaukastenBold }]}>{props.redeemedCouponTrackingData?.totalTimesRedeemed || "0"}</Text>
                </View>
            </ScrollView>
            <InsightFilterModal
                isVisible={openFilterModal}
                childComponent={
                    <View style={tw`w-51 h-35 bg-white rounded-lg justify-center items-center self-center`}>
                        <Text
                            style={[tw`text-4 font-bold py-1 px-5 my-1`, { color: filterType === "Hourly" ? Colors.GREEN : Colors.BLACK }]}
                            onPress={() => { setFilterType("Hourly"); prepareGraphData("Hourly") }}
                        >Hourly</Text>
                        <Text
                            style={[tw`text-4 font-bold py-1 px-5 my-1`, { color: filterType === "Daily" ? Colors.GREEN : Colors.BLACK }]}
                            onPress={() => { setFilterType("Daily"); prepareGraphData("Daily") }}
                        >Daily</Text>
                    </View>
                }
            />
            <Loader isVisible={props?.redeemedCouponTrackingLoader} />
        </View>
    )
}

export default SingleCouponInsight;
