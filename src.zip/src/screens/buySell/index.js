import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image, TextInput, Alert } from 'react-native';
import { Fonts, Colors, ImageIcons, CommonStrings } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';
import DropDownPicker from 'react-native-dropdown-picker';
import SwipeButton from 'rn-swipe-button';
import LinearGradient from 'react-native-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';


const BuySell = (props) => {
    const {
        navigation,
    } = props;
    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate
    const [email, setEmail] = useState('')
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState([]);
    const [gender, setGender] = useState('');
    const [items, setItems] = useState([
        { label: 'USDT-BEP20', value: 'bep20' },
        { label: 'USDT-TRC20', value: 'trc20' },
        { label: 'USDT-ERC20', value: 'erc20' }
    ]);
    const [slide, setSlide] = useState(false)
    const [firstLoad, setFirstLoad] = useState(false)
    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [amount, setAmount] = useState('')
    const [wallet, setWallet] = useState('')
    const itemget = props?.route?.params?.item

    const stockdata = props?.route?.params?.item

    const stockMethod = props?.route?.params?.value
    useEffect(() => {
        // if (firstLoad == true) {
        //     handleTransaction()
        // }
        // setFirstLoad(true)
    }, []);

    const handleTransaction = () => {
        if (amount == "") {
            Alert.alert(CommonStrings.AppName, 'Please Enter Amount')
        } else if (amount < 10) {
            Alert.alert(CommonStrings.AppName, 'Minimum Amount should be $10.')
        } else {

            var data = {
                wallet: wallet,
                amount: amount,
                currency: value
            }
            props.initiateBuyUSDT(data, navigation)
        }
    }

    const handleAmountChange = (text) => {
        setAmount(text);
    }

    const handleWalletChange = (text) => {
        setWallet(text);
    }

    const handleEmailChange = (text) => {
        setEmail(text)

    }


    const handleStock = async (data,key) => {
        // alert("okk")
        data.value = stockMethod
        data.key = key
        // await AsyncStorage.setItem('stockData', JSON.stringify(data));
        props.setStockDataValue(data, navigation);
        // props.navigation.navigate('Buy', { itemData: 1 })


    }
    const CheckoutButton = () => {
        return (
            <View style={tw`h-18 w-18 bg-white items-center justify-center`}>
                <Image source={ImageIcons.arrow_both} style={tw`h-4 bg-white absolute mt-3.5 w-5 ml-3 `} />
            </View>
        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>

            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Buy/Sell'} />
            {/* {stockMethod != "forex" ? */}
            <ScrollView style={tw`bg-white `}>
                <View style={tw` flex  justify-center items-center  w-12/12   `}>
                    <View style={tw` flex flex-row justify-around items-center mt-5  w-12/12 `}>
                        {/* <Image source={ImageIcons.Spotify} style={tw`  w-12 h-12 mb-4`} /> */}
                        <View style={tw` flex flex-row items-center w-6/12  `}>
                            <Text style={tw`text-2xl font-bold text-black font-[8]`}>{stockdata?.symbol}</Text>
                            <Text style={tw`text-3 text-gray-500`}>({(stockdata?.name)?.substring(0, 15)}....)</Text>
                        </View>
                        <View style={tw``} >
                            {stockdata?.changesPercentage < 0 ?
                                <TouchableOpacity style={tw`flex-row bg-[#ff4475] h-7 w-22 rounded-[4] flex justify-center  items-center`}
                                // onPress={() => props?.navigation?.navigate("Deposite")}
                                >
                                    <Image source={ImageIcons.dropdown} resizeMode='contain' style={[tw`h-4 w-2 `, { tintColor: '#f9f9f9' }]} />
                                    <Text style={tw`text-white font-bold text-3 `}>{stockdata?.changesPercentage}%</Text>
                                </TouchableOpacity>
                                :
                                <TouchableOpacity style={tw`flex-row  bg-[#ff4475] h-7 w-22 rounded-[6] flex justify-center items-center`}
                                // onPress={() => props?.navigation?.navigate("Deposite")}
                                >
                                    <Image source={ImageIcons.Fill} resizeMode='contain' style={[tw`h-6 w-3 `, { tintColor: '#f9f9f9' }]} />
                                    <Text style={tw`text-white font-bold text-3 `}>{stockdata?.changesPercentage}%</Text>
                                </TouchableOpacity>

                            }
                        </View>
                    </View>
                    <View style={tw`mt-5 flex justify-around items-center w-12/12 `}>
                        <Image source={ImageIcons.Chart_buysell} style={tw`w-80 h-60`} />
                    </View>
                    <View style={tw`mt-5 flex flex-row justify-between items-center  w-10/12  `}>
                        <Text style={tw` text-xl   text-black font-bold`}>Statistics</Text>
                        <Text style={tw`  text-2xl  text-black font-bold`}>${stockdata?.price}</Text>
                    </View>


                    <View style={tw` mt-3 flex flex-row justify-between items-center  w-11/12 `}>
                        <View style={tw` flex justify-center items-center  w-4/12  p-2`}>
                            <Text style={tw`  text-4 text-gray-500`}>Open</Text>
                            <Text style={tw` text-4  text-black font-bold`}>{stockdata?.open}</Text>
                        </View>
                        <View style={tw`flex justify-center items-center  w-4/12  p-2`}>
                            <Text style={tw`  text-4  text-gray-500`}>High</Text>
                            <Text style={tw`  text-4  text-black font-bold`}>{stockdata?.dayHigh}</Text>
                        </View>
                        <View style={tw`flex justify-center items-center  w-4/12 p-2`}>
                            <Text style={tw`  text-4  text-gray-500`}>Low</Text>
                            <Text style={tw` text-4  text-black font-bold`}>{stockdata?.dayLow}</Text>
                        </View>
                    </View>

                    <View style={tw`mt-1  flex-row justify-between items-center  w-11/12`}>
                        <View style={tw` flex justify-center items-center  w-4/12  p-2 `}>
                            <Text style={tw`  text-4 text-gray-500`}>Volume</Text>
                            <Text style={tw`  text-4  text-black font-bold`}>{stockdata?.volume}</Text>
                        </View>
                        <View style={tw`flex justify-center items-center  w-4/12  p-2 `}>
                            <Text style={tw`   text-4  text-gray-500`}>Avg. Volume</Text>
                            <Text style={tw` text-4  text-black font-bold`}>{stockdata?.avgVolume}</Text>
                        </View>
                        <View style={tw` flex justify-center items-center  w-4/12  h-20 mt-4 p-2 `}>
                            <Text style={tw`  text-4  text-gray-500`}>Market Cap</Text>
                            <Text style={tw`  text-4 text-black font-bold`}>{stockdata?.marketCap}</Text>
                        </View>
                    </View>
                    <View style={tw` flex flex-row mt-10 justify-between items-center w-11/12  `}>
                        <TouchableOpacity style={tw`flex-row justify-center  items-center bg-[#E0F64B] h-14 w-40  rounded-[6]`}
                            onPress={() => handleStock(stockdata,"buy")}
                        >
                            <Text style={tw`text-black font-bold  `}>Buy</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={tw`flex-row justify-center  items-center bg-[#000000] h-14 w-40   rounded-[6]`}
                       onPress={() => handleStock(stockdata,"sell")}
                        >
                            <Text style={tw`text-white font-bold text-3.5 `}>Sell</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </ScrollView>
            {/* :
                <ScrollView style={tw`bg-white`}>
                    <View style={tw`flex-row justify-between mt-5 mx-8`}>

                        <View style={tw`flex-row mt-2  mr-15 `}>
                            <Text style={tw` text-sm text-base  text-black font-bold`}>{stockdata?.ticker}</Text>
                            
                        </View>
                        {stockdata?.changes < 0 ?
                            <TouchableOpacity style={tw`flex-row bg-[#F61C7A] h-8 w-25 rounded-[6] mt-2`}
                           
                            >
                                <Text style={tw`text-white font-bold text-3.5 ml-7  my-2`}>{stockdata?.changes}%</Text>
                            </TouchableOpacity>
                            :
                            <TouchableOpacity style={tw`flex-row  bg-green-500 h-8 w-25 rounded-[6] mt-2`}
                            
                            >
                                <Text style={tw`text-white font-bold text-3.5 ml-7  my-2`}>{stockdata?.changes}%</Text>
                            </TouchableOpacity>

                        }
                    </View>
                    <View style={tw` `}>
                        <Image source={ImageIcons.Chart_buysell} style={tw`w-80 h-60 mx-6 my-4 `} />
                    </View>
                    <View style={tw`flex-row justify-center justify-evenly p-2 mt-5`}>
                        <Text style={tw`text-sm text-xl  text-black font-bold`}>Statistics</Text>
                        <Text style={tw` ml-25 text-sm text-xl  text-black font-bold`}>{stockdata?.bid}</Text>
                    </View>
                    <View style={tw`flex-row justify-around  p-2 mt-5`}>
                        <View>
                            <Text style={tw` mx-7 text-4 text-gray-500`}>Open</Text>
                            <Text style={tw` mx-7 text-4  text-black font-bold`}>{stockdata?.open}</Text>
                        </View>
                        <View>
                            <Text style={tw` mx-7 text-4  text-gray-500`}>High</Text>
                            <Text style={tw` mx-7 text-4  text-black font-bold`}>{stockdata?.high}</Text>
                        </View>
                        <View>
                            <Text style={tw` mx-7 text-4  text-gray-500`}>Low</Text>
                            <Text style={tw` mx-7 text-4  text-black font-bold`}>{stockdata?.low}</Text>
                        </View>
                    </View>
                   
                    <View style={tw`flex-row  p-4 mt-1`}>
                        <TouchableOpacity style={tw`flex-row justify-center items-center bg-[#E0F64B] h-14 w-30 ml-8 mt-4 rounded-[6]`}
                            onPress={() => handleStock(stockdata)}
                        >
                            <Text style={tw`text-black font-bold `}>Buy</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={tw`flex-row justify-center items-center bg-[#000000] h-14 w-30 ml-8 mt-4 rounded-[6]`}
                        
                        >
                            <Text style={tw`text-white font-bold text-3.5 `}>Sell</Text>
                        </TouchableOpacity>
                    </View>

                </ScrollView>
            } */}
            {/* 
            <CustomBottomTab
                {...props} isActive={true} selected={"Insights"} /> */}
        </KeyboardAvoidingView>

    )
}

export default BuySell;