import React, { useRef } from 'react';
import { KeyboardAvoidingView, Platform,Dimensions } from 'react-native';
// import { Fonts, Colors, ImageIcons ,CommonStrings} from '../../common';
// import { withFormik } from 'formik';
// import * as Yup from 'yup';
import tw from 'twrnc';
// import {
//     widthPercentageToDP as wp,
//     heightPercentageToDP as hp,
// } from 'react-native-responsive-screen';
// import InputField from '../../components/forms/inputField';
// import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
// import { BarChart } from "react-native-chart-kit";
// import styles from './styles';
// import InsightFilterModal from '../../components/modals/InsightFilterModal';
// import moment from 'moment';
// import Loader from '../../components/modals/Loader';
// import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import { WebView } from 'react-native-webview';
// const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

const BuyUsdt = (props) => {
    var amount = props.initiateReqUsdt.amount;
    var currency = props.initiateReqUsdt.currency;
    var wallet = props.initiateReqUsdt.wallet;
    
    // const webviewRef = useRef();
    
    // const {
    //     navigation,    
    // } = props;
    // const jsCode = `document.getElementById("myForm").submit()`;
    return ( 
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>

            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Buy USDT by UPI'} />
       
            <WebView source={{
                uri: "https://onramp.money/main/buy/?appId=1&coinAmount="+amount+"&walletAddress="+wallet+"&coinCode=usdt&flowtype=1&network="+currency,
            }}
            style={{ flex: 1, width:screenWidth, height:300, marginTop:0 }}  />          
        </KeyboardAvoidingView>
    )
}

export default BuyUsdt;

