import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image, TextInput, Alert } from 'react-native';
import { Fonts, Colors, ImageIcons, CommonStrings } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';
import DropDownPicker from 'react-native-dropdown-picker';
import SwipeButton from 'rn-swipe-button';
import LinearGradient from 'react-native-linear-gradient';
import { useIsFocused } from '@react-navigation/native'
import AsyncStorage from '@react-native-async-storage/async-storage';

const Buy = (props) => {
    const {
        navigation,
    } = props;
    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate
    const [email, setEmail] = useState('')
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState([]);
    const [gender, setGender] = useState('');
    const [items, setItems] = useState([
        { label: 'USDT-BEP20', value: 'bep20' },
        { label: 'USDT-TRC20', value: 'trc20' },
        { label: 'USDT-ERC20', value: 'erc20' }
    ]);
    const [slide, setSlide] = useState(false)
    const [firstLoad, setFirstLoad] = useState(false)
    const [dropdownval, setDropdownval] = useState('USDT')
    const [showdrowdoenval, setShowdrowdoenval] = useState(false)
    const [amount, setAmount] = useState('')
    const [wallet, setWallet] = useState('')
    const [assestsHold, setAssestsHold] = useState([])

    // const [stockValue, setStockValue] = useState(null)
    const [activeTab, setActiveTab] = useState(0);

    const stockValue = props?.stockData


    const walletData = props?.getwalletBalance
    
    const isFocused = useIsFocused()

    const stockDataValue = async () => {
        //props.setStockDataValue(data,navigation);
        const data = await AsyncStorage.getItem('stockData');
        const stocK = await JSON.parse(data)

        await setStockValue(stocK)

    }

    
    
    useEffect(() => {
        if(props?.getAssestsHolds){
            setAssestsHold(props?.getAssestsHolds[0])
        }
    });
    useEffect(() => {
        // stockDataValue()
        props.walletBalance()

        if (firstLoad == true) {
            // handleTransaction()
        }
        setFirstLoad(true)

        props.stocksHolds({
            symbol: props?.stockData?.symbol
        })
        if (props?.stockData?.key == "buy") {
            setActiveTab(0);
        }
        if (props?.stockData?.key == "sell") {
            setActiveTab(1);
        }

        

    }, [slide, props?.stockData]);

    const handleTransaction = () => {
        if (amount == "") {
            Alert.alert(CommonStrings.AppName, 'Please Enter Quantity')
        } else if (amount < 1) {
            Alert.alert(CommonStrings.AppName, 'Minimum Quantity should be 1.')
        } else {

            var data = {
                quantity: amount,
                amount: parseFloat(amount) * parseFloat(stockValue.price),
                symbol: stockValue.symbol,
                value: stockValue.value
            }
            props.initiateBuyUSDT(data, navigation)
        }
    }

    const handleTransactionSell = () => {
        if (amount == "") {
            Alert.alert(CommonStrings.AppName, 'Please Enter Quantity')
        } else if (amount < 1) {
            Alert.alert(CommonStrings.AppName, 'Minimum Quantity should be 1.')
        } else {

            var data = {
                quantity: amount,
                amount: parseFloat(amount) * parseFloat(stockValue.price),
                symbol: stockValue.symbol,
                value: stockValue.value
            }
            props.initiateSellStock(data, navigation)
        }
    }



    const handleAmountChange = (text) => {
        setAmount(text);
    }

    const handleWalletChange = (text) => {
        setWallet(text);
    }

    const handleEmailChange = (text) => {
        setEmail(text)

    }
    const CheckoutButton = () => {
        return (
            <View style={tw`h-18 w-18 bg-white items-center justify-center`}>
                <Image source={ImageIcons.arrow_both} style={tw`h-4 bg-white absolute mt-3.5 w-5 ml-3 `} />
            </View>
        );
    }
    const Tab = ({ label, active, onPress }) => {
        return (
            <TouchableOpacity
                onPress={onPress}
                style={tw`flex-1 py-2 items-center  ${active ? 'bg-[#FFFFFF] rounded-[3]' : ' bg-[#FCDDEC]'}`}
            >
                <Text style={tw`${active ? 'text-[#F61C7A] font-bold' : ' text-black font-bold'}`}>{label}</Text>
            </TouchableOpacity>
        );
    };


    const tabs = [
        { label: 'Buy' },
        { label: 'Sell' },
    ];

    const handleTabPress = (index) => {
        setActiveTab(index);
    };

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center items-center `}>

            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Buy/sell'} />



            <ScrollView style={tw`bg-white w-12/12   `}>
                <View style={tw` flex  justify-center items-center  w-12/12 h-auto   `}>
                    <View style={tw`bg-[#FCDDEC] flex  justify-center items-center  h-15 w-11/12 rounded-[2] mt-4 `}>
                        <View style={tw`flex-row w-10/12  rounded-[3] overflow-hidden`}>
                            {tabs.map((tab, index) => (
                                <Tab
                                    key={index}
                                    label={tab.label}
                                    active={index === activeTab}
                                    onPress={() => handleTabPress(index)}
                                />
                            ))}
                        </View>
                    </View>
                    {activeTab == 0 &&
                        <>
                            <View style={tw`w-11/12   mt-10 `}>

                                <Image source={ImageIcons.Base} resizeMode='contain' style={tw`w-12/12 h-40`} />
                                <View style={tw` h-40 absolute inset-0 flex justify-center items-center p-3 mx-4`}>
                                    <View style={tw`flex flex-row  justify-between items-center w-12/12  `}>
                                        <View style={tw`text-[#03314B] flex-row  text-xl font-bold`}>
                                            <Text style={tw`text-[#03314B] text-xl font-bold`}>{stockValue?.symbol}</Text>

                                            <Text style={tw`text-base text-gray-500`}>({(stockValue?.name).substring(0, 15)}....)</Text>
                                        </View>
                                        {/* <View>
                                            <Text style={tw`text-[#03314B] flex-row text-md font-bold`}>{stockValue?.price}</Text>
                                        </View> */}
                                    </View>
                                    <View style={tw`flex-row  justify-between items-center w-12/12 `} >
                                      
                                        <TextInput
                                            style={tw` text-5.5 font-bold text-[#03314B] border-white rounded-2 h-12  w-60 `}
                                            value={amount}
                                            type='text'
                                            placeholder={'Enter Quantity'}
                                            placeholderTextColor={'#d3d3d3'}
                                            onChangeText={handleAmountChange}
                                            keyboardType="numeric"
                                            selectionColor="Black"
                                        />
                                        <Image source={ImageIcons.Calculator} resizeMode='contain' style={tw`  h-6 w-6`} />
                                    </View>
                                </View>

                            </View>
                            <View style={tw`flex justify-center items-center  mt--7`}>
                                <Image source={ImageIcons.Rest} resizeMode='contain' style={tw`h-14 w-20`} />
                            </View>

                            <View style={tw`w-11/12  mt-5 relative mt--7 w-11/12 `}>
                                <Image source={ImageIcons.foreximg} resizeMode='contain' style={tw`w-12/12 h-40  `} />
                                <View style={tw` h-40 absolute top-0 left-0 right-0 bottom-0 mx-8 justify-center `}>
                                    <View style={tw`flex-row items-center justify-left  w-12/12`} >
                                        <Text style={tw`text-xl text-[#03314B] font-bold text-center`}>Available Balance (USD)</Text>
                                    </View>
                                    <View style={tw`flex-row items-center justify-left  w-12/12`}>
                                        <Text style={tw`text-2xl text-[#03314B] font-bold`}>$</Text>
                                        <Text style={tw`text-2xl h-9 text-[#03314B] font-bold ml-2`}>
                                            {parseInt(walletData?.amount).toFixed(2)}
                                        </Text>
                                    </View>
                                </View>
                            </View>

                            <View style={tw` flex-row   items-center   justify-between w-9/12 mt-5`}>
                                <View style={tw`text-[#03314B] flex-row  text-xl font-bold`}>

                                    <Text style={tw`text-xl  text-[#03314B] font-bold `}>Amount to be Paid :</Text>
                                </View>
                                <View>
                                    <Text style={tw`text-[#03314B] flex-row  text-md font-bold`}>${amount != "" && (parseFloat(stockValue?.price) * parseFloat(amount)).toFixed(3)}</Text>
                                </View>
                            </View>
                            <View style={tw`justify-center items-center mt-30`}>
                                <SwipeButton
                                    containerStyles={{ borderRadius: 10, borderColor: '#BD0B30', }}
                                    height={50}
                                    width={320}
                                    disabledThumbIconBorderColor={'#171717'}
                                    onSwipeFail={() => {
                                        setSlide(false)
                                    }}
                                    onSwipeStart={() => {
                                        setSlide(false)
                                    }}
                                    onSwipeSuccess={() => {
                                        setSlide(true)
                                        handleTransaction()
                                    }
                                    }

                                    railBackgroundColor="#171717"
                                    railFillBackgroundColor='white'
                                    shouldResetAfterSuccess={true}
                                    railStyles={{ borderRadius: 10, backgroundColor: 'white', borderColor: 'white', marginVertical: '2%', marginHorizontal: '2%' }}
                                    thumbIconComponent={CheckoutButton}
                                    thumbIconBorderColor={'white'}
                                    title="Swipe to Buy"
                                    titleFontSize={20}
                                    titleStyles={{ color: 'white', paddingLeft: '20%', zIndex: 1001 }}
                                />
                            </View>
                        </>
                    }
                    {activeTab == 1 &&

                        <>
                            <View style={tw`w-11/12   mt-10 `}>

                                <Image source={ImageIcons.Base} resizeMode='contain' style={tw`w-12/12 h-40`} />
                                <View style={tw` h-40 absolute inset-0 flex justify-center items-center p-3 mx-4`}>
                                    <View style={tw`flex flex-row  justify-between items-center w-12/12  `}>
                                        <View style={tw`text-[#03314B] flex-row  text-xl font-bold`}>
                                            <Text style={tw`text-[#03314B] text-xl font-bold`}>{stockValue?.symbol}</Text>

                                            <Text style={tw`text-base text-gray-500`}>({(stockValue?.name).substring(0, 15)}....)</Text>
                                        </View>
                                        <View>
                                            <Text style={tw`text-[#03314B] flex-row text-md font-bold`}>{stockValue?.price}</Text>
                                        </View>
                                    </View>
                                    <View style={tw`flex flex-row  justify-between items-center w-12/12 `} >
                                        <TextInput
                                            style={tw` text-5 font-bold text-[#03314B] border-white rounded-2 h-12  w-60 `}
                                            value={amount}
                                            type='text'
                                            placeholder={'Enter Quantity'}
                                            placeholderTextColor={'#03314B'}
                                            onChangeText={handleAmountChange}
                                            keyboardType="numeric"
                                            selectionColor="Black"
                                        />
                                        <Image source={ImageIcons.Calculator} resizeMode='contain' style={tw`  h-8 w-8`} />
                                    </View>
                                </View>

                            </View>
                            <View style={tw`flex justify-center items-center  mt--7`}>
                                <Image source={ImageIcons.Rest} resizeMode='contain' style={tw`h-14 w-20`} />
                            </View>

                            <View style={tw`w-11/12  mt-5 relative mt--7 w-11/12 `}>
                                <Image source={ImageIcons.foreximg} resizeMode='contain' style={tw`w-12/12 h-40  `} />
                                <View style={tw` h-40 absolute top-0 left-0 right-0 bottom-0 mx-8 justify-center `}>
                                    <View style={tw`flex-row items-center justify-left  w-12/12`} >
                                        <Text style={tw`text-xl text-[#03314B] font-bold text-center`}>Amount of asset you hold</Text>
                                    </View>
                                    <View style={tw`flex-row items-center justify-left  w-12/12`}>
                                        <Text style={tw`text-2xl text-[#03314B] font-bold`}>$</Text>
                                        {(assestsHold && assestsHold?.price !="" && assestsHold?.price !=null && assestsHold?.price !=undefined) ?
                                            <Text style={tw`text-2xl h-9 text-[#03314B] font-bold ml-2`}>
                                                {parseInt(assestsHold?.price).toFixed(2)}
                                            </Text>
                                        :
                                            <Text style={tw`text-2xl h-9 text-[#03314B] font-bold ml-2`}>
                                                0
                                            </Text>
                                        }
                                    </View>
                                </View>
                            </View>

                            <View style={tw` flex-row   items-center mt-5  justify-between  w-9/12`}>
                                <View style={tw`text-[#03314B] flex-row   text-xl font-bold`}>

                                    <Text style={tw`text-xl  text-[#03314B] font-bold `}>Total amount :</Text>
                                </View>
                                <View>
                                    <Text style={tw`text-[#03314B] flex-row  text-md font-bold`}>${amount != "" && (parseFloat(stockValue?.price) * parseFloat(amount)).toFixed(3)}</Text>
                                </View>
                            </View>
                            <View style={tw`justify-center items-center mt-30`}>
                                <SwipeButton
                                    containerStyles={{ borderRadius: 10, borderColor: '#BD0B30', }}
                                    height={50}
                                    width={320}
                                    disabledThumbIconBorderColor={'#BD0B30'}
                                    onSwipeFail={() => {
                                        setSlide(false)
                                    }}
                                    onSwipeStart={() => {
                                        setSlide(false)
                                    }}
                                    onSwipeSuccess={() => {
                                        setSlide(true)
                                        handleTransactionSell()
                                    }
                                    }

                                    railBackgroundColor="#171717"
                                    railFillBackgroundColor='white'
                                    shouldResetAfterSuccess={true}
                                    railStyles={{ borderRadius: 10, backgroundColor: 'white', borderColor: 'white', marginVertical: '2%', marginHorizontal: '2%' }}
                                    thumbIconComponent={CheckoutButton}
                                    thumbIconBorderColor={'white'}
                                    title="Swipe to Sell"
                                    titleFontSize={20}
                                    titleStyles={{ color: 'white', paddingLeft: '20%', zIndex: 1001 }}
                                />
                            </View>
                        </>
                    }
                </View>
            </ScrollView>
        </KeyboardAvoidingView>

    )
}

export default Buy;