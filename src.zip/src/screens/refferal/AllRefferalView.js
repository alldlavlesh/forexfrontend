import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';

import LinearGradient from 'react-native-linear-gradient';
// import { getTransactionsList } from '../../redux/actions/Coupon';

const AllRefferalView = (props) => {

    useEffect(() => {
        props?.referralListing();
    }, [])

    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };

    const renderItem = ({ item, index }) => {
        return (
            <View style={tw`justify-between my-2 p-2 mx-auto h-15 w-11/12 bg-[#FFFFFF] shadow-lg shadow-[#7D64FF] rounded-[4]`}>
                <Text>Your Refferal {item.referral.email} Joined on: {moment(item.createdAt)?.format('MMM DD YYYY')}</Text>
                <View style={tw`flex-row`}>
                    {/* {item.first_referral && <> */}
                    <View style={tw`w-12/12`}>
                        {/* <Text style={tw`font-bold text-[#C6C4CA] text-sm my-1`}>1st Connection:</Text>    */}
                        <Text style={tw`text-[#FF839E] text-sm`}>{item.referral.email}</Text>
                    </View>
                    {/* </>
                } */}
                    {/* {item.second_referral && <>
                        <View style={tw`w-6/12`}>
                            <Text style={tw`font-bold text-[#C6C4CA] text-sm my-1`}>2nd Connection:</Text>   
                            <Text style={tw`text-[#FF839E] text-sm`}>{item.second_referral.email}</Text>                            
                        </View>                        
                </>
                }   */}
                </View>
            </View>
        )
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>

            <CustomHeaderTab {...props} isActive={false} selected={"Coupon"} parent={false} name={'Referral Listing'} isReffer={false} />
            <ScrollView style={tw`bg-white `}>
                <View>
                    <FlatList
                        data={props?.refferalList}
                        renderItem={renderItem}
                        keyExtractor={item => item?.id}
                        ListEmptyComponent={renderEmptyComponent}
                    />
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    )
}

export default AllRefferalView;