import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Share from 'react-native-share';

import LinearGradient from 'react-native-linear-gradient';
// import { getTransactionsList } from '../../redux/actions/Coupon';

const AllRefferalView = (props) => {

   
    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };

    const openshare=()=>{
        let options = {
          message:'My Refferal Code is '+props?.getUserdetail?.userName+'6565',
          url: '',
        };

        Share.open(options)
          .then((res) => {
            console.log(res);
          })
          .catch((err) => {
            err && console.log(err);
          });
    }


    const renderItem = ({ item, index }) => {
        return (
            <View style={tw`justify-between my-2 p-2 mx-auto h-15 w-11/12 bg-[#FFFFFF] shadow-lg shadow-[#7D64FF] rounded-[4]`}>
                <Text>Your Refferal Joined on: {moment(item.createdAt)?.format('MMM DD YYYY')}</Text>
                <View style={tw`flex-row`}>
                    {/* {item.first_referral && <> */}
                    <View style={tw`w-12/12`}>
                        {/* <Text style={tw`font-bold text-[#C6C4CA] text-sm my-1`}>1st Connection:</Text>    */}
                        <Text style={tw`text-[#FF839E] text-sm`}>{item.referral.email}</Text>
                    </View>
                    {/* </>
                } */}
                    {/* {item.second_referral && <>
                        <View style={tw`w-6/12`}>
                            <Text style={tw`font-bold text-[#C6C4CA] text-sm my-1`}>2nd Connection:</Text>   
                            <Text style={tw`text-[#FF839E] text-sm`}>{item.second_referral.email}</Text>                            
                        </View>                        
                </>
                }   */}
                </View>
            </View>
        )
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>


            <ScrollView style={tw`bg-white `}>
               
            <View style={tw`items-center bg-[#ffffff] mt-9 w-12/12`}>
                <View style={tw`mt-5 flex-row w-4.5/12 `}>
                    <Text style={tw`font-bold text-lg text-center mt-2`}>Reffer A Friend</Text>
                    <TouchableOpacity onPress={() => props?.navigation?.navigate('AllRefferalView')} style={tw` ml-25`}>
                        <Image source={ImageIcons.refferFriend} style={tw`h-5 w-5 `} />
                    </TouchableOpacity>
                </View>
            </View>

                <View style={tw`mt-15`}>
                    <Image source={ImageIcons.circle} style={[tw`h-30 w-70 ml-10`,{resizeMode:'contain'}]} />
                </View>
                <View>
                    <Image source={ImageIcons.Refferalframe} style={[tw`h-40 w-30 ml-32 mt--45`, {resizeMode:'contain'}]} />
                </View>
                <View style={tw`mt-6 w-10/12 mx-auto`}>
                    <Text style={tw`text-[#03314B] font-bold text-3xl    text-center`}>Refer & Earn</Text>
                </View>
                <View style={tw`mt-8 w-10/12 mx-auto`}>
                    <Text style={tw`text-[#6C727F] text-base mt-3    text-center`}>Share this code with your friend and
                        both of you will get $10 free stocks.</Text>
                </View>
                <TouchableOpacity>
                <View style={tw`mx-5  bg-[#F5F5FD] text-black border border-[#F178B6] border-dashed bg-white rounded-4 h-20 mt-15 pl-4`}>
                    <Text style={tw`text-[#03314B] text-lg mt-7  w-7/12 font-bold`}> {props?.getUserdetail?.userName}6565 </Text>
                    <Image source={ImageIcons.Copy} style={[tw` h-10 w-10 ml-38 mt--8`]} />
                    <Text style={tw` text-[#F61C7A] text-lg ml-51 mt--9 font-bold`}>Copy Code</Text>
                </View>
                </TouchableOpacity>
                <View style={tw`mt-13`}>
                    <TouchableOpacity onPress={() => openshare()} style={tw` h-13 w-76 mx-auto bg-[#E0F64B]  items-center  justify-center rounded-[5] p-1  mt-3`} >
                        <Text style={tw`text-[#000000] w-100 text-[4.5] px-35 ml-10 font-bold`}>Refer friend</Text>
                    </TouchableOpacity>
                </View>

            </ScrollView>

             <CustomBottomTab {...props} isActive={true} selected={"Coupon"} />
        </KeyboardAvoidingView>

    )
}

export default AllRefferalView;