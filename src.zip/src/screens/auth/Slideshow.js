// React Native App Intro Slider using AppIntroSlider
// https://aboutreact.com/react-native-app-intro-slider/
// Intro slider with a button in the center

// import React in our code
import React, { useState, useRef } from 'react';
import { Fonts, Colors, ImageIcons } from '../../common';
import tw from 'twrnc'

// import LinearGradient from 'react-native-linear-gradient';

// import Icon from 'react-native-vector-icons/FontAwesome';
// import all the components we are going to use
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  Image,
  Button,
  FlatList,
  ImageBackground,
  TouchableOpacity,
  StatusBar,
  Dimensions,
  Platform
} from 'react-native';

//import AppIntroSlider to use it
import LinearGradient from 'react-native-linear-gradient';
import AppIntroSlider from 'react-native-app-intro-slider';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
// import { SwiperFlatList } from '../../components/react-native-swiper-flatlist';
import { CustomPagination } from './CustomPagination';

const { width, height } = Dimensions.get('window');

const Slideshow = (props) => {

  const {
    navigation,
    values,
    errors,
    handleChange,
    handleSubmit,
  } = props;
  const listRef = useRef();
  const [showRealApp, setShowRealApp] = useState(false);
  let [ShowComment, setShowModelComment] = useState(true);
  let [animateModal, setanimateModal] = useState(false);
  const [currentIndex, setcurrentIndex] = useState(0);
  const SCREEN_HEIGHT = Dimensions.get('screen').height;
  const [panelProps, setPanelProps] = useState({
    fullWidth: true,
    openLarge: true,
    showCloseButton: false,
    onClose: () => closePanel(),
    onPressCloseButton: () => closePanel(),
    // ...or any prop you want
  });
  const [isPanelActive, setIsPanelActive] = useState(true);

  const openPanel = () => {
    setIsPanelActive(true);

  };

  const closePanel = () => {
    setIsPanelActive(false);
  };


  const onDone = () => {
    props.navigation.navigate("Login")
  };

  const RenderNextButton = () => {
    return (

      <LinearGradient colors={['#DE3163', '#DE8206']} start={{ x: 0.1, y: 1.0 }}
        end={{ x: 1.0, y: 0.1 }}
        locations={[0.0, 1.0]} style={tw` h-16 w-55 mt-6  mx-20 items-center  justify-center rounded-[6] p-1 `} >
        <Text style={tw`text-white text-[4.5] font-bold  `}>Next</Text>
      </LinearGradient>

    );
  };



  const RenderDoneButton = () => {
    return (
      <LinearGradient colors={['#DE3163', '#DE8206']} start={{ x: 0.1, y: 1.0 }}
        end={{ x: 1.0, y: 0.1 }}
        locations={[0.0, 1.0]} style={tw` h-16 w-55  mx-20   items-center  justify-center rounded-[6] p-1 `} >
        <Text style={tw`text-white text-[4.5] font-bold `}>Next</Text>
      </LinearGradient>
    );
  };

  const slides = [
    {
      key: 0,
      title: 'SET YOUR FINANCIAL GOALS',
      image: ImageIcons.landing_img2,
      text: " Your goals will help us to formulate the right recommendation for success",
      backgroundColor: '#000000',
      margin: (Platform.OS == 'ios') ? SCREEN_HEIGHT/17 : SCREEN_HEIGHT/22
    },
    {
      key: 1,
      title: 'SET YOUR FINANCIAL GOALS',
      text: " Your goals will help us to formulate the right recommendation for success",
      image: ImageIcons.landing_img3,
      backgroundColor: '#000000',
      margin: (Platform.OS == 'ios') ? SCREEN_HEIGHT/17 : SCREEN_HEIGHT/26
    },
    {
      key: 2,
      title: 'SET YOUR FINANCIAL GOALS',
      text: " Your goals will help us to formulate the right recommendation for success",
      image: ImageIcons.landing_img4,
      backgroundColor: '#000000',
      margin: (Platform.OS == 'ios') ? SCREEN_HEIGHT/17 : SCREEN_HEIGHT/28
    },


  ];

  const RenderItem = ({ item, index }) => {
    return (
      <View style={[tw`W-12/12 bg-[#002662] flex-2 `,{ height: '100%' }]}>
        <View style={tw`items-center  justify-center ${`mt-`+item.margin}`}>

          <Image
            resizeMode='contain'
            style={{ height: 300 }}
            source={item.image} />

          <Text style={tw`text-base text-white mx-auto mt-12 w-4.5/12 text-center font-bold `}>
            {item.title}
          </Text>

          <View><Text style={tw`text-sm text-center text-white mt-4  px-6`}>{item.text}</Text></View>
          <TouchableOpacity onPress={() => props?.navigation?.navigate("WelcomeBack")}>
            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
              end={{ x: 1.0, y: 0.1 }}
              locations={[0.0, 1.0]} style={tw` h-16 w-55 my-14  mx-20  items-center  justify-center rounded-[6] p-1 `}
            >
              <Text style={tw`text-white text-base font-bold  `}>Next</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const onViewableItemsChanged = ({ viewableItems, changed }) => {
    if (viewableItems[0]?.isViewable) {
      setcurrentIndex(viewableItems[0]?.index);
    }
  }

  const viewabilityConfigCallbackPairs = useRef([
    {
      onViewableItemsChanged,
      viewabilityConfig: {
        waitForInteraction: true,
        minimumViewTime: 600,
        itemVisiblePercentThreshold: 60
      },
    },
  ]);

  return (
    <>
      {/* <SwipeablePanel style={tw` bg-[#000000] flex-row`} {...panelProps} isActive={isPanelActive}> */}
      <View style={tw`bg-[#000]`}>
        {/* <FlatList
                style={{ backgroundColor: '#000' }}
                keyboardShouldPersistTaps={'always'}
                showsVerticalScrollIndicator={true}
                nestedScrollEnabled={true}
                bounces={false}
                keyExtractor={(item, index) => index.toString()}
                data={slides}
                renderItem={RenderItem}
                pagingEnabled={true}
                viewabilityConfigCallbackPairs={
                  viewabilityConfigCallbackPairs.current
                }
                ref={listRef}
                maxToRenderPerBatch={12}
                initialNumToRender={0}
                removeClippedSubviews={true}
              /> */}

        <SwiperFlatList
          autoplay
          autoplayDelay={5}
          autoplayLoop
          index={0}
          showPagination={true}
          vertical={true}
          data={slides}
          renderItem={RenderItem}
          PaginationComponent={CustomPagination}
        />
      </View>
      {/* </SwipeablePanel> */}
    </>

  );
};
const styles = StyleSheet.create({
  containerContent: { flex: 1, marginTop: 40 },
  containerHeader: {
    flex: 1,
    alignContent: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    backgroundColor: '#F1F1F1',
  },
  headerContent: {
    marginTop: 0,
  },
  Modal: {
    backgroundColor: '#005252',
    marginTop: 0,
  },
  container: { flex: 1, backgroundColor: 'white' },
  child: { width, justifyContent: 'center', height },
  text: { fontSize: width * 0.5, textAlign: 'center' },

});


export default Slideshow;