// React Native App Intro Slider using AppIntroSlider
// https://aboutreact.com/react-native-app-intro-slider/
// Intro slider with a button in the center

// import React in our code
import React, { useState, useEffect } from 'react';
import { TouchableOpacity } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import tw from 'twrnc';
// import Icon from 'react-native-vector-icons/FontAwesome';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// import all the components we are going to use
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  Image,
  Button,
} from 'react-native';

//import AppIntroSlider to use it
import AppIntroSlider from 'react-native-app-intro-slider';

const Landing = (props) => {

  const {
    navigation,
    values,
    errors,
    handleChange,
    handleSubmit,
  } = props;

  const [showRealApp, setShowRealApp] = useState(false);

  const onDone = () => {
    props.navigation.navigate("Getstarted")
  };
  const onSkip = () => {
    props.navigation.navigate("Getstarted")
    //props.navigation.navigate("Documentverification",{response:{_id:"66a7adfe97972d1824b900f8"}})
  };

  useEffect(() => {
    // props.assignlogindata();
  }, [])

  const RenderNextButton = () => {
    return (
      <View style={tw` h-13 w-76 mt-6 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1 `} >
        <Text style={tw`text-black text-[4.5]  px-15 `}>Continue</Text>
      </View>
    );
  };

  const RenderSkipButton = () => {
    return (
      <View style={tw` h-13 w-76 mx-auto bg-[#1F1F1F] items-center  justify-center rounded-[2] p-1 `} >
      <Text style={tw`text-[#B8B8B8] text-[4.5]  px-15 `}>Skip</Text>
    </View>
    );
  };
  const RenderDoneButton = () => {
    return (
      <View>
      <View style={tw` h-13 w-76 mt-6 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1 `} >
        <Text style={tw`text-black text-[4.5]  px-15 `}>Continue</Text>
      </View>
       <View style={tw` h-13 w-76 mx-auto bg-[#1F1F1F] items-center  justify-center rounded-[2] p-1 `} >
       <Text style={tw`text-[#B8B8B8] text-[4.5]  px-15 `}>Skip</Text>
     </View>
     </View>
    );
  };




  const slides = [
    {
      key: 's1',
      title: 'Exchange, Buy & Sell Forex',
      image: ImageIcons.stock,
      text: 'Easily buy Bitcoin and other cryptocurrencies using  a wide range of payment options',
      backgroundColor: '#1F1F1F',
    },
    {
      key: 's2',
      title: 'Track Value Change Each Digital Currency ',
      text: "For each digital currency, there is information about its current market cap, price, 24-hour trading volume",
      image: ImageIcons.stock,
      backgroundColor: '#1F1F1F',
    },
    {
      key: 's3',
      title: 'Collect, Sell & Buy  Digital Arts',
      text: "Discover exclusive digital collectibles and their non-fungible tokens using InCrypto today",
      image: ImageIcons.stock,
      backgroundColor: '#1F1F1F',
    },

  ];

  const RenderItem = ({ item }) => {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: item.backgroundColor,
        }}
        >
        <View  style={tw`h-7/12 w-12/12 `}>
          <Image
            style={tw`ml-7 mt-25`}
            source={item.image} />
        </View>
        <Text style={tw`text-4xl text-white mx-auto font-bold`}>
          {item.title}
        </Text>
        <View><Text style={tw`text-sm text-left mx-4 text-white mt-3`}>{item.text}</Text></View>
      </View>
    );
  };

  return (
    <>
      {showRealApp ? (
        <SafeAreaView style={styles.container}>
          <View style={styles.container}>
            <Text style={styles.titleStyle}>
              React Native App Intro Slider using AppIntroSlider
            </Text>
            <Text style={styles.paragraphStyle}>
              This will be your screen when you click Skip
              from any slide or Done button at last
            </Text>
            <Button
              title="Show Intro Slider again"
              onPress={() => setShowRealApp(false)}
            />
          </View>
        </SafeAreaView>
      ) : (
        <AppIntroSlider
          data={slides}
          renderItem={RenderItem}
          onDone={onDone}
          onSkip={onSkip}
          bottomButton
          showSkipButton={true}
          renderNextButton={RenderNextButton}
          renderDoneButton={RenderDoneButton}
          renderSkipButton={RenderSkipButton}
          dotStyle={{
            backgroundColor: "#515151",
            bottom: 160,
            right:150
          }}
          activeDotStyle={{
            backgroundColor: "#ffffff",
            bottom: 160,
            right:150
          }}
        />
      )}
    </>
  );
};

export default Landing;



