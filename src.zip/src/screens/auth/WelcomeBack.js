import React, { useEffect, useRef, useState } from 'react';
import { Text, Image, View, ImageBackground, SafeAreaView, ScrollView, Alert, StatusBar, Animated, KeyboardAvoidingView, Platform, Keyboard, TouchableOpacity, Button, TextInput } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import CheckBox from '@react-native-community/checkbox';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common'
import ImageIcons from '../../common/ImageIcons'
import select from '../../common/select.png'
// import arrowleft from '../../common/arrowleft.png'
import InputField from '../../components/forms/inputField';
import { RoundedButton } from '../../components/forms/button';
import Loader from '../../components/modals/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';
import { requestMultiplePermisisons } from '../../services/permission';
import { white } from 'react-native-paper/lib/typescript/styles/colors';
import tw from 'twrnc';
// import { TextInput } from 'react-native-gesture-handler';
const WelcomeBack = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    //Reference
    const emailInputRef = useRef();
    const passwordInputRef = useRef();

    // Local states
    const [isShowPassword, setIsShowPassword] = useState(true);
    const [rememberMe, setRememberMe] = useState(false)
    const [refreshFiled, setRefreshFiled] = useState(false)
    const [deviceToken, setDeviceToken] = useState();
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [isValidEmail, setIsValidEmail] = useState(false);
    const [validPass, setValidPass] = useState(false);
    const [enabled3, setEnabled3] = useState(false)
    const [loginButtonColor, setLoginButtonColor] = useState('white');
    const [signupButtonColor, setSignupButtonColor] = useState('white');

    
    

    const handleLoginButtonClick = () => {
        setLoginButtonColor(['#C40730', '#FD5578']);
        setSignupButtonColor('white');
        setTimeout(()=>{
            props.navigation.navigate('Login')

        },1000)

    };

    const handleSignupButtonClick = () => {
        setSignupButtonColor(['#C40730', '#FD5578']);
        setLoginButtonColor('white');
        setTimeout(()=>{
            props.navigation.navigate('Registration')

        },1000)
        
    };

    return (


        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw` justify-center`}>

            {/* <StatusBar backgroundColor={Colors.BLACK} barStyle="light-content" translucent={true} /> */}

            <ScrollView style={tw`flex bg-[#fff] h-12/12`}>
                {/* <View> */}
                <View style={tw`flex-1 h-10/12`}>
                    <ImageBackground source={ImageIcons.Ellipse_welcome} style={tw`h-100% w-12/12`}>
                        <Image source={ImageIcons.Pngtree} style={tw`h-70  w-7/12 mt-6 ml-4`} />
                        <View style={tw`w-8/12 mt-5`}>
                            <Text style={tw`text-[#ffffff] font-bold text-5xl mx-5`}>Welcome Back!!</Text>
                        </View>
                    </ImageBackground>

                </View>
                <View style={tw`mb-35 h-2/12`}>
                <TouchableOpacity
                    onPress={handleLoginButtonClick}
                    style={{ backgroundColor: loginButtonColor }}
                >
                    {loginButtonColor === 'white' ? (
                     <View style={tw` h-14 w-11.5/15 mt-15  mx-auto  items-center  justify-evenly rounded-[4] p-1 border flex-row `}>
                     <Text style={tw`text-black text-sm font-bold `}>Login</Text>
                     </View>
                    ) : (
                        <LinearGradient
                            colors={['#C40730', '#FD5578']}
                            start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw` h-14 w-9.2/12 mt-15 mx-auto  items-center  justify-evenly rounded-[4] p-1 flex-row `}
                        >
                            <Text style={tw`text-[#fff] font-bold`}>Login</Text>
                        </LinearGradient>
                    )}
                </TouchableOpacity>

                <TouchableOpacity
                    onPress={handleSignupButtonClick}
                    style={{ backgroundColor: signupButtonColor }}
                >
                    {signupButtonColor === 'white' ? (
                     <View style={tw` h-14 w-9.2/12 mt-7  mx-auto  items-center  justify-evenly rounded-[4] p-1 border flex-row `}>
                     <Text style={tw`text-black text-sm font-bold `}>Signup</Text>
                     </View>
                    ) : (
                        <LinearGradient
                            colors={['#C40730', '#FD5578']}
                            start={{ x: 0.1, y: 1.0 }}
                            end={{ x: 1.0, y: 0.1 }}
                            locations={[0.0, 1.0]} style={tw` h-14 w-9.2/12 mt-7 mx-auto  items-center  justify-evenly rounded-[4] p-1 flex-row `}

                        >
                            <Text style={tw`text-[#fff] font-bold`}>Signup</Text>
                        </LinearGradient>
                    )}
                </TouchableOpacity>
                </View>
                
                {/* </View> */}
            </ScrollView>




        </KeyboardAvoidingView>

    )
}


const formikEnhancer = withFormik({
    validateOnMount: true,
    validationSchema: Yup.object().shape({
        email: Yup.string().required('Please enter email address').email('Please enter a valid email address'),
        password: Yup.string().required('Please enter password'),
    }),
    mapPropsToValues: (props) => {
        return {
            email: '',
            password: '',
        };
    },
    handleSubmit: async (payload, { props }) => {
        // props.login(payload)
    },
});


export default formikEnhancer(WelcomeBack);