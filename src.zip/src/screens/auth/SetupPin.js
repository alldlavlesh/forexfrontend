import React, { useRef, useEffect, useState } from 'react';
import { View, Image, SafeAreaView, ImageBackground, Linking, Button, TouchableOpacity, ScrollView, Alert, Animated, StatusBar, KeyboardAvoidingView, Platform, Keyboard, Text, TextInput } from 'react-native';
import { withFormik } from 'formik';
import LinearGradient from 'react-native-linear-gradient';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, ImageIcons, CommonStrings } from '../../common';

import InputField from '../../components/forms/inputField';
import { LocationInputButton, RoundedButton } from '../../components/forms/button';
import { phoneRegExp } from '../../services/helper';
import Loader from '../../components/modals/Loader'
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import CategorySearch from '../../components/forms/inputField/CategorySearch';
import WarningModal from '../../components/modals/WarningModal';
import { useDispatch } from 'react-redux';
//import { SET_BUSINESS_EXISTANCES } from '../../redux/actions/ActionTypes';
import CheckBox from '@react-native-community/checkbox';
export const passwordValidationRegx = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
import select from '../../common/select.png'
import arrow from '../../common/arrowleft.png'
import tw from 'twrnc';
import branch from 'react-native-branch';
import { requestMultiplePermisisons } from '../../services/permission';
import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';

const SetupPin = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const dispatch = useDispatch();

    //Reference
    const phonenoRef = useRef();
    const emailRef = useRef();
    const phoneRef = useRef();
    const bisinessnameRef = useRef();
    const contactPersonRef = useRef();
    const passwordRef = useRef();
    const passwordConfirmRef = useRef();
    const dbanameRef = useRef();
    //const recaptcha = useRef();
    // Local states
    const [isCheckPrivacy, setIsCheckPrivacy] = useState(false)
    const [coordinate, setCoordinate] = useState();
    const [businessType, setBusinessType] = useState();
    const [businessTypeId, setBusinessTypeId] = useState();
    const [vendorId, setVendorId] = useState(null);
    const [isScrollEnabled, setIsScrollEnabled] = useState(true);
    const [isShowPIN, setIsShowPIN] = useState(true);
    const [isShowConfirmPassword, setIsShowConfirmPassword] = useState(true);
    const emailInputRef = useRef();
    const passwordInputRef = useRef();
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [isValidEmail, setIsValidEmail] = useState(false);
    const [validPass, setValidPass] = useState(false);
    const [rememberMe, setRememberMe] = useState(false)
    const [phoneNumber, setPhoneNumber] = useState('');
    const [countryCode, setCountryCode] = useState('');

    const [validPhoneNumber, setvalidPhoneNumber] = useState(false);
    const [refferalId, setRefferalId] = useState('');
    const [deviceToken, setDeviceToken] = useState();
    const [keyboardStatus, setKeyboardStatus] = useState(0);
    const [randomstring, setRandomstring] = useState('');
    const [answer, setAnswer] = useState('')
    const [name, setName] = useState('')
    const [code, setCode] = useState('')



    // Animation references
    const fadeAnim = useRef(new Animated.Value(0)).current
    const transformAnim = useRef(new Animated.Value(300)).current

    useEffect(async () => {
        animateLogo();
        const status = await requestMultiplePermisisons();
    }, [fadeAnim, transformAnim])

    useEffect(() => {
        let vendorDetail = props?.route?.params && props?.route?.params?.vendorDetail || null;
        if (vendorDetail && vendorDetail !== null) {
            values.email = vendorDetail?.email;
            setVendorId(vendorDetail?._id);

        }
    }, [])

    useEffect(async () => {
        let refferalId = await AsyncStorage.getItem('@refferalId');
        setRefferalId(refferalId);
        requestUserPermission();
    }, [])

    useEffect(() => {
        createRandomString()
        const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
            setKeyboardStatus(1);
        });
        const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
            setKeyboardStatus(0);
        });

        return () => {
            showSubscription.remove();
            hideSubscription.remove();
        };
    }, []);

    const createRandomString = async () => {
        var getstring = Math.round((Math.pow(36, 8 + 1) - Math.random() * Math.pow(36, 8))).toString(36).slice(1);
        setRandomstring(getstring);
    }
    // Get the deep link used to open the app
    const getUrl = async () => {
        branch.skipCachedEvents()
        branch.subscribe(({ error, params, uri }) => {
            if (error) {
                console.error("fetchMyAPI Error from Branch: " + error)
                return
            }
            getInitialUniversalLink();
        })

        const getInitialUniversalLink = async () => {
            let lastParams = await branch.getLatestReferringParams() // params from last open
            let installParams = await branch.getFirstReferringParams() // params from original install
            // await AsyncStorage.setItem('@refferalId', lastParams.itemId);
        }
    };

    // Animation 
    const animateLogo = () => {
        Animated.parallel([
            Animated.timing(
                fadeAnim,
                {
                    toValue: 1,
                    duration: 1500,
                    useNativeDriver: true
                },

            ),
            Animated.timing(
                transformAnim,
                {
                    toValue: 0,
                    duration: 1500,
                    useNativeDriver: true
                },

            )
        ]).start()
    }

    // Get device token
    const requestUserPermission = async () => {
        const authStatus = await messaging().requestPermission();

        const enabled =
            authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
            authStatus === messaging.AuthorizationStatus.PROVISIONAL;
        if (enabled) {
            const _deviceToken = await messaging().getToken();
            setDeviceToken(_deviceToken)
        }
    }


    const cancelAddForce = () => {
        //dispatch({ type: SET_BUSINESS_EXISTANCES, payload: false });
        //props.navigation?.goBack();
    }

    // Address coordinates
    const getLocation = (coordinate) => {
        setCoordinate(coordinate);
    }

    // Add new business request submission
    const handleAddVendorSubmit = async (isForceAdd) => {
        Keyboard.dismiss();
        // if (errors.businessName) {
        //     Alert.alert(CommonStrings.AppName, errors.businessName)
        // } else if (errors.businessAddress) {
        //     Alert.alert(CommonStrings.AppName, errors.businessAddress)
        // } else if (!businessTypeId || businessTypeId === "" || businessTypeId === null) {
        //     Alert.alert(CommonStrings.AppName, "Please select a business type.")
        // } else if (errors.contactPerson) {
        //     Alert.alert(CommonStrings.AppName, errors.contactPerson)
        // } else if (errors.phoneNumber) {
        //     Alert.alert(CommonStrings.AppName, errors.phoneNumber)
        // } else 
        if (email == "") {
            Alert.alert(CommonStrings.AppName, "Enter Email Address")

        } else if (!isValidEmail) {
            Alert.alert(CommonStrings.AppName, "Enter Valid Email")
        }
        else if (password == "") {
            Alert.alert(CommonStrings.AppName, "Enter password")
        }
        else if (!validPass) {
            Alert.alert(CommonStrings.AppName, "Enter valid password. It should be Combination of  Letters & Numbers minimum 8 characters")
        }
        else if (phoneNumber == "") {
            Alert.alert(CommonStrings.AppName, "Enter phone number")
        }
        else if (!validPhoneNumber) {
            Alert.alert(CommonStrings.AppName, "Enter valid phone number")
        } else if (randomstring != answer) {
            Alert.alert(CommonStrings.AppName, "Invalid security captcha")
        }

        else {
            let finalBusinessName = String(values.businessName).replace(/\s\s+/g, ' ');
            let request = {
                "userName": name,
                "email": email,
                "phone": phoneNumber,
                "countryCode": countryCode ? countryCode : "AE",
                "password": password,
                "deviceToken": deviceToken,
                "role": "user",
                "refferalId": refferalId
            }
            // if (isForceAdd) {
            //     dispatch({ type: SET_BUSINESS_EXISTANCES, payload: false });
            // }
            setTimeout(() => {
                props.signupVendor(request, props.navigation);
            }, 500);
        }

        // else if (errors.confirmPassword) {
        //     Alert.alert(CommonStrings.AppName, errors.confirmPassword)
        // } else if (values.confirmPassword !== values.password) {
        //     Alert.alert(CommonStrings.AppName, "Password does not match.")
        // }

    }

    const openPrivacyPolicy = () => {
        Linking.openURL('https://wallpon.com/privacy-policy');
        //props.navigation.navigate('OTPVerification')
    }

    const openTerms = () => {
        Linking.openURL('http://vendor.wallpon.com/terms-and-conditions.html');
    }

    const handleEmailChange = (text) => {
        setEmail(text)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        setIsValidEmail(emailRegex.test(text));
    }


    const handlecodeChange = (number) => {
        setCode(number)
    }

    const handlePassswordChange = (value) => {
        // setPassword(value)

        // const passRegex = "^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/"
        // setValidPass(passRegex.test(value));
        const passwordRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})")
        setPassword(value)
        // alert('Password must be at least 8 characters long and contain at least one letter and one number.');
        setValidPass(passwordRegex.test(value));
    }
    const handlemobilechange = (value) => {
        setPhoneNumber(value)
        const phoneRegex = /^[0-9]{9,10}$/;
        setvalidPhoneNumber(phoneRegex.test(value));
    }

    const handleCountryCodeChange = (value) => {
        setCountryCode(value)
    }


    const send = () => {
        recaptcha.current.open();
    }

    const onVerify = token => {
    }

    const onExpire = () => {
        console.warn('expired!');
    }

    return (
        // <KeyboardAvoidingView behavior={Platform.OS === "ios" && "padding"} style={tw`flex-1 justify-center`}>
        // <View style={tw` bg-[#000000]`}>


        <ScrollView style={tw`bg-[#FAFAFA]`}>
            <View>
                <View style={tw`mt-20 `}>
                    <Image source={ImageIcons.Frame} style={tw`ml-35 h-30 w-22 `} />
                </View>
                <View>
                    <Text style={tw` text-center mt-10 text-3xl font-bold text-[#03314B]`}>Setup PIN</Text>
                    <Text style={tw` text-center mt-2 text-lg  text-[#8198A5] `}>Enter your PIN number</Text>
                </View>
            </View>

            <View>
                <TextInput
                    // style={tw`mx-10  bg-[#FFFFFF] text-black rounded-4 h-12 border mt-6   pl-8`}
                    style={tw`mx-5  bg-[#ffffff] text-blacK  text-2xl rounded-2 h-12 mt-10 pl-8`}
                    // value={values.email}
                    type='number'
                    placeholder={'Enter your pin'}
                    // value={password}
                    // onChangeText={handlePassswordChange}
                    placeholderTextColor={Colors.GREY}
                    secureTextEntry={isShowPIN}
                    password={true}
                    selectionColor="#C20A33"
                    keyboardType='numeric'
                />

                <TouchableOpacity style={tw`absolute right-15 bottom-3   `} onPress={() => setIsShowPIN(!isShowPIN)}>
                    {isShowPIN ?
                        <Image source={ImageIcons.eyeIconHide} style={tw`w-5 h-5`} />
                        :
                        <Image source={ImageIcons.eyeIcon} style={tw`w-5 h-5`} />
                    }

                </TouchableOpacity>
            </View>


            {/* <View style={tw`relative mt--2`}>
                            <PhoneMaskInput
                                style={tw`bg-[#ffffff] text-black border rounded-4 h-13 mt-5 `}
                                id="countryCode"
                                defaultValue={phoneNumber}
                                placeholder=" Enter Phone no."
                                defaultCode={'AE'}
                                // onCountryChange={handleChange('countryCode')}
                                onCountryCodeChange={handleCountryCodeChange}
                                layout="first"
                                // onCountryChange={handleChange('countryCode')}
                                onChangePhone={(value) => handlemobilechange(value)}
                                theme="white"
                                reference={phonenoRef}
                                returnKeyType='done'
                            /> */}
            {/* {validPhoneNumber &&
                                <>
                                    <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-8 w-8  justify-center text-center items-center rounded-[3.5]  absolute top-1/2 transform -translate-y-1/2 right-12 mt--1.2 `}
                                    >
                                        <View style={tw`flex-row `}>

                                            <Image
                                                source={select}
                                                style={[tw`h-7 w-7  `, { tintColor: 'white' }]}

                                            >
                                            </Image>
                                        </View>

                                    </LinearGradient>


                                </>

                            } */}

            {/* </View> */}

            {/* <TouchableOpacity onPress={() => props.navigation.navigate("OTPVerification")} style={tw`flex-row w-11/12 mt-2 mx-2 mb-10 items-center  justify-round `}>
                <Image source={ImageIcons.ICON} style={tw`w-5 h-5 mb-2  mx-auto`} />
                <Text style={tw` text-[#576284] font-bold w-10.5/12  mx-auto text-[3]`}>At Least 8 Characters mixture of upper case, lower
                    case, numbers & special characters (!@#$%^&*)</Text>
            </TouchableOpacity>

            <View style={tw`flex-row  h-10 w-11/12 mt-4 ml-6  mb-1 items-center  justify-round `}>
                <Image source={ImageIcons.Dot} style={tw`w-13 h-6 mx-auto`} />
                <Text style={tw`  text-[3.1] text-[#848484]  w-10/12  ml-2`}>By continuing you accept our Privacy Policy</Text>
                        </View> */}

            <View>
                <TouchableOpacity style={tw` h-13 w-76 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1  mt-50`} >
                    <Text style={tw`text-black w-89 text-[4.5] px-35  `}>Continue</Text>
                </TouchableOpacity>

                <Text style={tw` text-center mt-2 text-lg  text-[#8198A5] `}>Forget PIN?</Text>
                <Text style={tw`text-[#000000] w-38  h-0.2 text-[4.5] px-35 bg-black justify-center rounded-[2] p-1 mt-5 ml-28`}></Text>

            </View>
            {/* <View style={tw` h-13 w-86 mx-auto mb-2 items-center  justify-center rounded-[2] p-1 `}>
                <Text style={tw` text-[#848484] `}>  Already have an account? <TouchableOpacity  onPress={() => props.navigation.navigate("Login")} style={tw`  `}>
                    <Text  style={tw` text-[#848484]  mb--1`}>Sign in</Text></TouchableOpacity></Text></View> */}

            {/* <TouchableOpacity style={tw`justify-center items-center`} onPress={() => handleAddVendorSubmit(false)}>
                        <View style={tw`w-10/12 flex-row mt-3 justify-end items-center`}>
                            <Text style={tw`font-bold text-lg `}>Sign Up</Text>
                            <View style={tw`h-10 w-10 rounded-full bg-[#BD0B30] ml-2`}></View>
                            <Image source={ImageIcons.arrow_login} style={tw`h-4   absolute mt-3 right-3 w-5 `} />

                        </View>
                    </TouchableOpacity> */}

        </ScrollView>
        /* {keyboardStatus == 0 &&
                <View style={tw`absolute bottom-0 right-0`}>
                    <TouchableOpacity onPress={() => props.navigation.navigate('Login')}>
                        <ImageBackground source={ImageIcons.Ellipse_bottom} style={tw`h-20 w-41`}>
                            <Text style={tw`font-bold text-lg text-right text-[#fff] right-5 my-7`}>Sign In</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>
            } */
        // </View>
        // </KeyboardAvoidingView>


    )
}

const formikEnhancer = withFormik({
    // validateOnMount: true,
    validationSchema: Yup.object().shape({
        // businessName: Yup.string().required('Please enter business name'),
        // businessAddress: Yup.string().required('Please enter business address'),
        // businessType: Yup.string().required('Please select business type'),
        // contactPerson: Yup.string().required('Please enter contact person name'),
        // phoneNumber: Yup.string().required('Please enter phone number').matches(phoneRegExp, 'Phone number is not valid'),
        email: Yup.string().required('Please enter email address').email('Please enter a valid email address'),
        password: Yup.string().required("Password must contain minimum 8 characters including one number, one special character and one capital letter").matches(passwordValidationRegx, "Password must contain minimum 8 characters including one number, one special character and one capital letter"),
        //countryCode: Yup.string().required()
    }),
    mapPropsToValues: (props) => {
        return {
            businessName: '',
            businessAddress: '',
            businessType: '',
            contactPerson: '',
            phoneNumber: '',
            email: '',
            countryCode: '+1',
        };
    },
    handleSubmit: (payload, { props }) => {

    },

});


export default formikEnhancer(SetupPin);