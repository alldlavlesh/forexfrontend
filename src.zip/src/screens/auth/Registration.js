import React, { useRef, useEffect, useState, Component  } from 'react';
import { View, Image, Switch, SafeAreaView, ImageBackground, Linking, Button, TouchableOpacity, ScrollView, Alert, Animated, StatusBar, KeyboardAvoidingView, Platform, Keyboard, Text, TextInput } from 'react-native';
import { withFormik } from 'formik';
import LinearGradient from 'react-native-linear-gradient';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, ImageIcons, CommonStrings } from '../../common';

import InputField from '../../components/forms/inputField';
import { LocationInputButton, RoundedButton } from '../../components/forms/button';
import { phoneRegExp } from '../../services/helper';
import Loader from '../../components/modals/Loader'
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import CategorySearch from '../../components/forms/inputField/CategorySearch';
import WarningModal from '../../components/modals/WarningModal';
import { useDispatch } from 'react-redux';
//import { SET_BUSINESS_EXISTANCES } from '../../redux/actions/ActionTypes';
import CheckBox from '@react-native-community/checkbox';
export const passwordValidationRegx = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
import select from '../../common/select.png'
import arrow from '../../common/arrowleft.png'
import tw from 'twrnc';
import branch from 'react-native-branch';
import { requestMultiplePermisisons } from '../../services/permission';
import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';

const Registration = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const dispatch = useDispatch();

    //Reference
    const phonenoRef = useRef();
    const emailRef = useRef();
    const phoneRef = useRef();
    const bisinessnameRef = useRef();
    const contactPersonRef = useRef();
    const passwordRef = useRef();
    const passwordConfirmRef = useRef();
    const dbanameRef = useRef();
    //const recaptcha = useRef();

    const [isEnabled, setisEnabled] = React.useState(false);
    // Local states
    const [isCheckPrivacy, setIsCheckPrivacy] = useState(false)
    const [coordinate, setCoordinate] = useState();
    const [businessType, setBusinessType] = useState();
    const [businessTypeId, setBusinessTypeId] = useState();
    const [vendorId, setVendorId] = useState(null);
    const [isScrollEnabled, setIsScrollEnabled] = useState(true);
    const [isShowPassword, setIsShowPassword] = useState(true);
    const [isShowConfirmPassword, setIsShowConfirmPassword] = useState(true);
    const emailInputRef = useRef();
    const passwordInputRef = useRef();
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [isValidEmail, setIsValidEmail] = useState(false);
    const [validPass, setValidPass] = useState(false);
    const [rememberMe, setRememberMe] = useState(false)
    const [phoneNumber, setPhoneNumber] = useState('');
    const [countryCode, setCountryCode] = useState('');

    const [validPhoneNumber, setvalidPhoneNumber] = useState(false);
    const [refferalId, setRefferalId] = useState('');
    const [deviceToken, setDeviceToken] = useState();
    const [keyboardStatus, setKeyboardStatus] = useState(0);
    const [randomstring, setRandomstring] = useState('');
    const [answer, setAnswer] = useState('')
    const [name, setName] = useState('')



    // Animation references
    const fadeAnim = useRef(new Animated.Value(0)).current
    const transformAnim = useRef(new Animated.Value(300)).current
    const [selectedButton, setSelectedButton] = useState(null);

    const handleButtonPress = (buttonType) => {

        setSelectedButton(buttonType);
        setTimeout(() => {
            if (buttonType === 'Verification') {
                props.navigation.navigate('Verification'); // Navigate to the verification screen
            }
        }, 100);
    };

    useEffect(async () => {
        animateLogo();
        const status = await requestMultiplePermisisons();
    }, [fadeAnim, transformAnim])

    useEffect(() => {
        let vendorDetail = props?.route?.params && props?.route?.params?.vendorDetail || null;
        if (vendorDetail && vendorDetail !== null) {
            values.email = vendorDetail?.email;
            setVendorId(vendorDetail?._id);

        }
    }, [])

    useEffect(async () => {
        let refferalId = await AsyncStorage.getItem('@refferalId');
        setRefferalId(refferalId);
        requestUserPermission();
    }, [])

    useEffect(() => {
        createRandomString()
        const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
            setKeyboardStatus(1);
        });
        const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
            setKeyboardStatus(0);
        });

        return () => {
            showSubscription.remove();
            hideSubscription.remove();
        };
    }, []);

    const createRandomString = async () => {
        var getstring = Math.round((Math.pow(36, 8 + 1) - Math.random() * Math.pow(36, 8))).toString(36).slice(1);
        setRandomstring(getstring);
    }
    // Get the deep link used to open the app
    const getUrl = async () => {
        branch.skipCachedEvents()
        branch.subscribe(({ error, params, uri }) => {
            if (error) {
                console.error("fetchMyAPI Error from Branch: " + error)
                return
            }
            getInitialUniversalLink();
        })

        const getInitialUniversalLink = async () => {
            let lastParams = await branch.getLatestReferringParams() // params from last open
            let installParams = await branch.getFirstReferringParams() // params from original install
            // await AsyncStorage.setItem('@refferalId', lastParams.itemId);
        }
    };

    // Animation 
    const animateLogo = () => {
        Animated.parallel([
            Animated.timing(
                fadeAnim,
                {
                    toValue: 1,
                    duration: 1500,
                    useNativeDriver: true
                },

            ),
            Animated.timing(
                transformAnim,
                {
                    toValue: 0,
                    duration: 1500,
                    useNativeDriver: true
                },

            )
        ]).start()
    }


    //checkbox 
    class Checkbox extends Component {
        constructor() {
          super();
          this.state = {
            isChecked: false,
          };
        }
      
        toggleCheckbox = () => {
          this.setState({ isChecked: !this.state.isChecked });
        };
      
        render() {
          return (
            <TouchableOpacity
              style={[
                styles.checkbox,
                this.state.isChecked && styles.checkedCheckbox,
              ]}
              onPress={this.toggleCheckbox}
            >
              {this.state.isChecked && (
                <Image source={ImageIcons.checkmark3} style={styles.checkmark} />
              )}
            </TouchableOpacity>
          );
        }
      }

    // Get device token
    const requestUserPermission = async () => {
        const authStatus = await messaging().requestPermission();

        const enabled =
            authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
            authStatus === messaging.AuthorizationStatus.PROVISIONAL;
        if (enabled) {
            const _deviceToken = await messaging().getToken();
            setDeviceToken(_deviceToken)
        }
    }


    const cancelAddForce = () => {
        //dispatch({ type: SET_BUSINESS_EXISTANCES, payload: false });
        //props.navigation?.goBack();
    }

    // Address coordinates
    const getLocation = (coordinate) => {
        setCoordinate(coordinate);
    }

    // Add new business request submission
    const handleAddVendorSubmit = async (isForceAdd) => {
        Keyboard.dismiss();
        // if (errors.businessName) {
        //     Alert.alert(CommonStrings.AppName, errors.businessName)
        // } else if (errors.businessAddress) {
        //     Alert.alert(CommonStrings.AppName, errors.businessAddress)
        // } else if (!businessTypeId || businessTypeId === "" || businessTypeId === null) {
        //     Alert.alert(CommonStrings.AppName, "Please select a business type.")
        // } else if (errors.contactPerson) {
        //     Alert.alert(CommonStrings.AppName, errors.contactPerson)
        // } else if (errors.phoneNumber) {
        //     Alert.alert(CommonStrings.AppName, errors.phoneNumber)
        // } else 
        if (name == "") {
            Alert.alert(CommonStrings.AppName, "Enter Name")
        }
        else if (email == "") {
            Alert.alert(CommonStrings.AppName, "Enter Email Address")

        } else if (!isValidEmail) {
            Alert.alert(CommonStrings.AppName, "Enter Valid Email")
        }
        else if (password == "") {
            Alert.alert(CommonStrings.AppName, "Enter password")
        }
        else if (!validPass) {
            Alert.alert(CommonStrings.AppName, "Enter valid password. It should be Combination of  Letters & Numbers minimum 8 characters")
        }
        else if (isEnabled == false) {
            Alert.alert(CommonStrings.AppName, "Please accept Privacy Policy")
        }
        // else if (!validPhoneNumber) {
        //     Alert.alert(CommonStrings.AppName, "Enter valid phone number")
        // } else if (randomstring != answer) {
        //     Alert.alert(CommonStrings.AppName, "Invalid security captcha")
        // }

        else {
            let finalBusinessName = String(values.businessName).replace(/\s\s+/g, ' ');
            let request = {
                "userName": name,
                "email": email,
                "password": password,
                // "deviceToken": deviceToken,
                "role": "user",
            }
            props.signupVendor(request, props.navigation);
        }

    }

    const clearUserDetails = () => {
        setName('');
        setEmail('');
        setPassword('');
    };

    useEffect(() => {
        const unsubscribe = props.navigation.addListener('blur', clearUserDetails);

        // Cleanup the listener when the component unmounts
        return unsubscribe;
    }, [props.navigation]);


    const openPrivacyPolicy = () => {
        Linking.openURL('https://wallpon.com/privacy-policy');
        //props.navigation.navigate('OTPVerification')
    }

    const openTerms = () => {
        Linking.openURL('http://vendor.wallpon.com/terms-and-conditions.html');
    }

    const handleEmailChange = (text) => {
        setEmail(text)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        setIsValidEmail(emailRegex.test(text));
    }


    const handleNameChange = (text) => {
        setName(text)
    }

    const handlePassswordChange = (value) => {
        // setPassword(value)

        // const passRegex = "^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/"
        // setValidPass(passRegex.test(value));
        const passwordRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})")
        setPassword(value)
        // alert('Password must be at least 8 characters long and contain at least one letter and one number.');
        setValidPass(passwordRegex.test(value));
    }
    const handlemobilechange = (value) => {
        setPhoneNumber(value)
        const phoneRegex = /^[0-9]{9,10}$/;
        setvalidPhoneNumber(phoneRegex.test(value));
    }

    const handleCountryCodeChange = (value) => {
        setCountryCode(value)
    }


    const send = () => {
        recaptcha.current.open();
    }

    const onVerify = token => {
    }

    const onExpire = () => {
        console.warn('expired!');
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center  `}>

            <ScrollView style={tw`bg-[#FAFAFA] `}>
                <View style={tw`flex-1 bg-[#fff]  w-12/12 flex justify-center items-center`}>
                    <View style={tw`mt-20 mb-15 justify-center items-center`}>
                        <Text style={tw`text-black text-3xl font-bold `}> Create New  </Text>
                        <Text style={tw`text-black text-3xl font-bold `}>  Account </Text>

                    </View>
                    <View style={tw` justify-center items-start w-11/12`}>

                        <Text style={tw`text-black pl-3 text-[#848484] `}>FULL NAME</Text>
                    </View>
                    <View style={[tw`  justify-center mt-4 items-center w-11/12`]}>
                        <TextInput
                            // style={ tw`mx-5  bg-[#FFFFFF] text-black border-[#828282] rounded-4 h-12 mt-3  pl-8`}
                            style={[tw`  bg-[#ffffff] text-black border border-[#E8E8E8] rounded-2 w-12/12 h-12 pl-3`, { fontWeight: '600' }]}
                            value={name}
                            type='text'
                            placeholder={'Name'}
                            placeholderTextColor={Colors.GREY}
                            // onChangeText={handleChange('email')}
                            onChangeText={handleNameChange}
                            selectionColor="#C20A33"
                            onSubmitEditing={() => emailInputRef?.current?.focus()}
                        />
                    </View>


                    <View style={tw` justify-center mt-4 items-start w-11/12`}>

                        <Text style={tw`text-black pl-3 text-[#848484] `}>EMAIL</Text>
                    </View>
                    <View style={tw`  justify-center mt-4 items-center w-11/12`}>
                        <TextInput
                            // style={ tw`mx-5  bg-[#FFFFFF] text-black border-[#828282] rounded-4 h-12 mt-3  pl-8`}
                            style={[tw`  bg-[#ffffff] text-black border border-[#E8E8E8] rounded-2 w-12/12 h-12 pl-3`, { fontWeight: '600' }]}
                            value={email}
                            type='text'
                            placeholder={'Email'}
                            placeholderTextColor={Colors.GREY}
                            selectionColor="#C20A33"
                            onChangeText={handleEmailChange}
                            keyboardType="email-address"
                            reference={emailInputRef}
                            onSubmitEditing={() => passwordInputRef?.current?.focus()}
                        />
                    </View>

                    <View style={tw` justify-center items-start mt-4 w-11/12`}>
                        <Text style={tw`text-black pl-3 text-[#848484]`}>PASSWORD</Text>
                    </View>
                    <View style={tw`justify-center mt-4 items-center w-11/12`}>
                        <TextInput
                            // style={tw`mx-10  bg-[#FFFFFF] text-black rounded-4 h-12 border mt-6   pl-8`}
                            style={[tw`  bg-[#FFFFFF] text-black border border-[#E8E8E8] rounded-2 w-12/12 h-12 pl-3`, { fontWeight: '600' }]}
                            // value={values.email}
                            type='text'
                            placeholder={'Password'}
                            placeholderTextColor={Colors.GREY}
                            value={password}
                            secureTextEntry={isShowPassword}
                            password={true}
                            onChangeText={handlePassswordChange}
                            selectionColor="#C20A33"
                        />
                        <TouchableOpacity style={tw`absolute absolute right-5`} onPress={() => setIsShowPassword(!isShowPassword)}>
                            {isShowPassword ?
                                <Image source={ImageIcons.eyeIconHide} style={tw`w-5 h-5`} />
                                :
                                <Image source={ImageIcons.eyeIcon} style={tw`w-5 h-5`} />
                            }

                        </TouchableOpacity>
                    </View>
                    <View style={tw` flex-row justify-center mt-3 items-center  w-11/12`}>
                        <View style={styles.container}>
                           
                            <View style={styles.textContainer}>
                                <Text style={[styles.text,{textAlign:'center'}]}>
                                    Atleast 8 Characters mixture of upper case, lower case, numbers & special characters (!@#$%^&*)
                                </Text>
                            </View>
                        </View>
                    </View>

                    <View style={tw` flex-row justify-start mt-4 items-center  w-11/12 `}>
                        <View style={tw`  border-[0.5]  bg-[#E8E8E8]  rounded-[4] h-6 justify-center w-11 `}>
                            <Switch style={tw`w-11`}
                                value={isEnabled}
                                onValueChange={(value) => setisEnabled(value)}
                                trackColor={{ false: "#E8E8E8", true: "#E0F64B" }}
                                thumbColor={isEnabled ? "#313541" : "#313541"}
                                ios_backgroundColor='gray'
                            />
                        </View>
                        <Text style={tw` text-[3.1] text-[#848484] pl-2`}>By continueing you accept our Privacy Policy</Text>
                    </View>
                    <View style={tw`flex-row justify-center items-center  mt-8 w-11/12 `}>
                        <TouchableOpacity
                            style={tw`h-13 w-76  bg-[#E0F64B] items-center justify-center rounded-[2]  ${selectedButton === 'Verification'}`}
                            onPress={() => handleAddVendorSubmit(false)}
                            activeOpacity={0.7}
                        >
                            <Text style={tw`text-[4.5] ${selectedButton === 'Verification'}`}>
                                Create Personal Account
                            </Text>
                        </TouchableOpacity>
                    </View>

                    <View style={tw`flex-row justify-center items-center mt-5 w-11/12 mb-15`}>
                        <Text style={tw` text-[#848484] `}> Already have an account?</Text>
                        <TouchableOpacity onPress={() => props.navigation.navigate("Login")} style={tw`  `}>
                            <Text style={tw` text-[#848484] `}>Sign In</Text>
                        </TouchableOpacity>

                    </View>
                </View>

            </ScrollView>
        </KeyboardAvoidingView >


    )
}

const formikEnhancer = withFormik({
    // validateOnMount: true,
    validationSchema: Yup.object().shape({
        email: Yup.string().required('Please enter email address').email('Please enter a valid email address'),
        password: Yup.string().required("Password must contain minimum 8 characters including one number, one special character and one capital letter").matches(passwordValidationRegx, "Password must contain minimum 8 characters including one number, one special character and one capital letter"),
    }),
    mapPropsToValues: (props) => {
        return {
            businessName: '',
            businessAddress: '',
            businessType: '',
            contactPerson: '',
            phoneNumber: '',
            email: '',
            countryCode: '+1',
        };
    },
    handleSubmit: (payload, { props }) => {

    },

});


export default formikEnhancer(Registration);