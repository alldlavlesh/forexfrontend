import React, { useEffect, useState } from 'react';
import { Text, KeyboardAvoidingView, View, TextInput, FlatList, Dimensions, Button, StatusBar, ImageBackground, TouchableOpacity, ScrollView, SafeAreaView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CheckBox from '@react-native-community/checkbox';
// import {
//   widthPercentageToDP as wp,
//   heightPercentageToDP as hp,
// } from 'react-native-responsive-screen';

// import moment from 'moment';
import Loader from '../../components/modals/Loader';
// import Editprofile from '../profile/Editprofile';
// import { SwipeablePanel } from 'rn-swipeable-panel';
// import { RadioButton, Provider, Portal, Button, } from 'react-native-paper';
// import Modal from 'react-native-modal'
// import { FlatListSlider } from 'react-native-flatlist-slider';
import tw from 'twrnc';

const Getstarted = (props) => {
  const {
    navigation,
    values,
    errors,
    handleChange,
    handleSubmit,
  } = props;

  const [number, setNumber] = useState(false);
  const [selectedButton, setSelectedButton] = useState(null);

  const handleButtonPress = (buttonType) => {

    setSelectedButton(buttonType);
    setTimeout(() => {
      if (buttonType === 'register') {
        props.navigation.navigate('Registration'); // Navigate to the registration screen
      } else {
        props.navigation.navigate('Login'); // Navigate to the login screen
        //props.navigation.navigate('Documentverification');
      }

    }, 100);
  };

  const [panelProps, setPanelProps] = useState({
    fullWidth: true,
    openLarge: true,
    //onlySmall:true,
    showCloseButton: true,
    closeOnTouchOutside: true,
    onClose: () => closePanel(),
    onPressCloseButton: () => closePanel(),
    // ...or any prop you want
  });
  const [isPanelActive, setIsPanelActive] = useState(false);

  const [isaction, setisaction] = useState(true);

  const openPanel = () => {

    setIsPanelActive(true);
    setisaction(false);
  };

  const closePanel = () => {
    setIsPanelActive(false);
    setisaction(true);

  };


  return (
    // <KeyboardAvoidingView behavior={Platform.OS === "ios" && "padding"} style={styles.root}>

    // <ImageBackground source={ImageIcons.stock} style={tw`flex-1 opacity-90`}>
    <View style={tw`flex-1 bg-black `}>
      <Image
        style={tw`ml-7 mt-25`}
        source={ImageIcons.stock} />

      <View style={tw`flex-1  bg-black mt-10 opacity-90`}>
        <View style={tw`flex flex-col`}>

          <View><Text style={tw`text-4xl text-white mx-auto  mt-3 font-bold`}>Get started with Trade Forex!!</Text></View>

        </View>
        <View>
          <TouchableOpacity
            style={tw`h-13 w-76 mt-15 mb-5 mx-auto items-center justify-center rounded-[3] p-1 ${selectedButton === 'register' ? 'bg-[#E0F64B]' : 'bg-black border-4 border-[#E0F64B] '
              }`}
            onPress={() => handleButtonPress('register')}
            activeOpacity={0.7}
          >
            <Text style={tw`text-[4.5] ${selectedButton === 'register' ? 'text-black' : 'text-white'}`}>
              Register new account
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={tw`h-13 w-76 mt-4 mb-5 mx-auto items-center justify-center rounded-[3] p-1 ${selectedButton === 'login' ? 'bg-[#E0F64B]' : 'bg-black border-4 border-[#E0F64B]'
              }`}
            onPress={() => handleButtonPress('login')}
            activeOpacity={0.7}
          >
            <Text style={tw`text-[4.5] ${selectedButton === 'login' ? 'text-black' : 'text-white'}`}>
              Login to existing account
            </Text>
          </TouchableOpacity>
        </View>


      </View>
    </View>

    //  </ImageBackground>

    // <Loader />
    // </KeyboardAvoidingView>
  )
}

export default Getstarted;
