import React, { useRef, useEffect, useState } from 'react';
import { View, Image, SafeAreaView, ImageBackground, Linking, Button, TouchableOpacity, ScrollView, Alert, Animated, StatusBar, KeyboardAvoidingView, Platform, Keyboard, Text, TextInput } from 'react-native';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common';
import ImageIcons from '../../common/ImageIcons';
import { useDispatch } from 'react-redux';
import tw from 'twrnc';
import branch from 'react-native-branch';
import { requestMultiplePermisisons } from '../../services/permission';
import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';
import DropDownPicker from 'react-native-dropdown-picker';
import { RadioButton, Provider, Portal} from 'react-native-paper';
import ImagePicker from 'react-native-image-crop-picker';


const Documentverification = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    const dispatch = useDispatch();
    const itemget = props?.route?.params?.response
    //Reference
    const [documentselfie, setDocumentselfie] = useState('userselfi');
    const [documentvalue, setDocumentvalue] = useState('');
    const [keyboardStatus, setKeyboardStatus] = useState(0);
    const [buttontext, setButtontext] = useState('Continue')
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(null);
    const [wayToContact, setWayToContact] = useState("India");
    const [idcardImage, setIdcardImage] = useState('');
    const [userPicture, setUserPicture] = useState('');
    const [wayToContactList, setWayToContactList] = useState([
        {
            label: "India",
            value: "India"
        },
        {
            label: "United States of America",
            value: "USA"
        },
        {
            label: "UAE",
            value: "UAE"
        },
        {
            label: "Indonesia",
            value: "Indonesia"
        },
        {
            label: "Canada",
            value: "Canada"
        },
        {
            label: "China",
            value: "China"
        }
    ]);
   
    const handleOTPSubmit = () => {
        if (value=='' || value==null) {
            Alert.alert(CommonStrings.AppName, "Please select Country")
        }else{
            if(keyboardStatus>0){
                setButtontext('Submit')
            }else {
                
                setButtontext('Continue')
            }
            setKeyboardStatus(keyboardStatus+1)
        }
    }

    const handleOTPSubmit1 = () => {
        const formData = new FormData();
        formData.append("userId", itemget?._id);
        formData.append("image", userPicture);
        formData.append("idcardtypeval", '');
        props.submitverificationData2(formData, props.navigation);
    }

    const handleOTPSubmit2 = (type,cardimage) => {
        const formData = new FormData();
        formData.append("userId", itemget?._id);
        formData.append("country", value);
        formData.append("image", cardimage);
        formData.append("idcardtypeval", type);
        props.submitverificationData(formData, props.navigation);
    }
    
    const onSelectImage = (value) => {
        setDocumentvalue(value);
        ImagePicker.openPicker({
            width: 400,
            cropping: true,
            mediaType: 'photo',
            compressImageQuality: 0.5,
            height: 400,
        }).then(image => {
            if (image?.path) {
                let fileName = image?.path?.split('/').pop();
                let mimeType = image?.path?.split('.').pop();
                let file = {
                    'uri': image?.path,
                    'type': `image/${mimeType}`,
                    'name': fileName
                }
                setIdcardImage(file); 
                handleOTPSubmit2(value,file);
            }
        }).catch((error) => {
            
        });
    }
    
    const onSelectCamera = (value) => {
        setDocumentselfie(value);
        ImagePicker.openCamera({
            width: 400,
            cropping: true,
            mediaType: 'photo',
            compressImageQuality: 0.5,
            height: 400,
        }).then(image => {
            if (image?.path) {
                let fileName = image?.path?.split('/').pop();
                let mimeType = image?.path?.split('.').pop();
                let file = {
                    'uri': image?.path,
                    'type': `image/${mimeType}`,
                    'name': fileName
                }
                setUserPicture(file); 
            }
        }).catch((error) => {
            
        });
    }

    const handleBack = () => {
        props.navigation?.goBack();
    }
    return (
        <View style={[tw`bg-[#FAFAFA]`,{flex: 1}]}>
           {keyboardStatus<3 ?
            <View style={[tw`bg-[#FAFAFA]`,{flex: 1}]}>
                {keyboardStatus==0 &&
                    <View style={tw`justify-center mx-auto p-5`}>
                        <View style={tw`flex-row`}>
                            <TouchableOpacity onPress={handleBack}>
                                <Image source={ImageIcons.backarrow} style={tw`h-6 w-3`}  />
                            </TouchableOpacity>
                            <Text style={tw`mx-auto pb-3 text-lg`}><Text style={tw`font-bold`}>1</Text> of 3</Text>
                        </View>
                       <Image source={ImageIcons.onesel} style={tw`rounded-full`} />
                    </View>
                }
                {keyboardStatus==1 &&
                    <View style={tw`justify-center mx-auto p-5`}>
                      <View style={tw`flex-row`}>
                            <TouchableOpacity onPress={handleBack}>
                                <Image source={ImageIcons.backarrow} style={tw`h-6 w-3`}  />
                            </TouchableOpacity>
                            <Text style={tw`mx-auto pb-3 text-lg`}><Text style={tw`font-bold`}>2</Text> of 3</Text>
                        </View>
                      <Image source={ImageIcons.twosel} style={tw`rounded-full`} />
                    </View>
                }
                {keyboardStatus==2 &&
                    <View style={tw`justify-center mx-auto p-5`}>
                      <View style={tw`flex-row`}>
                            <TouchableOpacity onPress={handleBack}>
                                <Image source={ImageIcons.backarrow} style={tw`h-6 w-3`}  />
                            </TouchableOpacity>
                            <Text style={tw`mx-auto pb-3 text-lg`}><Text style={tw`font-bold`}>3</Text> of 3</Text>
                        </View>
                      <Image source={ImageIcons.threesel} style={tw`rounded-full`} />
                    </View>
                }
                <View style={tw`mt-5 `}>
                    <View><Text style={tw`text-black text-3xl font-bold mx-auto`}> Document Verification  </Text></View>
                    <View><Text style={tw` text-[#848484] text-sm mx-auto`}>Document Issuing Country/Region</Text></View>
                </View>
               
                <Text style={tw`text-black ml-5 mt-10` }>Country</Text>
                {keyboardStatus==0 ?
                <View
                    style={{
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingHorizontal: 15,
                        height:100
                    }}>
                    
                    <DropDownPicker
                        open={open}
                        value={value}
                        items={wayToContactList}
                        setOpen={setOpen}
                        setValue={setValue}
                        setItems={wayToContactList}
                        placeholder={'Choose a country'}
                    />
                </View>
                :
                    <View
                    style={{
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingHorizontal: 15,
                        height:100
                    }}>
                    <DropDownPicker
                        open={false}
                        value={value}
                        items={wayToContactList}
                        setValue={setValue}
                        setItems={wayToContactList}
                        placeholder={'Choose a country'}
                    />
                </View>
                }

                {keyboardStatus>0 &&
                    <View>
                        <Text style={tw`text-black ml-5 mt-1` }>Document Type</Text>
                        <RadioButton.Group onValueChange={value => onSelectImage(value)} value={documentvalue}>
                          <View style={tw`ml-5 mt-5 border-2 border-zinc-300 rounded-md  mb-2 justify-between flex-row mr-5 ` }>
                            <View style={tw`flex-row`}>
                                <View style={tw`border-2 rounded-full border-gray-300    p-1 m-1`}>
                                    <Image source={ImageIcons.Idcardpath} style={tw`h-5 w-5`} />
                                </View>
                                <Text style={{padding:5, paddingTop:8}}>ID Card</Text>
                            </View>
                            <RadioButton value="idcard" />
                          </View>
                          <View style={tw`ml-5 mt-2 border-2 border-zinc-300 rounded-md  mb-2 justify-between flex-row mr-5 ` }>
                            <View style={tw`flex-row`}>
                                <View style={tw`border-2 rounded-full border-gray-300    p-1 m-1`}>
                                    <Image source={ImageIcons.Passportpath} style={tw`h-5 w-5`} />
                                </View>
                                <Text style={{padding:5, paddingTop:8}}>Passport</Text>
                            </View>
                            <RadioButton value="passport" />
                          </View>
                          <View style={tw`ml-5 mt-2 border-2 border-zinc-300 rounded-md  mb-2 justify-between flex-row mr-5 ` }>
                            <View style={tw`flex-row`}>
                                <View style={tw`border-2 rounded-full border-gray-300    p-1 m-1`}>
                                    <Image source={ImageIcons.IconSelfiepath} style={tw`h-5 w-5`} />
                                </View>
                                <Text style={{padding:5, paddingTop:8}}>Driver’s License</Text>
                            </View>
                            <RadioButton value="license" />
                          </View>
                          
                        </RadioButton.Group>  
                    </View>
                }

                {keyboardStatus>1 &&
                    <View>
                        <Text style={tw`text-black ml-5 mt-5` }>Selfie</Text>
                        <RadioButton.Group onValueChange={value => onSelectCamera() } value={documentselfie}>
                          <View style={tw`ml-5 mt-5 border-2 border-zinc-300 rounded-md  mb-2 justify-between flex-row mr-5 ` }>
                            <View style={tw`flex-row`}>
                                <View style={tw`border-2 rounded-full border-gray-300    p-1 m-1`}>
                                    <Image source={ImageIcons.Idcardpath} style={tw`h-5 w-5`} />
                                </View>
                                <Text style={{padding:5, paddingTop:8}}>Take your selfie</Text>
                            </View>
                            <RadioButton value="userselfi" />
                          </View>
                        </RadioButton.Group>  
                    </View>
                }
            
                <View style={{width: '100%',height: 90, justifyContent: 'center',alignItems: 'center',position: 'absolute', bottom: 0}}>
                    <TouchableOpacity onPress={handleOTPSubmit}  style={tw` h-13 w-86 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1 `} >
                        <Text style={tw`text-black w-90 text-[4.5] px-35  `}>{buttontext}</Text>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={handleBack}  style={tw` h-13 w-76 mx-auto items-center  justify-center rounded-[2] p-1 `} >
                        <Text style={tw`text-[#848484] w-90 text-[4.5] px-35  `}>Go Back</Text>
                    </TouchableOpacity>
                </View>
            </View>
            :
                <View style={[tw`bg-[#FAFAFA]`,{flex: 1,alignItems: 'center',justifyContent: 'center'}]}>
                    <View>
                        <Image source={ImageIcons.Iconpath} style={tw`h-40 w-40 mx-auto`} />
                        <Text style={tw`text-black text-center ml-5 mr-5 mt-5 text-lg font-bold` }>Thank You</Text>
                        <Text style={tw`text-black text-center ml-5 mr-5 mt-5` }>Thank you for submitting KYC, Once approved you will be notified by email and notification. Till that look towarsd the dashboard</Text>

                    </View>
                    <View style={{width: '100%',height: 90, justifyContent: 'center',alignItems: 'center',position: 'absolute', bottom: 0}}>
                        <TouchableOpacity onPress={handleOTPSubmit1}  style={tw` h-13 mx-auto w-80 bg-[#E0F64B] items-center  justify-center rounded-[2] p-1 `} >
                            <Text style={tw`text-black w-100 text-[4.5] text-center`}>Go to Dashboard</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            }
        </View>
    )
}

const formikEnhancer = withFormik({

});


export default formikEnhancer(Documentverification);