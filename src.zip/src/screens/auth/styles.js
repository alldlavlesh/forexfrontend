import React from 'react';
import { StyleSheet } from 'react-native';
import { Colors, Fonts } from '../../common';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

const styles = StyleSheet.create({
    registrationRoot: {
        flex: 1,
        justifyContent: 'center',
    },
    registrationRootreg:{
        flex:1,
        //marginTop:'15%'
    },
    heading: {
        // paddingVertical: '2%',
        alignItems: 'center',
        marginTop: hp('10%'),
        // paddingBottom:hp('5%')
    },
    headingText: {
        textAlign: 'center',
        fontSize: 24,
        color: Colors.WHITE,
        fontFamily: Fonts.RalewayExtraBold,
        paddingHorizontal:'20%'
    },
    phoneTitle: {
        color: Colors.WHITE,
        paddingVertical: 5,
        fontSize: 16,
        fontFamily: Fonts.RalewayExtraBold
    },
    phoneContainer: {
        width: '100%',
        height: 50,
        backgroundColor: Colors.LIGHT_BLACK,
        borderRadius: 10,
        color: Colors.WHITE,
    },
    phoneTextContainer: {
        height: 50,
        backgroundColor: Colors.LIGHT_BLACK,
        color: Colors.WHITE,
        borderTopRightRadius: 10,
        borderBottomRightRadius: 10
    },
    phoneInput: {
        height: 50,
        backgroundColor: Colors.LIGHT_BLACK,
        color: Colors.WHITE,
    },
    logoImg: {
        // resizeMode: 'contain',
        width: wp('70%'),
        height: wp('60%'),
    },
    loginSubtitleContainer: {
        // paddingHorizontal: 30,
        marginTop: 10,
        width: wp('60%')
    },
    loginSubtitleText: {
        textAlign: 'center',
        color: Colors.WHITE,
        fontSize: 16
    },
    countdown: {
        marginTop: '5%',
        justifyContent: 'center',
        width: '100%',
        alignItems: 'center'
    },
    rememberMeContainer: {
        width:wp('95%'),
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: '8%',
        paddingHorizontal:'5%',
    },
    rememberMeText: {
        color: Colors.WHITE,
        fontSize: 16,
        fontFamily: Fonts.RalewayExtraBold,
        paddingLeft:20
    },
    privacyText: {
        color: Colors.WHITE,
        fontSize: 14,
        paddingLeft:10
    },
    linkText:{
        color:Colors.GREEN,
        textDecorationLine:'underline'
    },
    matterText:{
        fontFamily:Fonts.HomepageBaukastenBold,
        fontSize:20,
        color:Colors.GREEN,
        textAlign:'right',
        marginTop:-50,
        width: wp('60%')
    },
    subtitleLogoText:{
        fontFamily:Fonts.HomepageBaukastenBold,
        fontSize:20,
        textAlign:'center',
        width:'70%',
        color:Colors.GREEN,
        position:'relative',
        top:-30
    },
    subtitleSubText:{
        fontFamily:Fonts.HomepageBaukastenBold,
        fontSize:16,
        textAlign:'center',
        width:'70%',
        color:Colors.WHITE,
        position:'relative',
        top:-20
    },
    sortModal: {
        backgroundColor: 'white',
        // alignItems: 'center',
        borderRadius: 10,
        padding: 20,
        height: 240,
    },
    sortText: {
        fontSize: 16,
        margin: 5
    },
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        width: '90%', // Adjust the width as needed
        marginTop: 10,
      },
      checkboxContainer: {
        width: '10%',
        alignItems: 'center',
      },
    
    checkbox: {
        width: 20,
        height: 20,
        borderWidth: 4,
        borderRadius: 12,
        borderColor: '#171717',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: -30,
        marginTop: -10,
      },
      checkedCheckbox: {
        backgroundColor: 'black',
      },
      checkmark: {
        width: 12, 
        height: 12, 
        resizeMode: 'contain', 
      },
      textContainer: {
        width: '90%',
      },
      text: {
        color: '#576284',
        fontWeight: 'bold',
        fontSize: 12,
        marginLeft:-8,
        
      },
    
    
    
   
})

export default styles;