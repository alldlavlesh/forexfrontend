import React, { useRef, useState } from 'react';
import { Text, View, ImageBackground, ScrollView, Alert, StatusBar, KeyboardAvoidingView, Platform,Keyboard} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common'
import ImageIcons from '../../common/ImageIcons'
import InputField from '../../components/forms/inputField';
import { RoundedButton } from '../../components/forms/button';
import { phoneRegExp } from '../../services/helper';
import DropdownField from '../../components/dropdown/DropDownMenu';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import Loader from '../../components/modals/Loader';

const StoreOwner = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
    } = props;

    //Reference
    const emailRef = useRef();
    const phoneRef = useRef();
    const bisinessnameRef = useRef();
    const fullnameRef = useRef();

    // Local states
    const [wayToContact, setWayToContact] = useState("Phone");
    const [wayToContactList, setWayToContactList] = useState([
        {
            label: "Phone",
            value: "Phone"
        },
        {
            label: "Email",
            value: "Email"
        }
    ]);

    // Vendor request submission
    const handleSendRequestSubmit = async () => {
        Keyboard.dismiss();
        if (errors.businessName) {
            Alert.alert(CommonStrings.AppName, errors.businessName)
        } else if (errors.fullName) {
            Alert.alert(CommonStrings.AppName, errors.fullName)
        } else if (errors.email) {
            Alert.alert(CommonStrings.AppName, errors.email)
        } else if (errors.phoneNumber) {
            Alert.alert(CommonStrings.AppName, errors.phoneNumber)
        } else if (!wayToContact || wayToContact === null || wayToContact === "") {
            Alert.alert(CommonStrings.AppName, "Please select way to be contacted.")
        } else {
            let request = {
                "businessName": values.businessName,
                "fullName": values.fullName,
                "email": values.email,
                "phone": values.phoneNumber,
                "countryCode": values.countryCode,
                "contactType": wayToContact,
                "role": "vendor"
            }
            props.signup(request, props.navigation, "vendor");
        }
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            style={styles.registrationRoot}>
            <StatusBar backgroundColor={Colors.BLACK} barStyle="light-content" translucent={true} />
            <ImageBackground
                style={{ flex: 1 }}
                source={ImageIcons.registrationBgIcon}
                imageStyle={{ resizeMode: 'cover' }}
            >
                <LinearGradient
                    colors={[Colors.BLACK, 'rgba(0,0,0,0.7)']}
                    start={{ x: 0, y: 0 }} end={{ x: 0, y: 2 }}
                    style={{ flex: 1 }}>
                    <ScrollView  keyboardShouldPersistTaps="handled" persistentScrollbar={true}>
                        <View style={styles.heading}>
                            <Text style={styles.headingText}>Contact a WallPon Consultant</Text>
                        </View>
                        <View style={{ flex: 1, marginTop: '2%', paddingBottom: '5%' }}>
                            <InputField
                                id="businessName"
                                title="Business Name"
                                value={values.businessName}
                                onChangeText={handleChange('businessName')}
                                selectionColor="white"
                                reference={bisinessnameRef}
                                onSubmitEditing={() => fullnameRef?.current?.focus()}
                                returnKeyType="next"
                            />
                            <InputField
                                id="fullName"
                                title="Full Name"
                                value={values.fullName}
                                onChangeText={handleChange('fullName')}
                                selectionColor="white"
                                reference={fullnameRef}
                                onSubmitEditing={() => emailRef?.current?.focus()}
                                returnKeyType="next"
                            />
                            <InputField
                                id="email"
                                title="Email Address"
                                value={values.email}
                                onChangeText={handleChange('email')}
                                keyboardType="email-address"
                                selectionColor="white"
                                reference={emailRef}
                                onSubmitEditing={() => phoneRef?.current?.focus()}
                                returnKeyType="next"
                            />
                            <PhoneMaskInput
                                id="salesmanPhone"
                                defaultValue={values.phoneNumber}
                                placeholder=""
                                defaultCode="US"
                                layout="second"
                                onCountryChange={handleChange('countryCode')}
                                onChangePhone={handleChange('phoneNumber')}
                                theme="black"
                                reference={phoneRef}
                            />
                            <DropdownField
                                data={wayToContactList}
                                id="businessType"
                                title="How would you like to be contacted?"
                                iconTintColor={Colors.BLACK}
                                theme="black"
                                selectedValue={wayToContact}
                                onValueChange={(itemValue) =>
                                    setWayToContact(itemValue)
                                }
                            />
                            <View style={{ paddingHorizontal: '20%', marginTop: '10%' }}>
                                <RoundedButton
                                    text="SEND REQUEST"
                                    onPress={() => handleSendRequestSubmit()}
                                />
                            </View>
                        </View>
                    </ScrollView>
                </LinearGradient>
            </ImageBackground>
            {props?.vendorRequestLoader && <Loader isVisible={props?.vendorRequestLoader} />}
        </KeyboardAvoidingView>
    )
}


const formikEnhancer = withFormik({
    validateOnMount: true,
    validationSchema: Yup.object().shape({
        fullName: Yup.string().required('Please enter full name'),
        email: Yup.string().required('Please enter email address').email('Please enter a valid email address'),
        phoneNumber: Yup.string().required('Please enter phone number').matches(phoneRegExp, 'Phone number is not valid'),
        businessName: Yup.string().required('Please enter business name'),
        wayToContact: Yup.string(),
        countryCode: Yup.string().required()
    }),
    mapPropsToValues: (props) => {
        return {
            fullName: '',
            email: '',
            phoneNumber: '',
            businessName: '',
            wayToContact: '',
            countryCode: '+1'
        };
    },
    handleSubmit: (payload, { props }) => {
        props.navigation.goBack();
    },
});


export default formikEnhancer(StoreOwner);