import Login from './Login';
import Registration from './Registration';
import Verification from './Verification';
import OTPVerification from './OTPVerification';
import WelcomeBack from './WelcomeBack';
import Landing from './Landing';
import Getstarted from './Getstarted';
// import Slideshow from './Slideshow';
import StoreOwner from './StoreOwner';
import ForgetPassword from './ForgetPassword';
import VerifyPassword from './VerifyPassword';
import ResetPassword from './ResetPassword';
import Searchlocation from './Searchlocation';
import SetupPin from './SetupPin';
import Documentverification from './Documentverification';

export {
    Login,
    Registration,
    Verification,
    Documentverification,
    SetupPin,
    OTPVerification,
    WelcomeBack,
    StoreOwner,
    Landing,
    Getstarted,
    // Slideshow,
    ForgetPassword,
    VerifyPassword,
    ResetPassword,
    Searchlocation
}