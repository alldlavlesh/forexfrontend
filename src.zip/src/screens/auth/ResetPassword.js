import React, { useRef, useState } from 'react';
import { Text, Image, View, ImageBackground, KeyboardAvoidingView, ScrollView, Alert, Platform, TextInput, TouchableOpacity } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common'
import ImageIcons from '../../common/ImageIcons'
import InputField from '../../components/forms/inputField';
import { RoundedButton } from '../../components/forms/button';
import { passwordValidationRegx } from '../../services/helper';
import Loader from '../../components/modals/Loader';
import select from '../../common/select.png'
import tw from 'twrnc';

const ResetPassword = (props) => {
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
    } = props;
    // Local states
    const [isShowPassword, setIsShowPassword] = useState(true);
    const [isShowPassword1, setIsShowPassword1] = useState(true);
    const [isShowConfirmPassword, setIsShowConfirmPassword] = useState(true);
    const [password, setPassword] = useState('')
    const [confirmpassword, setConfirmPassword] = useState('')
    const [otp, setOtp] = useState('')
    const [validPass, setValidPass] = useState(false);
    const [confirmPass, setConfirmPass] = useState(false);
    const [validconfirmPassword, setValidConfirmPassword] = useState(false);

    const userId = props?.signupCredentials?._id

    // Reset password request submission
    const handleResetPasswordSubmit = () => {
        if (otp == "") {
            Alert.alert(CommonStrings.AppName, 'Please enter OTP')
        } else if (password == "") {
            Alert.alert(CommonStrings.AppName, 'password required')

        } else if (!validPass) {
            Alert.alert(CommonStrings.AppName, "Enter valid password. It should be Combination of  Letters & Numbers minimum 8 characters")
        }
        else if (confirmpassword == "") {
            Alert.alert(CommonStrings.AppName, "confirm password required")
        } else if (password !== confirmpassword) {
            Alert.alert(CommonStrings.AppName, "Password does not match.")
        } else {
            let request = {
                "otp": otp,
                "password": password,

            }
            props?.resetPassword(request, userId, props.navigation)



        }

    }

    const handlePassswordChange = (value) => {

        const passwordRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})")
        setPassword(value)
        // alert('Password must be at least 8 characters long and contain at least one letter and one number.');
        setValidPass(passwordRegex.test(value));
    }
    const handleConfirmPassswordChange = (value) => {

        const passwordRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})")
        setConfirmPassword(value)
        // alert('Password must be at least 8 characters long and contain at least one letter and one number.');
        setConfirmPass(passwordRegex.test(value));
    }
    const handleOtpSubmit = (value) => {
        // Define the regex pattern for a 4-digit OTP
        const otpRegex = /^\d{4}$/;
        setOtp(value)
        setValidConfirmPassword(otpRegex.test(value));


    };

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>


            <ScrollView style={tw`bg-[#fff]`}>

                <View style={tw`mt-20 mb-15 `}>
                    <View><Text style={tw`text-black text-3xl font-bold mx-auto`}> Reset Password </Text></View>
                   
                </View>

                <View>
                    {/* <InputField
                        id="password"
                        title="Password"
                        value={values.password}
                        onChangeText={handleChange('password')}
                        secureTextEntry={isShowPassword}
                        rightIcon={isShowPassword ? ImageIcons.eyeIconHide : ImageIcons.eyeIcon}
                        passwordToogle={() => setIsShowPassword(!isShowPassword)}
                    />
                    <InputField
                        id="confirmPassword"
                        title="Confirm Password"
                        value={values.confirmPassword}
                        onChangeText={handleChange('confirmPassword')}
                        secureTextEntry={isShowConfirmPassword}
                        rightIcon={isShowConfirmPassword ? ImageIcons.eyeIconHide : ImageIcons.eyeIcon}
                        passwordToogle={() => setIsShowConfirmPassword(!isShowConfirmPassword)}
                    />
                    <View style={{ paddingHorizontal: '25%', marginTop: '10%' }}>
                        <RoundedButton
                            text="RESET"
                            onPress={() => handleResetPasswordSubmit()}
                        />
                    </View> */}
                    <View style={tw`relative mt-10`}>
                    <Text style={tw`text-black ml-5 mt-5`}>OTP</Text>
                        <TextInput
                            placeholder="OTP"
                            style={tw`mx-5  bg-[#ffffff] text-black border border-[#828282] rounded-2 h-12 mt-3 pl-8`}
                            placeholderTextColor={'gray'}
                            keyboardType="numeric"
                            maxLength={4}
                            value={otp}
                            onChangeText={handleOtpSubmit}
                            selectionColor={'#C20A33'}
                        />
                       

                    </View>
                    <View style={tw`relative`}>
                    <Text style={tw`text-black ml-5 mt-4`}>NEW PASSWORD</Text>
                        <TextInput
                          style={tw`mx-5  bg-[#ffffff] text-black border border-[#828282] rounded-2 h-12 mt-3 pl-8`}
                            // value={values.email}
                            type='text'
                            placeholder={'New Password'}
                            placeholderTextColor={'gray'}
                            value={password}
                            onChangeText={handlePassswordChange}
                            secureTextEntry={isShowPassword}
                            password={true}
                            selectionColor={'#C20A33'}
                        />
                        <TouchableOpacity style={tw`absolute right-17 bottom-4	 `} onPress={() => setIsShowPassword(!isShowPassword)}>
                            {isShowPassword ?
                                <Image source={ImageIcons.eyeIconHide} style={tw`w-5 h-5`} />
                                :
                                <Image source={ImageIcons.eyeIcon} style={tw`w-5 h-5`} />
                            }

                        </TouchableOpacity>
                        {/* {validPass &&
                            <>
                                <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                    end={{ x: 1.0, y: 0.1 }}
                                    locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3.5]  absolute top-1/2 transform -translate-y-1/2 right-14 mt--2 `}
                                >
                                    <View style={tw`flex-row `}>

                                        <Image
                                            source={select}
                                            style={[tw`h-7 w-7  `, { tintColor: 'white' }]}

                                        >
                                        </Image>
                                    </View>

                                </LinearGradient>


                            </>

                        } */}
                    </View>
                    <View style={tw`relative`}>
                    <Text style={tw`text-black ml-5 mt-4`}>CONFIRM PASSWORD</Text>
                        <TextInput
                            style={tw`mx-5  bg-[#ffffff] text-black border border-[#828282] rounded-2 h-12 mt-3 pl-8`}
                            // value={values.email}
                            type='text'
                            placeholder={'Confirm Password'}
                            placeholderTextColor={'gray'}
                            value={confirmpassword}
                            onChangeText={handleConfirmPassswordChange}
                            secureTextEntry={isShowPassword1}
                            password={true}
                            selectionColor={'#C20A33'}
                        />
                        <TouchableOpacity style={tw`absolute right-17 bottom-4 `} onPress={() => setIsShowPassword1(!isShowPassword1)}>
                            {isShowPassword1 ?
                                <Image source={ImageIcons.eyeIconHide} style={tw`w-5 h-5`} />
                                :
                                <Image source={ImageIcons.eyeIcon} style={tw`w-5 h-5`} />
                            }

                        </TouchableOpacity>
                        {/* {confirmPass &&
                            <>
                                <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                    end={{ x: 1.0, y: 0.1 }}
                                    locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3.5]  absolute top-1/2 transform -translate-y-1/2 right-14 mt--2 `}
                                >
                                    <View style={tw`flex-row `}>

                                        <Image
                                            source={select}
                                            style={[tw`h-7 w-7  `, { tintColor: 'white' }]}

                                        >
                                        </Image>
                                    </View>

                                </LinearGradient>


                            </>

                        } */}
                    </View>
                </View>
                <View>
                    {/* <RoundedButton
                                    text="SEND"
                                    onPress={() => handleSubmitForgot()}
                                /> */}
                    <View style={tw` mt-35 `}>
                        <TouchableOpacity onPress={() => handleResetPasswordSubmit()} style={tw` h-13 w-76 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1 `} >
                            <Text style={tw`text-black w-86 text-[4.5] px-34  `}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                    {/* <TouchableOpacity onPress={() => handleResetPasswordSubmit()}>
                        <View style={tw`w-11/12 flex-row mt-15 justify-end items-center`}>
                            <Text style={tw`font-bold text-lg `}>Okay</Text>
                            <View style={tw`h-10 w-10 rounded-full bg-[#BD0B30] ml-2`}></View>
                            <Image source={ImageIcons.arrow_login} style={tw`h-4   absolute mt-3 right-3 w-5 `} />

                        </View>
                    </TouchableOpacity> */}
                </View>
            </ScrollView>
            <Loader isVisible={props.resetPasswordLoader} />

        </KeyboardAvoidingView >

    )
}


const formikEnhancer = withFormik({
    validateOnMount: true,
    validationSchema: Yup.object().shape({
        password: Yup.string().required("Password must be minimum of 8 character").min(8).matches(passwordValidationRegx, "Password must include at least 1 number, 1 character, 1 capital letter"),
        confirmPassword: Yup.string().required('Please enter confirm password'),
    }),
    mapPropsToValues: (props) => {
        return {
            password: '',
            confirmPassword: ''
        };
    },
    handleSubmit: (payload, { props }) => {

    },
});

export default formikEnhancer(ResetPassword);