import React from 'react';
import { StyleSheet } from 'react-native';
import { Pagination, PaginationProps } from '../../components/react-native-swiper-flatlist';
const styles = StyleSheet.create({
  paginationContainer: {
    top: 0,
  },
  pagination: {
    borderRadius: 10,
    height:10,
    margin:10
  },
});

export const CustomPagination = (props: JSX.IntrinsicAttributes & PaginationProps) => {
  return (
    <Pagination
      {...props}
      paginationStyle={styles.paginationContainer}
      paginationStyleItem={styles.pagination}
      paginationDefaultColor="gray"
      paginationActiveColor="#FF3A79"
    />
  );
};
