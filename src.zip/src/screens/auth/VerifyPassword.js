import React, { useEffect, useRef, useState } from 'react';
import { Text, Image, View, ImageBackground, TouchableOpacity, BackHandler, Dimensions, ScrollView, Alert, StatusBar, KeyboardAvoidingView, Platform } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import CountDown from 'react-native-countdown-component';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common'
import ImageIcons from '../../common/ImageIcons'
import InputField from '../../components/forms/inputField';
import { RoundedButton } from '../../components/forms/button';
import Loader from '../../components/modals/Loader';
import { useDispatch } from 'react-redux';
import { SET_DEFAULT_AUTH_SCREEN } from '../../redux/actions/ActionTypes';
import { RadioButton, Provider, Portal, Button, } from 'react-native-paper';
import Modal from 'react-native-modal';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;

const VerifyPassword = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
    } = props;

    //Redux methods
    const dispatch = useDispatch();
    //References
    const countdownRef = useRef();
    const phoneRef = useRef();
    // Local states
    const [countdown, setCountdown] = useState(true);
    const [phoneNumber, setphoneNumber] = useState();
    const [countryCode, setcountryCoder] = useState();

    const [modalvisible, setmodalVisible] = React.useState(false);
    const [submitted, setSubmitted] = React.useState(false);

    // Otp request submission
    const handleOTPSubmit = () => {
        if (errors.otp) {
            Alert.alert(CommonStrings.AppName, errors.otp)
        } else {
            let { signupCredentials, loginCredentials } = props;
            let isForgetPassword = props && props.route && props.route.params || false;
            let request = {
                "userId": signupCredentials?._id || loginCredentials?.userId,
                "otp": Number(values.otp)  // default opt:  6364
            }
            props.verifyOtpForgotPassword(request, props.navigation, isForgetPassword);
        }
    }

    const handlechangephoneno = () => {
        setSubmitted(true)
        if (errors.phoneNumber) {
            Alert.alert(CommonStrings.AppName, errors.phoneNumber)
        } else {
            let request = {
                "phone": values.phoneNumber,
                "countryCode": (values.countryCode) ? values.countryCode : '+1',
                "email": props.signupCredentials?.email,
                "roletype": "vendor"
            }
            setSubmitted(true)
            props.chnagemobileno(request, props.navigation);
        }
    }



    useEffect(() => {
        if (props?.route?.params?.isForgetPassword) {
            dispatch({ type: SET_DEFAULT_AUTH_SCREEN, payload: "ResetPassword" })
        }
    }, [props?.route?.params?.isForgetPassword])

    useEffect(() => {
        const backHandler = BackHandler.addEventListener(
            "hardwareBackPress",
            hardwareBackPress
        );
        return () => backHandler.remove();
    }, [])


    const containerStyle = { backgroundColor: 'white', padding: '2%', marginHorizontal: '5%', borderRadius: 10, paddingVertical: '3%' };

    const openmodal = () => {
        setmodalVisible(true)
    }

    const closemodal = () => {
        setmodalVisible(false)
    }

    // Hanlde hardware back
    const hardwareBackPress = () => {
        dispatch({ type: SET_DEFAULT_AUTH_SCREEN, payload: "Login" })
        BackHandler.exitApp()
    }

    // Resend opt request submission
    const handleResendOpt = () => {
            props.resendOtp() 
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            style={styles.registrationRoot}>
            <StatusBar backgroundColor={Colors.BLACK} barStyle="light-content" translucent={true} />
            <ImageBackground
                style={{ flex: 1 }}
                source={ImageIcons.registrationBgIcon}
                imageStyle={{ resizeMode: 'cover' }}
            >
                <LinearGradient
                    colors={[Colors.BLACK, 'rgba(0,0,0,0.7)']}
                    start={{ x: 0, y: 0 }} end={{ x: 0, y: 2 }}
                    style={{ flex: 1 }}>
                    <ScrollView persistentScrollbar={true} keyboardShouldPersistTaps="always">
                        <View style={styles.heading}>
                            <Text style={[styles.headingText, { marginTop: 20 }]}>OTP  Verification</Text>
                            <Text style={[styles.loginSubtitleText, { marginTop: 20, paddingHorizontal: 30 }]}>We have send you a One-time Password on your phone number.</Text>
                        </View>
                        <View style={{ flex: 1, marginTop: '5%', alignItems:'center', justifyContent:'center' }}>

                            
                            <View style={{ width: '50%', alignItems:'center', justifyContent:'center' }}>
                                <InputField
                                    id="otp"
                                    title="Enter OTP"
                                    value={values.otp}
                                    onChangeText={handleChange('otp')}
                                    keyboardType="numeric"
                                    secureTextEntry={true}
                                    textStyle={{ textAlign: 'center', marginBottom: 5, width: '50%' }}
                                    selectionColor="white"
                                />
                                <View style={{ width: 200, marginTop: 30 }}>
                                    <RoundedButton
                                        text="VERIFY"
                                        onPress={() => handleOTPSubmit()}
                                    />
                                </View>
                            </View>
                            

                            {/* <View style={styles.countdown}>
                                {countdown &&
                                    <CountDown
                                        ref={(ref) => countdownRef.current = ref}
                                        until={100}
                                        size={15}
                                        onFinish={() => setCountdown(false)}
                                        digitStyle={{ backgroundColor: 'transparent' }}
                                        digitTxtStyle={{ color: '#1CC625' }}
                                        timeToShow={['M', 'S']}
                                        timeLabels={{ m: 'MM', s: 'SS' }}
                                    />
                                }
                            </View> */}
                            <View style={{ paddingHorizontal: '5%',marginTop:'5%' }}>
                                <Text style={styles.loginSubtitleText}>Didn't receive the OTP Number?
                                    <Text style={{  color:'white', textDecorationLine: "underline", fontSize: 16, fontWeight: 'bold' }} onPress={() => handleResendOpt()}> Resend OTP</Text>
                                </Text>
                            </View>                            
                        </View>

                        {openmodal &&

                            <Provider>
                                <Portal>
                                    <Modal transparent={true} visible={modalvisible} style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', marginHorizontal: -20, marginVertical: -5 }} onDismiss={closemodal} contentContainerStyle={containerStyle}>
                                        <View style={{ marginTop: 40, position: 'absolute', textAlign: 'center', alignItems: 'center', top: '25%', left: 0, right: 0 }}>
                                            <View style={{ width: 330, borderRadius: 10, backgroundColor: '#f2f2f2', borderColor: '#999', borderWidth: 2 }}>
                                                <View style={{ width: deviceWidth / 1.35, backgroundColor: '#f2f2f2', padding: '5%', alignSelf: 'center', marginTop: '3%', borderRadius: 15, }}>
                                               
                                                    <PhoneMaskInput
                                                        id="vendorPhone"
                                                        defaultValue={values.phoneNumber}
                                                        placeholder="Mobile Number"
                                                        defaultCode={'US'}
                                                        theme="white"
                                                        layout="second"
                                                        onCountryChange={handleChange('countryCode')}
                                                        onChangePhone={handleChange('phoneNumber')}
                                                        reference={phoneRef}
                                                    // onSubmitEditing={() => emailRef?.current?.focus()}
                                                    />
                                                </View>
                                                <View style={{ marginHorizontal: "5%", marginBottom: 25 }}>
                                                    <TouchableOpacity onPress={() => { closemodal(), handlechangephoneno() }} style={{  backgroundColor: "#324ca8", borderRadius: 10, padding: 9, alignSelf: 'center' }}>
                                                        <Text style={{ color: '#FFFFFF' }}>Update & send OTP</Text>
                                                    </TouchableOpacity>
                                                </View>
                                            </View>
                                        </View>
                                    </Modal>
                                </Portal>
                            </Provider>
                        }
                    </ScrollView>

                    <Loader isVisible={props?.otpVerificationLoader} />
                </LinearGradient>
            </ImageBackground>
        </KeyboardAvoidingView>
    )
}


const formikEnhancer = withFormik({
    // validateOnMount: true,
    validationSchema: Yup.object().shape({
        otp: Yup.string().required('Please enter OTP')
    }),
    mapPropsToValues: (props) => {
        return {
            otp: '',
            countryCode: '+1'
        };
    },
    handleSubmit: (payload, { props }) => {

    },
});

export default formikEnhancer(VerifyPassword);