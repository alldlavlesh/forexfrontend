import React, { useRef, useState, useEffect } from 'react';
import { Text, View, ImageBackground, ScrollView, Keyboard, Alert, TouchableOpacity, TextInput, KeyboardAvoidingView, Image } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common'
import ImageIcons from '../../common/ImageIcons'
import { RoundedButton } from '../../components/forms/button';
import { phoneRegExp } from '../../services/helper';
import Loader from '../../components/modals/Loader';
import PhoneMaskInput from '../../components/forms/inputField/PhoneMaskInput';
import InputField from '../../components/forms/inputField';
import select from '../../common/select.png'
import tw from 'twrnc';
import CustomHeaderTab from '../../components/CustomHeaderTab';

const ForgetPassword = (props) => {

    const [email, setEmail] = useState();
    const [isValidEmail, setIsValidEmail] = useState(false);
    const [keyboardStatus, setKeyboardStatus] = useState(0);

    const emailRef = useRef();
    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
    } = props;

    // Submit forgot password 
    const handleForgetPasswordSubmit = () => {
        if (errors.phoneNumber) {
            Alert.alert(CommonStrings.AppName, errors.phoneNumber)
        } else {
            let request = {
                "phone": values.phoneNumber,
                "countryCode": values.countryCode
            }
            props.forgetPassword(request, props.navigation);
        }
    }

    useEffect(() => {
        const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
            setKeyboardStatus(1);
        });
        const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
            setKeyboardStatus(0);
        });

        return () => {
            showSubscription.remove();
            hideSubscription.remove();
        };
    }, []);

    const handleSubmitForgot = () => {
        let validationSchema = Yup.object().shape({
            email: Yup.string().required('Please enter email address').email('Please enter a valid email address')
        });
        validationSchema.validate({
            email: email
        }).catch(err => {
            if (err.errors[0]) {
                Alert.alert(CommonStrings.AppName, err.errors[0])
            }
        }).then(valid => {
            if (valid != undefined) {
                let request = {
                    "email": email,
                    // "role": 'ads'
                }
                props?.forgetPassword(request, props.navigation)
            }
        })
    }




    const handleemailChange = (text) => {
        setEmail(text)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        setIsValidEmail(emailRegex.test(text));
    }
    const handlePassswordChange = (text) => {
        setPassword(text)
    }



    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center bg-[#fff]`}>


            <View style={tw` flex-1 bg-[#fff]`}>
                {/* <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Withdraw Amount'} /> */}
            
                <ScrollView style={tw`flex-1 h-2/12`}>
                    <View style={tw`mt-20 mb-15 `}>
                    <Text style={tw`text-black text-3xl font-bold mx-auto`}> Forget  Password </Text>
                    </View>
                    
                    <View style={keyboardStatus == 1 ? tw` items-center mt-5` : tw` items-center`}>
                        <Text style={tw`text-black text-base text-center`}>Please enter your email. We will send you a One-time Password on this Email.</Text>
                    </View>
                    <View style={tw`relative`}>
                        {/* <InputField
                            myref={emailRef}
                            id="email"
                            title="Email Address"
                            value={email}
                            Theme='white'
                            onChangeText={(text) => setEmail(text)}
                            keyboardType="email-address"
                            editable={true}
                        //onSubmitEditing={() => setVisible(true)}
                        /> */}
                        <TextInput
                            style={tw`mx-5 bg-[#ffffff]  text-black border border-[#828282] rounded-2 h-12 mt-20 pl-8`}
                            value={email}
                            type='text'
                            placeholder={'Enter Email'}
                            placeholderTextColor={Colors.GREY}
                            // onChangeText={handleChange('email')}
                            onChangeText={handleemailChange}
                            keyboardType="email-address"
                            // reference={emailInputRef}
                            selectionColor="#C20A33"
                        // onSubmitEditing={() => passwordInputRef?.current?.focus()}


                        />
                        {/* {isValidEmail &&
                            <>



                                <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                    end={{ x: 1.0, y: 0.1 }}
                                    locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3.5]  absolute top-1/2 transform -translate-y-1/2 right-12 mt--10`}
                                >
                                    <View style={tw`flex-row `}>

                                        <Image
                                            source={select}
                                            style={[tw`h-7 w-7  `, { tintColor: 'white' }]}

                                        >
                                        </Image>
                                    </View>

                                </LinearGradient>


                            </>

                        } */}
                        <View style={tw`mt-20`}>
                            {/* <RoundedButton
                                    text="SEND"
                                    onPress={() => handleSubmitForgot()}
                                /> */}

                            <TouchableOpacity onPress={() => handleSubmitForgot()}>
                                <View style={keyboardStatus == 1 ? tw` h-13 w-76 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1` : tw` h-13 w-76 mx-auto bg-[#E0F64B] items-center  justify-center rounded-[2] p-1`}>
                                    <Text style={tw`text-black w-86 text-[4.5] px-37  `}>Send</Text>
                                    {/* <View style={tw`h-10 w-10 rounded-full bg-[#BD0B30] ml-2`}></View>
                                    <Image source={ImageIcons.arrow_login} style={tw`h-4   absolute mt-3 right-3 w-5 `} /> */}

                                </View>
                            </TouchableOpacity>
                        </View>
                    </View>
                </ScrollView>

            </View>
            {/* <Loader isVisible={props?.forgetPasswordLoader} /> */}


        </KeyboardAvoidingView>
    )
}


const formikEnhancer = withFormik({
    validateOnMount: true,
    validationSchema: Yup.object().shape({
        phoneNumber: Yup.string().required('Please enter phone number').matches(phoneRegExp, 'Phone number is not valid'),
        countryCode: Yup.string().required()
    }),
    mapPropsToValues: (props) => {
        return {
            phoneNumber: '',
            countryCode: '+1'
        };
    },
    handleSubmit: (payload, { props }) => {

    },
});

export default formikEnhancer(ForgetPassword);