import React, { useEffect, useRef, useState } from 'react';
import { Text, Image, View, Switch, ImageBackground, Dimensions, SafeAreaView, ScrollView, Alert, StatusBar, Animated, KeyboardAvoidingView, Platform, Keyboard, TouchableOpacity, Button, TextInput } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import CheckBox from '@react-native-community/checkbox';
import { withFormik } from 'formik';
import * as Yup from 'yup';
import styles from './styles';
import { Colors, CommonStrings } from '../../common'
import ImageIcons from '../../common/ImageIcons'
import select from '../../common/select.png'
// import arrowleft from '../../common/arrowleft.png'
import InputField from '../../components/forms/inputField';
import { RoundedButton } from '../../components/forms/button';
import Loader from '../../components/modals/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';
import { requestMultiplePermisisons } from '../../services/permission';
import { white } from 'react-native-paper/lib/typescript/styles/colors';
import tw from 'twrnc';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
// import { TextInput } from 'react-native-gesture-handler';
const Login = (props) => {

    const {
        navigation,
        values,
        errors,
        handleChange,
        handleSubmit,
        setFieldValue
    } = props;

    //Reference
    const emailInputRef = useRef();
    const passwordInputRef = useRef();

    const [isEnabled, setisEnabled] = React.useState(false);

    // Local states
    const [isShowPassword, setIsShowPassword] = useState(true);
    const [rememberMe, setRememberMe] = useState(false)
    const [refreshFiled, setRefreshFiled] = useState(false)
    const [deviceToken, setDeviceToken] = useState();
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [isValidEmail, setIsValidEmail] = useState(false);
    const [validPass, setValidPass] = useState(false);

    const [keyboardStatus, setKeyboardStatus] = useState(0);


    // Animation references
    const fadeAnim = useRef(new Animated.Value(0)).current
    const transformAnim = useRef(new Animated.Value(300)).current


    useEffect(async () => {
        animateLogo();
        const status = await requestMultiplePermisisons();
    }, [fadeAnim, transformAnim])

    useEffect(() => {
        checkRememberMe();
    }, [refreshFiled])

    useEffect(() => {
        requestUserPermission();
    }, [])

    useEffect(() => {
        const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
            setKeyboardStatus(1);
        });
        const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
            setKeyboardStatus(0);
        });

        return () => {
            showSubscription.remove();
            hideSubscription.remove();
        };
    }, []);


    // handle remember me
    const checkRememberMe = async () => {
        let loginDetail = await AsyncStorage.getItem('@rememberMe');
        if (loginDetail && loginDetail !== null) {
            loginDetail = JSON.parse(loginDetail);
            values.email = loginDetail?.email || '';
            values.password = loginDetail?.password || '';
            setFieldValue("email", loginDetail?.email);
            setFieldValue("password", loginDetail?.password);
            setRefreshFiled(true)
            setRememberMe(true)
        }
    }

    // Animation 
    const animateLogo = () => {
        Animated.parallel([
            Animated.timing(
                fadeAnim,
                {
                    toValue: 1,
                    duration: 1500,
                    useNativeDriver: true
                },

            ),
            Animated.timing(
                transformAnim,
                {
                    toValue: 0,
                    duration: 1500,
                    useNativeDriver: true
                },

            )
        ]).start()
    }

    // Get device token
    const requestUserPermission = async () => {
        const authStatus = await messaging().requestPermission();
        const enabled =
            authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
            authStatus === messaging.AuthorizationStatus.PROVISIONAL;
        if (enabled) {
            const _deviceToken = await messaging().getToken();
            setDeviceToken(_deviceToken)
        }
    }

    // Login request submision 
    const handleLoginSubmit = async (event) => {
        //props.navigation.navigate("Coupons")
        Keyboard.dismiss();
        if (email == "") {
            Alert.alert(CommonStrings.AppName, "Enter Email Address")
        } else if (password == "") {
            Alert.alert(CommonStrings.AppName, "Enter password")
        }
        // else if (!validPass) {
        //     Alert.alert(CommonStrings.AppName, "Enter valid password. It should be Combination of  Letters & Numbers minimum 8 characters")
        // }
        else {
            if (rememberMe) {
                await AsyncStorage.setItem('@rememberMe', JSON.stringify({
                    email: email,
                    password: password
                }))
            } else {
                await AsyncStorage.removeItem('@rememberMe')
            }
            let request = {
                "email": email,
                "password": password,
                "deviceToken": "sdfsdfsdfgsjdfhgsdfhsdgf",
                "roletype": "user"
            }
            props.login(request, props.navigation)
        }

        // setIsValidEmail(event.target.checkValidity());
    }
    const handleEmailChange = (text) => {
        setEmail(text)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        setIsValidEmail(emailRegex.test(text));
    }
    // const handlePassswordChange = (text) => {
    //     setPassword(text)
    // }
    const handlePassswordChange = (value) => {
        // setPassword(value)

        // const passRegex = "^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/"
        // setValidPass(passRegex.test(value));
        const passwordRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})")
        setPassword(value)
        // alert('Password must be at least 8 characters long and contain at least one letter and one number.');
        setValidPass(passwordRegex.test(value));
    }



    return (


        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center  `}>

            <ScrollView style={tw`bg-[#FAFAFA] `}>
                <View style={tw`flex-1 bg-[#fff]  w-12/12 flex justify-center items-center`}>
                    <View style={tw`mt-20 mb-15 justify-center items-center `}>
                        <Text style={tw`text-black text-3xl font-bold `}> Login to your  </Text>
                        <Text style={tw`text-black text-3xl font-bold `}>  Account </Text>

                    </View>
                    <View style={tw` justify-center items-start w-11/12`}>

                        <Text style={tw`text-black pl-3 `}>EMAIL</Text>
                    </View>
                    <View style={tw`  justify-center mt-4 items-center w-11/12`}>
                        <TextInput
                            // style={ tw`mx-5  bg-[#FFFFFF] text-black border-[#828282] rounded-4 h-12 mt-3  pl-8`}
                            style={tw`  bg-[#ffffff] text-black border border-[#828282] rounded-2 w-12/12 h-12 pl-3`}
                            value={email}
                            type='text'
                            placeholder={'Email'}
                            placeholderTextColor={Colors.GREY}
                            // onChangeText={handleChange('email')}
                            onChangeText={handleEmailChange}
                            keyboardType="email-address"
                            reference={emailInputRef}
                            selectionColor="#C20A33"
                            onSubmitEditing={() => passwordInputRef?.current?.focus()}
                        />
                    </View>

                    <View style={tw` justify-center items-start mt-4 w-11/12`}>
                        <Text style={tw`text-black pl-3`}>PASSWORD</Text>
                    </View>
                    <View style={tw`justify-center mt-4 items-center w-11/12`}>
                        <TextInput
                            // style={tw`mx-10  bg-[#FFFFFF] text-black rounded-4 h-12 border mt-6   pl-8`}
                            style={tw`  bg-[#ffffff] text-black border border-[#828282] rounded-2 w-12/12 h-12 pl-3`}
                            // value={values.email}
                            type='Password'
                            placeholder={'Password'}
                            value={password}
                            onChangeText={handlePassswordChange}
                            placeholderTextColor={Colors.GREY}
                            secureTextEntry={isShowPassword}
                            password={true}
                            selectionColor="#C20A33"
                        />
                        <TouchableOpacity style={tw`absolute right-5    `} onPress={() => setIsShowPassword(!isShowPassword)}>
                            {isShowPassword ?
                                <Image source={ImageIcons.eyeIconHide} style={tw`w-5 h-5`} />
                                :
                                <Image source={ImageIcons.eyeIcon} style={tw`w-5 h-5`} />
                            }
                        </TouchableOpacity>
                    </View>
                    <View style={tw`flex-row justify-center items-center mt-4 w-11/12 `}>
                        <View style={tw`  border  bg-[#E8E8E8]  rounded-[4] h-6 justify-center w-11 `}>
                            <Switch style={tw`w-11`}
                                value={isEnabled}
                                onValueChange={(value) => setisEnabled(value)}
                                trackColor={{ false: "#E8E8E8", true: "#E0F64B" }}
                                thumbColor={isEnabled ? "#313541" : "#313541"}
                                ios_backgroundColor='gray'
                            />
                        </View>
                        {/* <CheckBox
                            disabled={false}
                            value={rememberMe}
                            style={tw`w-6 h-6 ml-5`}
                            // tintColors={Colors.RED}
                            tintColors={{ true: Colors.BLUE, false: Colors.BLACK, }}
                            boxType="square"
                            onValueChange={(rememberMe) => setRememberMe(rememberMe)}
                        /> */}
                        {/* <Image source={ImageIcons.Rectanglebox} style={tw`h-3.5 w-3.5 mt-1s`} /> */}
                        <View style={tw`w-10/12  flex-row justify-between pl-3`}>
                            <Text style={tw`text-black  text-xs`}>Remember me</Text>

                            <Text style={tw`text-black   text-xs`} onPress={() => props.navigation.navigate('ForgetPassword')}>Forgot Password?</Text>
                        </View>
                    </View>
                    <View style={tw`flex-row justify-center items-center mt-40 w-11/12 `}>
                        <TouchableOpacity onPress={handleLoginSubmit} style={tw` h-13 w-12/12 bg-[#E0F64B] items-center  justify-center rounded-[2]  `} >
                            <Text style={tw`text-black w-86 text-[4.5] px-37  `}>Login</Text>
                        </TouchableOpacity>
                    </View>
                    {/* <View style={tw`flex-row justify-center items-center mt-4 w-11/12  border border-2`}>
                        <Text style={tw` text-[#848484] `}> New to the app? <TouchableOpacity onPress={() => props.navigation.navigate("Registration")} style={tw`  `}>
                            <Text style={tw` text-[#848484]  `}>Register Now</Text></TouchableOpacity></Text>
                    </View> */}

                    <View style={tw`flex-row justify-center items-center mt-5 w-11/12 mb-18`}>
                        <Text style={tw` text-[#848484] `}> New to the app?</Text>
                        <TouchableOpacity onPress={() => props.navigation.navigate("Registration")} style={tw`  `}>
                            <Text style={tw` text-[#848484] `}> Register Now</Text>
                        </TouchableOpacity>

                    </View>


                    {/* <TouchableOpacity onPress={handleLoginSubmit}>
                        <View style={tw`w-11/12 flex-row mt-5 justify-end items-center`}>
                            <Text style={tw`font-bold text-lg `}>Sign In</Text>
                            <View style={tw`h-10 w-10 rounded-full bg-[#BD0B30] ml-2`}></View>
                            <Image source={ImageIcons.arrow_login} style={tw`h-4   absolute mt-3 right-3 w-5 `} />

                        </View>
                    </TouchableOpacity> */}
                    {/* <TouchableOpacity onPress={() => props.navigation.navigate("SetupPin")}>
                    <Text>SetUP PIN</Text>
                    </TouchableOpacity> */}
                </View>
            </ScrollView>
            {/* {keyboardStatus == 0 &&
                    <View style={tw`absolute bottom-0 right-0`}>
                        <TouchableOpacity onPress={() => props.navigation.navigate('Registration')}>
                            <ImageBackground source={ImageIcons.Ellipse_bottom} style={tw`h-20 w-41`}>
                                <Text style={tw`font-bold text-lg text-right text-[#fff] right-5 my-7`}>Sign Up</Text>
                            </ImageBackground>
                        </TouchableOpacity>
                    </View>
                } */}


        </KeyboardAvoidingView >

    )
}

const formikEnhancer = withFormik({
    validateOnMount: true,
    validationSchema: Yup.object().shape({
        email: Yup.string().required('Please enter email address').email('Please enter a valid email address'),
        password: Yup.string().required('Please enter password'),
    }),
    mapPropsToValues: (props) => {
        return {
            email: '',
            password: '',
        };
    },
    handleSubmit: async (payload, { props }) => {
        // props.login(payload)
    },
});

export default formikEnhancer(Login);