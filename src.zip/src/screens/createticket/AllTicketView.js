import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, StatusBar, TouchableOpacity, KeyboardAvoidingView, ScrollView, Image } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import CustomBottomTab from '../../components/CustomBottomTab';
import Loader from '../../components/modals/Loader';
import styles from './styles';
import tw from 'twrnc';
import backarrow from '../../common/arrow-left.png'
import notification from '../../common/notificationicon.png'
import message from '../../common/messageicon.png'
import deposit from '../../common/g.png'
import withdrawicon from '../../common/io.png'
import refferalicon from '../../common/l.png'
import profiticon from '../../common/h.png'
import moment from 'moment';
import { DatePickerButton, RoundedButton } from '../../components/forms/button';
import withdrawiconblack from '../../common/io1.png'
import refferaliconblack from '../../common/l1.png'
import profiticonblack from '../../common/h1.png'
import image from '../../common/Image.png'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import CustomHeaderTab from '../../components/CustomHeaderTab';

import LinearGradient from 'react-native-linear-gradient';
// import { getTransactionsList } from '../../redux/actions/Coupon';

const AllTicketView = (props) => {

    const [popularOperation, setPopularOperation] = useState('deposit')
    const [startDate, setStartDate] = useState();
    const [endtDate, setEndDate] = useState();
    const [type, setType] = useState();
    const [isPlaceholderStartDate, setIsPlaceholderStartDate] = useState(true);
    const [isPlaceholderEndDate, setIsPlaceholderEndDate] = useState(true);
    const [submitted, setSubmit] = React.useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [show, setShow] = useState(false);
    const [datePickerFor, setDatePickerFor] = useState("startDate");  //startDate, endDate

    const onChangeDate = (dateTime) => {
        if (dateTime) {
            setShowDatePicker(false)
            if (datePickerFor === "startDate") {
                setIsPlaceholderStartDate(false)
                setStartDate(dateTime);
            } else {
                setIsPlaceholderEndDate(false);
                setEndDate(dateTime);
            }
            setToggleCheckBox(false)
        }
    }

    useEffect(() => {
        props?.ticketsListing();

    }, [])

    
    
    const renderEmptyComponent = () => {
        return (
            <View style={tw`items-center justify-center mt-20 my-40`}>
                <Text>No data available</Text>
            </View>
        );
    };

    const renderItem = ({ item, index }) => {

        return (
            <View>
                <View style={tw`flex-row justify-between my-2 p-5 mx-auto h-17 w-11/12 bg-white  items-center  shadow-lg shadow-[#7D64FF] rounded-[4] `}>
                    <TouchableOpacity onPress={() => props?.navigation?.navigate("ChatPage", { id: item._id })}>
                        <View style={tw`flex-row w-12/12 items-center`}>
                            <View style={tw`w-9/12`}>
                                <Text style={tw`font-bold text-'#1C162E' text-sm my-1`}>{item.subject}</Text>
                                <Text style={tw`text-'#1C162E' text-xs  `}>{item.message}</Text>
                            </View>
                            {item.status == 'pending' ?
                                <View style={tw`w-3/12`}>
                                    <TouchableOpacity style={tw`bg-[#E33A61] h-8 w-20 items-center text-center justify-center rounded-[9] my-5`} onPress={() => props?.navigation?.navigate('CreateTicket')}>
                                        <Text style={tw`text-[#ffffff]`}>{item.status}</Text>
                                    </TouchableOpacity>
                                </View>
                                :
                                <View style={tw`w-3/12`}>
                                    <TouchableOpacity style={tw`bg-[#097969] h-8 w-20 items-center text-center justify-center rounded-[9] my-5`} onPress={() => props?.navigation?.navigate('CreateTicket')}>
                                        <Text style={tw`text-[#ffffff]`}>{item.status}</Text>
                                    </TouchableOpacity>
                                </View>
                            }
                        </View>
                    </TouchableOpacity>
                </View>
            </View>

        )
    }





    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === "ios" && "padding"}
            style={tw`flex-1 justify-center`}>

            <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Support Tickets'} isTicket={true} />

            <ScrollView style={tw`bg-white mt-2`}>
                <View>
                    <FlatList
                        data={props?.createticket}
                        renderItem={renderItem}
                        keyExtractor={item => item?.id}
                        ListEmptyComponent={renderEmptyComponent}
                    />
                </View>
            </ScrollView>

            {/* 
            <CustomBottomTab
                {...props} isActive={true} selected={"Insights"} /> */}
        </KeyboardAvoidingView>

    )
}

export default AllTicketView;