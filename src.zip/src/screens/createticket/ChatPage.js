import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, Button, ImageBackground, TouchableOpacity, Image, ScrollView } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import LinearGradient from 'react-native-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import { TextInput } from 'react-native-gesture-handler';

const ChatPage = (props) => {
  const ticketId = props?.route?.params?.id

  const scrollViewRef = useRef(null);


  useEffect(() => {
    props?.ticketThreadChat(ticketId);
    setTimeout(function(){ 
      scrollViewRef.current?.scrollToEnd({ animated: false}); 
    },1000)
  }, [])
  const [inputText, setInputText] = useState('');
  const handlemessageChange = (text) => {
    
    setInputText(text)

  }
  const handleSubmitButton = () => {
    if (inputText == '') {
      alert('Enter Your message')
    }
    else {
      let request = {
        ticketId: ticketId,
        userMessage: inputText
      }
      setInputText('')
      props?.chatThread(request)
      props?.ticketThreadChat(ticketId);
      setTimeout(function(){ 
        scrollViewRef.current?.scrollToEnd({ animated: false}); 
      },1000)
    }
  }
  const renderItem = ({ item, index }) => {
    
    return (
      <>
        {item.adminMessage != '' &&
          <>
            <View style={tw`items-start justify-start p-2 mt-0 `}>              
              <View style={tw`h-auto w-auto bg-[#ffffff] p-3 items-center shadow-blue-900  justify-start shadow-xl rounded-t-[2] rounded-br-[4] flex-row`}>
                <Text style={tw`text-[#333333] text-sm`}>{item.adminMessage}</Text>
              </View>
              <Text style={tw`justify-start text-center text-sm text-[#757575] w-4/12 mt-1`}>{moment(item.createdAt).format("MMM Do, h:mm a")}</Text>
            </View>

          </>
        }
        {item.userMessage != '' &&
          <>
            <View style={tw` items-end justify-end p-2 mt-0`}>
              <View style={tw`h-auto w-auto bg-[#002662] p-3 items-center shadow-blue-900  justify-center shadow-xl rounded-t-[2] rounded-bl-[4] flex-row`}>
                <Text style={tw`text-[#FFFFFF] text-sm`}>{item.userMessage}</Text>
              </View>
              <Text style={tw`text-center text-sm text-[#757575] ml-8`}>{moment(item.createdAt).format("MMM Do, h:mm a")}</Text>
            </View>
          </>
        }

      </>
    )
  }

  return (
    <View style={tw`flex-1 bg-[#FFFFFF]`}>

      <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
      <CustomHeaderTab {...props} isActive={true} selected={"Coupon"} parent={false} name={'Support'} />
      <View style={tw`mb-20 bottom-18 top-0 bg-[#f2f2f2]`}>
        <ScrollView ref={scrollViewRef}>
            <FlatList
              data={props?.ticketThread}
              renderItem={renderItem}
              keyExtractor={item => item.id}
            />
        </ScrollView>

        <Loader isVisible={props?.couponsListLoader} />
      </View>
      <View style={tw`flex-row bg-white justify-around bottom-0 absolute`}>
        <View style={tw`w-9/12`}>
          <TextInput placeholder={'Type your message'} onChangeText={handlemessageChange} clearButtonMode="while-editing" value={inputText} placeholderTextColor={'black'} style={tw` shadow-[#ffffff]  shadow-2xl mb-2 bg-[#ffffff]  text-black rounded-3 h-14 p-4 `} />

        </View>
        <View style={tw`w-3/12`}>
        <TouchableOpacity style={tw`justify-center items-center`} onPress={() => handleSubmitButton()}>
          <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
            end={{ x: 1.0, y: 0.1 }}
            locations={[0.0, 1.0]} style={tw` h-12 w-90% mb-2 ml-2 items-center  justify-center rounded-[4] `}
          >
            <View style={tw`flex-row `}>
              <Text style={tw`text-white text-sm font-bold  `}>Send</Text>
              <Image source={ImageIcons.arrow_login} style={tw`h-3 w-5 mt-1 ml-2`} />
            </View>
          </LinearGradient>
        </TouchableOpacity>
        </View>
      </View>
      {/* <CustomBottomTab {...props} isActive={true} selected={"Profile"} /> */}
    </View>
  )
}

export default ChatPage;