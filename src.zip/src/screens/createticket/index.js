import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View, FlatList, StatusBar, Linking, Dimensions, TextInput, ImageBackground, TouchableOpacity, Image, ScrollView } from 'react-native';
import { Fonts, Colors, ImageIcons } from '../../common';
import { FloatingButton, RoundedButton } from '../../components/forms/button';
import CustomBottomTab from '../../components/CustomBottomTab';
import CustomHeaderTab from '../../components/CustomHeaderTab';
import Loader from '../../components/modals/Loader';
import Video from 'react-native-video';
import styles from './styles';
import { useFocusEffect } from '@react-navigation/native';
import tw from 'twrnc';
import select from '../../common/select.png'
import Modal from 'react-native-modal';
// import messaging from '@react-native-firebase/messaging';
import { firebase, ShortcutBadge } from '@react-native-firebase/app';
import { MarkerAnimated } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import ToggleSwitch from 'toggle-switch-react-native'
// import { LinearGradientText } from 'react-native-linear-gradient-text'
// import notifee, { AuthorizationStatus } from '@notifee/react-native';


const SCREEN_HEIGHT = Dimensions.get('screen').height
const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const CreateTicket = (props) => {

    const [message, setMessage] = useState('');
    const [subject, setSubject] = useState('');
    const [copy, setCopy] = useState('');
    const [validname, setValidname] = useState('');
    const [validEmail, setValidEmail] = useState('');
    const [validPhone, setValiPhone] = useState('');

    const handleSubjectChange = (text) => {
        
        setSubject(text)

    }
    const handleMessageChange = (text) => {
        setMessage(text)

    }
    const handlecopy = (text) => {
        setCopy(text)
    }

    const handleSubmit1 = () => {
        if (subject == '') {
            alert('Enter Your Subject')
        } else if (message == '') {
            alert('Enter Your Message')
        }
        else {
            let request = {

                subject: subject,
                message: message,



            }

            props?.addTickets(request,props?.navigation)

        }
    }

    return (
        <View style={tw`flex-1 bg-white`}>

            <StatusBar backgroundColor={Colors.WHITE} barStyle="dark-content" translucent={true} />
            {/* <CustomHeaderTab {...props} isActive={false} selected={"Coupon"} /> */}
            <ScrollView>



                <View style={tw`items-center bg-[#ffffff] mt-9 w-12/12`}>
                    <View style={tw`mt-5 flex-row w-4.5/12 `}>
                        <Text style={tw`font-bold text-lg text-center mt-8`}>Create Ticket</Text>
                        <TouchableOpacity onPress={() => props?.navigation?.navigate('AllTicketView')} style={tw` ml-25`}>
                            <Image source={ImageIcons.refferFriend} style={tw`h-5 w-5 `} />
                        </TouchableOpacity>
                    </View>






                    <View style={tw`  w-10/12 bg-[#fff] shadow-2xl shadow-[#7D64FF]   rounded-[8] justify-center items-center my-30`}>

                        <View style={tw`w-9/12`}>

                            <TextInput placeholder={'Subject'} onChangeText={handleSubjectChange} value={subject} placeholderTextColor={'black'} style={tw`  bg-[#ffffff] text-black border rounded-3 h-14 p-4 mt-12`} />

                            {/* {validname &&
                                <>
                                    <LinearGradient colors={['#DE3163', '#DE8206']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3.5]  absolute top-1/2 transform -translate-y-1/2 right-14 mt-2 `}
                                    >
                                        <View style={tw`flex-row `}>

                                            <Image
                                                source={select}
                                                style={[tw`h-7 w-7  `, { tintColor: 'white' }]}

                                            >
                                            </Image>
                                        </View>

                                    </LinearGradient>


                                </>


                            } */}
                        </View>
                        <View style={tw`w-9/12 justify-start`}>
                            <TextInput placeholder={'Message'} onChangeText={handleMessageChange} value={message} placeholderTextColor={'black'} multiline={true} numberOfLines={5} style={tw` bg-[#ffffff] border justify-start items- text-black rounded-3  p-4 mt-4`}></TextInput>
                            {/* 
                            {validEmail &&

                                <>
                                    <LinearGradient colors={['#DE3163', '#DE8206']} start={{ x: 0.1, y: 1.0 }}
                                        end={{ x: 1.0, y: 0.1 }}
                                        locations={[0.0, 1.0]} style={tw` h-10 w-10  justify-center text-center items-center rounded-[3.5]  absolute top-1/2 transform -translate-y-1/2 right-14 mt-2 `}
                                    >
                                        <View style={tw`flex-row `}>

                                            <Image
                                                source={select}
                                                style={[tw`h-7 w-7  `, { tintColor: 'white' }]}

                                            >
                                            </Image>
                                        </View>

                                    </LinearGradient>


                                </>


                            } */}

                        </View>




                        <TouchableOpacity onPress={() => handleSubmit1()}>
                            {/* <TouchableOpacity> */}
                            <LinearGradient colors={['#C10932', '#FD5578']} start={{ x: 0.1, y: 1.0 }}
                                end={{ x: 1.0, y: 0.1 }}
                                locations={[0.0, 1.0]} style={tw` h-16 w-50  mx-16 mt-11 mb-6  items-center  justify-center rounded-[8] p-3 `}
                            >
                                <Text style={tw`text-white text-sm font-bold  `}>Submit</Text>
                            </LinearGradient>
                        </TouchableOpacity>

                    </View>


                </View>

                <Loader isVisible={props?.couponsListLoader} />
            </ScrollView>

            {/* <CustomBottomTab {...props} isActive={true} selected={"Coupon"} /> */}
        </View>
    )
}

export default CreateTicket;