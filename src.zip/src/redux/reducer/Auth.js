import {
  SET_EDITPROFILE_LOADER,
  SET_EDITPROFILE,
  USER_PROFILE,
  USER_PROFILE_SUCCESS,
  SIGNUP_CREDENTIALS,
  CHANGE_REMBER_ME_LOGIN_CREDENTIALS,
  SIGNUP_SUCCESS,
  SET_LOGIN_CREDENTIAL,
  OTP_VERIFIED,
  OTP_RESEND_SUCCESS,
  SET_REGISTRATION_LOADER,
  SET_OTP_LOADER,
  SET_LOGIN_LOADER,
  SET_FORGET_PASSWORD_LOADER,
  SET_RESET_PASSWORD_LOADER,
  SET_FORGET_PASSWORD_SUCCESS,
  SET_RESET_PASSWORD_SUCCESS,
  SET_NETWORK_STATE,
  VENDOR_REQUEST_LOADER,
  VENDOR_REQUESTED_INFO,
  SET_DEFAULT_AUTH_SCREEN,
  EXIST_EMAIL_DATA,
  SIGNUP_ROLE_SUCCESS,
  CHANGE_MOBILE_NO,

  SET_PROFILE_USER,
  GET_WALLET_DATA,
  GET_DEPOSIT_DATA,
  GET_NEWS_DATA,
  GET_STOCK_DATA,
  SEARCH_NEWS_DATA,
  

} from '../actions/ActionTypes';

// Redux state
const initialState = {
  isInternetConnected: false,
  signupCredentials: null,
  registrationLoader: false,
  otpVerified: false,
  optResent: undefined,
  otpVerificationLoader: false,
  signupSuccess: false,
  loginCredentials: null,
  loginLoader: false,
  remeberMeLoginCredentials: false,
  forgetPasswordLoader: false,
  resetPasswordLoader: false,
  forgetPasswordSuccess: false,
  resetPasswordSuccess: false,
  vendorRequestLoader: false,
  vendorRequestedInfo: null,
  existemail: [],
  signuprolestatus: false,
  defaultAuthScreen: "Login",  //Login, ResetPaswword
  seteditprofile: null,
  editprofileloader: false,
  setmobileno: null,

  userdarshanDetail: null,
  getwalletBalance: [],
  getDeposit: [],
  getNewslist: [],
  getStocklist: [],
  searchNewsdata : [],

};

const Auth = (state = initialState, action) => {
  switch (action.type) {
    case USER_PROFILE_SUCCESS:
      return {
        ...state,
        isloading: true,
        error: '',
        data: action.payload,
        // message: ''
      }
    case GET_WALLET_DATA:
      
      return {
        ...state,
        getwalletBalance: action.payload,

      };
    case GET_DEPOSIT_DATA:
      return {
        ...state,
        getDeposit: action.payload,

      };


    case SEARCH_NEWS_DATA:
      return {
        ...state,
        searchNewsdata: action.payload,

      };

    case GET_NEWS_DATA:
      return {
        ...state,
        getNewslist: action.payload,

      };

    case GET_STOCK_DATA:
      return {
        ...state,
        getStocklist: action.payload,

      };

    case SET_NETWORK_STATE:
      return {
        ...state,
        isInternetConnected: action.payload,
      };
    case SIGNUP_CREDENTIALS:
      
      return {
        ...state,
        signupCredentials: action.payload,
      };
    case SET_EDITPROFILE_LOADER:
      return {
        ...state,
        editprofileloader: action.payload,
      };
    case SET_EDITPROFILE:
      return {
        ...state,
        seteditprofile: action.payload,
      };

    case EXIST_EMAIL_DATA:
      return {
        ...state,
        existemail: action.payload,
      };
    case SIGNUP_ROLE_SUCCESS:
      return {
        ...state,
        signuprolestatus: action.payload,
      };
    case SET_REGISTRATION_LOADER:
      return {
        ...state,
        registrationLoader: action.payload,
      };
    case CHANGE_REMBER_ME_LOGIN_CREDENTIALS:
      return {
        ...state,
        remeberMeLoginCredentials: action.payload,
      };
    case SIGNUP_SUCCESS:
      return {
        ...state,
        signupSuccess: action.payload,
      };
    case SET_PROFILE_USER:

      return {
        ...state,
        userdarshanDetail: action.payload,

      };
    case SET_LOGIN_CREDENTIAL:
      
      return {
        ...state,
        loginCredentials: action.payload,
      };
    case SET_LOGIN_LOADER:
      return {
        ...state,
        loginLoader: action.payload,
      };
    case OTP_VERIFIED:
      return {
        ...state,
        otpVerified: action.payload,
      };
    case SET_OTP_LOADER:
      return {
        ...state,
        otpVerificationLoader: action.payload,
      };
    case CHANGE_MOBILE_NO:
      return {
        ...state,
        setmobileno: action.payload,
      };
    case OTP_RESEND_SUCCESS:
      return {
        ...state,
        optResent: action.payload,
      };
    case SET_FORGET_PASSWORD_LOADER:
      return {
        ...state,
        forgetPasswordLoader: action.payload,
      };
    case SET_RESET_PASSWORD_LOADER:
      return {
        ...state,
        resetPasswordLoader: action.payload,
      };
    case SET_FORGET_PASSWORD_SUCCESS:
      return {
        ...state,
        forgetPasswordSuccess: action.payload,
      };
    case SET_RESET_PASSWORD_SUCCESS:
      return {
        ...state,
        resetPasswordSuccess: action.payload,
      };
    case VENDOR_REQUEST_LOADER:
      return {
        ...state,
        vendorRequestLoader: action.payload,
      };
    case VENDOR_REQUESTED_INFO:
      return {
        ...state,
        vendorRequestedInfo: action.payload,
      };
    case SET_DEFAULT_AUTH_SCREEN:
      return {
        ...state,
        defaultAuthScreen: action.payload,
      };
     
    default:
      return state;
  }
};

export default Auth;
