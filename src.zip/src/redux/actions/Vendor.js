import {
    SET_INITIATE_REQUEST,
    SET_INITIATEWIHDRAW_REQUEST,
    SET_CREATE_STORE_INFO,
    SET_CREATE_STORE_LOADER,
    SET_VENDOR_LOADER,
    VENDOR_ADDED_SUCCESS,
    SET_UTILITYBILL_INFO,
    SET_UTILITYBILL_LOADER,
    SET_STOREIMAGE_LOADER,
    SET_STOREIMAGE_INFO,
    SET_VENDOR_LIST_LOADER,
    SET_VENDOR_LIST,
    VENDOR_UPDATE_LOADER,
    VENDOR_UPDATED_INFO,
    SET_SINGLE_VENDOR_LOADER,
    SET_SINGLE_VENDOR_INFO,
    ACCEPT_VENDOR_LOADER,
    ACCEPT_VENDOR_INFO,
    SET_IS_STORE,
    SET_STORE_AUTOFILL_INFO,
    SET_VENDOR_NOTIFICATION_INFO,
    SET_SEARCH_CATEGORY_LOADER,
    SET_SEARCH_CATEGORY_RESULT,
    SET_USER_ID_RESET_PASSWORD,
    SET_DEFAULT_AUTH_SCREEN,
    SET_LOGIN_CREDENTIAL,
    SET_TRACK_EARNING_LOADER,
    SET_TRACK_EARNING_DATA,
    SET_VERIFICAITON_STATUS,
    SET_PLAN_SELECTED_FLAG,
    SET_VERIFICAITON_STEPS,
    SET_BUSINESS_EXISTANCES,
    SET_DASHBOARD_DATA,
    SET_REFFERAL_FRIEND,
    SET_TICKET,
    GET_TICKET_LIST,
    GET_REFFERAL_LIST,
    GET_TICKET_THREAD,
    SET_CHATTHREAD_LIST,
    GET_BANNER_LIST,
    SET_CURRENCY_LIST,
    SET_INITIATE_USDT,
    GET_NOTIFICATION_LIST,
    SET_STOCK_DATA,
    SET_lavlesh_DATA,
    GET_ASSESTS_HOLDS
} from './ActionTypes';
import { Alert } from 'react-native';

import { Api, Utilise, CommonStrings } from '../../common';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { search } from '../../common/SearchApiCalling';
import { CommonActions, StackActions } from '@react-navigation/native';


export const initiateBuyUSDT = (data, navigation) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {

                let response = await Utilise.apiCalling('POST', Api.initiateBuyUSDT, data);
                
                if (response?.status == 200) {
                    Alert.alert(CommonStrings.AppName, response?.message)
                    dispatch({ type: SET_INITIATE_USDT, payload: response.data });
                    navigation.navigate("Transaction");   

                }
                if (response?.status == 201) {
                    Alert.alert(CommonStrings.AppName, response?.message)

                }
            } catch (error) {

            }
        };
    }
};

export const initiateSellStock = (data, navigation) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {

                let response = await Utilise.apiCalling('POST', Api.initiateSellUSDT, data);
                
                if (response?.status == 200) {
                    Alert.alert(CommonStrings.AppName, response?.message)
                    navigation.navigate("Transaction");  

                }
                if (response?.status == 201) {
                    Alert.alert(CommonStrings.AppName, response?.message)

                }
            } catch (error) {

            }
        };
    }
};




export const stocksHolds = (data, navigation) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {

                let response = await Utilise.apiCalling('POST', Api.assestsHolds, data);
                
                if (response?.status == 200) {
                    dispatch({ type: GET_ASSESTS_HOLDS, payload: response.data.rows });
                    // navigation.navigate("BuyUsdt");   

                }
                if (response?.status == 201) {
                    Alert.alert(CommonStrings.AppName, response?.message)

                }
            } catch (error) {

            }
        };
    }
};

// export const initiateBuyUSDT = (request, navigation) => {

//     return async (dispatch,getState) => {
//         try {


//             dispatch({ type: SET_INITIATE_USDT, payload: request });
//             navigation.navigate("BuyUsdt");          
//         } catch (error) {

//         }
//       }
//   }

export const initiateSellUSDT = (request, navigation) => {

    return async (dispatch, getState) => {
        try {
            dispatch({ type: SET_INITIATE_USDT, payload: request });
            navigation.navigate("SellUsdt");
        } catch (error) {

        }
    }
}

export const initiateTransaction = (request, navigation) => { 
    return async (dispatch, getState) => {
        // let isInternetConnected = await getState().auth?.isInternetConnected;
        // if (isInternetConnected) {
        try {

            let response = await Utilise.apiCalling('POST', Api.initiateTransaction, request);
            
            if (response.status == 200 || response.status == '200') {
                dispatch({ type: SET_INITIATE_REQUEST, payload: response.data });
                Alert.alert(CommonStrings.AppName, response?.message)
                navigation.navigate('Transaction');
            } else {
                Alert.alert(CommonStrings.AppName, response?.message)
            }
        } catch (error) {

        }
    }
}

export const initiateWithdrawRequest = (request, navigation) => {
    return async (getState) => {
        // let isInternetConnected = await getState().auth?.isInternetConnected;
        // if (isInternetConnected) {
        try {

            let response = await Utilise.apiCalling('POST', Api.initiateWithdrawRequest, request);
            
            if (response.status == 200) {
                //dispatch({ type: SET_INITIATEWIHDRAW_REQUEST, payload: response.data });
                Alert.alert(CommonStrings.AppName, 'Withdraw request successful!')
                navigation.navigate("Wallet");
            } else {
                Alert.alert(CommonStrings.AppName, response.message)
            }
        } catch (error) {

        }
    }
}
export const addReferral = (request, navigation) => {
    return async (getState) => {
        // let isInternetConnected = await getState().auth?.isInternetConnected;
        // if (isInternetConnected) {
        try {

            let response = await Utilise.apiCalling('POST', Api.addReferral, request);
            
            if (response.status == 200) {
                dispatch({ type: SET_REFFERAL_FRIEND, payload: response.data });
            }
        } catch (error) {

        }
    }
}

export const addTickets = (request, navigation) => {
    return async (dispatch, getState) => {
        // let isInternetConnected = await getState().auth?.isInternetConnected;
        // if (isInternetConnected) {
        try {

            let response = await Utilise.apiCalling('POST', Api.addTickets, request);
            
            if (response.status == 200) {
                Alert.alert(CommonStrings.AppName, 'Ticket Created Successfully')
                navigation?.navigate("AllTicketView")
                // dispatch({ type: SET_TICKET, payload: response.data });
                setTimeout(() => {
                    dispatch(ticketsListing('all'))
                }, 200)

            }

        } catch (error) {

        }
    }
}

export const chatThread = (request, navigation) => {
    return async (getState) => {
        // let isInternetConnected = await getState().auth?.isInternetConnected;
        // if (isInternetConnected) {
        try {

            let response = await Utilise.apiCalling('POST', Api.chatThread, request);
            
            if (response.status == 200) {
                dispatch({ type: SET_CHATTHREAD_LIST, payload: response.data });
            }
        } catch (error) {

        }
    }
}
export const setCurrency = (request, navigation) => {
    return async (getState) => {
        // let isInternetConnected = await getState().auth?.isInternetConnected;
        // if (isInternetConnected) {
        try {

            let response = await Utilise.apiCalling('POST', Api.setCurrency, request);
            
            if (response.status == 200) {
                dispatch({ type: SET_CURRENCY_LIST, payload: response.data });
            }
        } catch (error) {

        }
    }
}
export const dashboardData = () => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: SET_DASHBOARD_DATA, payload: true });
                let response = await Utilise.apiCalling('GET', Api.dashboardData)
                
                // dispatch({ type: SET_DASHBOARD_DATA, payload: false });
                if (response?.status) {
                    dispatch({ type: SET_DASHBOARD_DATA, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_DASHBOARD_DATA, payload: false });
                dispatch({ type: SET_DASHBOARD_DATA, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
export const ticketsListing = (type) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('GET', Api.ticketsListing)
                
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type: GET_TICKET_LIST, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_TICKET_LIST, payload: false });
                dispatch({ type: GET_TICKET_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
export const referralListing = (type) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('GET', Api.referralListing)
                
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type: GET_REFFERAL_LIST, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_REFFERAL_LIST, payload: false });
                dispatch({ type: GET_REFFERAL_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
export const getBannerList = (type) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('GET', Api.getBannerList)
                
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type: GET_BANNER_LIST, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_BANNER_LIST, payload: false });
                dispatch({ type: GET_BANNER_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
export const getnotificationlist = (type) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('GET', Api.getnotificationlist)
                
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type: GET_NOTIFICATION_LIST, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_NOTIFICATION_LIST, payload: false });
                dispatch({ type: GET_NOTIFICATION_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
export const ticketThreadChat = (ticketId) => {
    
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.ticketThreadChat}/${ticketId}`)
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type: GET_TICKET_THREAD, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_TICKET_THREAD, payload: false });
                dispatch({ type: GET_TICKET_THREAD, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
// Add New Vendor 
export const addNewVendor = (vendorRequest) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SET_VENDOR_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', Api.addVendor, vendorRequest)
                dispatch({ type: SET_VENDOR_LOADER, payload: false });
                
                if (response?.status) {
                    dispatch({ type: VENDOR_ADDED_SUCCESS, payload: true });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_VENDOR_LOADER, payload: false });
                dispatch({ type: VENDOR_ADDED_SUCCESS, payload: false });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Update Vendor 
export const updateVendor = (updateVendorRequest, vendorId, navigation) => {
    return async (dispatch, getState) => {
        // let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                let url = Api.insertOrUpdateVendor;
                if (vendorId && vendorId !== null) {
                    url = `${Api.insertOrUpdateVendor}?vendorId=${vendorId}`;
                }
                dispatch({ type: VENDOR_UPDATE_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', url, updateVendorRequest)
                
                dispatch({ type: VENDOR_UPDATE_LOADER, payload: false });
                if (response?.status) {
                    if (response?.data?.isBusinessExist) {
                        setTimeout(() => {
                            dispatch({ type: VENDOR_UPDATED_INFO, payload: response?.data?.data });
                            dispatch({ type: SET_BUSINESS_EXISTANCES, payload: true });
                        }, 500);
                        return;
                    } else {
                        dispatch({ type: VENDOR_UPDATED_INFO, payload: response?.data });
                        dispatch({ type: SET_BUSINESS_EXISTANCES, payload: false });
                        navigation?.navigate("Vendor");
                        dispatch(getVendorList())
                    }
                    // Send dynamic link for reset password
                    // dispatch(sendResetPasswordLink(response?.data?._id))
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: VENDOR_UPDATE_LOADER, payload: false });
                dispatch({ type: VENDOR_UPDATED_INFO, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Send reset Paasword link
export const sendResetPasswordLink = (vendorId) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;

    }
};

// Get Vendor List
export const getVendorList = () => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SET_VENDOR_LIST_LOADER, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.getVendorsList}/${loginCredentials?._id}`)
                dispatch({ type: SET_VENDOR_LIST_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SET_VENDOR_LIST, payload: response.data });
                } else {
                    
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_VENDOR_LIST_LOADER, payload: false });
                dispatch({ type: SET_VENDOR_LIST, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};




// Get Single Vendor // it not in use
export const getStoreInfo = (navigation) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                let response = await Utilise.apiCalling('GET', `${Api.getStoreInfo}/${loginCredentials?._id}`)
                if (response?.status) {
                    
                    if (response?.data && response?.data?.utilityBillFile != null) {
                        navigation?.dispatch(
                            CommonActions.reset({
                                index: 0,
                                routes: [{ name: "CouponsStack" }],
                            })
                        );
                    }
                }
            } catch (error) {
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Get Single Vendor // it not in use
export const getSingleVendor = () => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SET_SINGLE_VENDOR_LOADER, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.getVendor}/${loginCredentials?._id}`)
                dispatch({ type: SET_SINGLE_VENDOR_LOADER, payload: false });

                if (response?.status) {
                    dispatch({ type: SET_SINGLE_VENDOR_INFO, payload: response.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_SINGLE_VENDOR_LOADER, payload: false });
                dispatch({ type: SET_SINGLE_VENDOR_INFO, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Create New Store 
export const createOrUpdateStore = (storeRequest, navigation) => {
    
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        let storeAutofilInfo = await getState().vendor?.storeAutofilInfo;
        let loginCredentials = await getState().auth?.loginCredentials;
        if (isInternetConnected) {
            let url = Api.createOrUpdateStore;
            if (storeAutofilInfo && storeAutofilInfo !== null && storeAutofilInfo?._id) {
                url = `${Api.createOrUpdateStore}?storeId=${storeAutofilInfo?._id}`
            }
            try {
                dispatch({ type: SET_VERIFICAITON_STEPS, payload: 0 });
                dispatch({ type: SET_CREATE_STORE_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', url, storeRequest);
                dispatch({ type: SET_CREATE_STORE_LOADER, payload: false });
                
                if (response?.status) {
                    dispatch({ type: SET_CREATE_STORE_INFO, payload: response?.data });
                    dispatch({ type: SET_VERIFICAITON_STATUS, payload: 1 })
                    dispatch({ type: SET_VERIFICAITON_STEPS, payload: 1 });
                    dispatch(setStoreAutofilInfo(response?.data, response?.data?._id, 1))
                    //dispatch(setStoreAutofilInfo(response?.data, response?.data?._id, response?.data?.verificationStatus))
                    await AsyncStorage.setItem('@storeInfo', JSON.stringify(response.data));
                    if (loginCredentials) {
                        let updatedLogin = Object.assign(loginCredentials, { store: response?.data });
                        await AsyncStorage.setItem('@loginCredential', JSON.stringify(updatedLogin));
                    }
                    //navigation?.navigate("VerificationForm2");

                    navigation.navigate("Coupons");
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_CREATE_STORE_LOADER, payload: false });
                dispatch({ type: SET_CREATE_STORE_INFO, payload: null });
                await AsyncStorage.removeItem('@storeInfo');
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Set store autofil information
export const setStoreAutofilInfo = (storeAutofillInfo, storeId, verificationStatus) => {
    return async (dispatch, getState) => {
        try {
            let storeInfo = await AsyncStorage.getItem('@storeInfo');
            let verificationStatusLocal = await AsyncStorage.getItem('@verificationStatus');

            if (verificationStatusLocal && verificationStatusLocal !== null) {
                verificationStatus = JSON.parse(verificationStatusLocal);
            }
            if (storeAutofillInfo && storeAutofillInfo !== null) {
                storeInfo = storeAutofillInfo;
                dispatch({ type: SET_CREATE_STORE_INFO, payload: storeAutofillInfo });
                await AsyncStorage.setItem('@storeInfo', JSON.stringify(storeAutofillInfo));
            } else if (storeInfo && storeInfo !== null) {
                storeInfo = JSON.parse(storeInfo);
                storeId = storeInfo?.verificationStatus?.isStore ? storeInfo?._id : undefined;
            }
            let storeDetail = {
                "_id": storeId,
                "businessAddress": storeInfo?.businessAddress || "",
                "businessName": storeInfo?.businessName || "",
                "businessType": storeInfo?.businessType,
                "contactPerson": storeInfo?.contactPerson || storeInfo?.fullName,
                "countryCode": storeInfo?.countryCode,
                "email": storeInfo?.email,
                "isDeleted": false,
                "verificationStatus": verificationStatus,
                "location": storeInfo?.location,
                "phone": storeInfo?.phone,
            }
            dispatch({ type: SET_VERIFICAITON_STATUS, payload: verificationStatus })
            dispatch({ type: SET_STORE_AUTOFILL_INFO, payload: storeDetail });
            // if (verificationStatus && (verificationStatus?.isStore && verificationStatus?.isStoreImage && verificationStatus?.isUtilityBill)) {
            //     dispatch({ type: SET_VERIFICAITON_STEPS, payload: 3 });
            // }
            // dispatch({ type: SET_CREATE_STORE_INFO, payload: storeDetail });
        } catch (error) {
            dispatch({ type: SET_STORE_AUTOFILL_INFO, payload: null });
            await AsyncStorage.removeItem('@storeInfo');
        }
    }
};

// upload Store Utility Bill
export const uploadStoreUtilityBill = (utilityBillRequest, navigation) => {
    return async (dispatch, getState) => {
        let storeInfo = await getState().vendor?.storeInfo;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SET_UTILITYBILL_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', `${Api.uploadUtilityBill}/${storeInfo?._id}`, utilityBillRequest)
                dispatch({ type: SET_UTILITYBILL_LOADER, payload: false });

                
                if (response?.status) {
                    await AsyncStorage.setItem('@verificationStatus', JSON.stringify(response?.data?.verificationStatus));
                    dispatch({ type: SET_VERIFICAITON_STATUS, payload: response?.data?.verificationStatus })
                    dispatch({ type: SET_STOREIMAGE_INFO, payload: response?.data });
                    dispatch({ type: SET_PLAN_SELECTED_FLAG, payload: true });
                    dispatch({ type: SET_VERIFICAITON_STEPS, payload: 3 })
                    navigation?.dispatch(
                        CommonActions.reset({
                            index: 0,
                            routes: [{ name: "CouponsStack" }],
                        })
                    );
                    // navigation?.navigate("VerificationForm4");
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }

                //  if (response?.status) {
                //     await AsyncStorage.setItem('@verificationStatus', JSON.stringify(response?.data?.verificationStatus));
                //     dispatch({ type: SET_CREATE_STORE_INFO, payload: response?.data });
                //     dispatch({ type: SET_STOREIMAGE_INFO, payload: response?.data });
                //     dispatch({ type: SET_PLAN_SELECTED_FLAG, payload: true });
                //     dispatch({ type: SET_VERIFICAITON_STATUS, payload: response?.data?.verificationStatus })
                //     dispatch({ type: SET_VERIFICAITON_STEPS, payload: 3 });
                //     dispatch(setStoreAutofilInfo(response?.data, response?.data?._id, response?.data?.verificationStatus))
                //     await AsyncStorage.setItem('@storeInfo', JSON.stringify(response.data));
                //     if (loginCredentials) {
                //         let updatedLogin = Object.assign(loginCredentials, { store: response?.data });
                //         await AsyncStorage.setItem('@loginCredential', JSON.stringify(updatedLogin));
                //     }
                //     navigation?.dispatch(
                //         CommonActions.reset({
                //             index: 0,
                //             routes: [{ name: "CouponsStack" }],
                //         })
                //     );
                // } else {
                //     Alert.alert(CommonStrings.AppName, String(response?.message))
                // }
            } catch (error) {
                dispatch({ type: SET_UTILITYBILL_LOADER, payload: false });
                dispatch({ type: SET_UTILITYBILL_INFO, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// upload Store Facade Service
export const uploadStoreFacade = (fecadeRequest, navigation) => {
    return async (dispatch, getState) => {
        let storeInfo = await getState().vendor?.storeInfo;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SET_STOREIMAGE_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', `${Api.uploadStoreFacade}/${storeInfo?._id}`, fecadeRequest)
                dispatch({ type: SET_STOREIMAGE_LOADER, payload: false });
                if (response?.status) {
                    await AsyncStorage.setItem('@verificationStatus', JSON.stringify(response?.data?.verificationStatus));
                    dispatch({ type: SET_VERIFICAITON_STATUS, payload: response?.data?.verificationStatus })
                    dispatch({ type: SET_STOREIMAGE_INFO, payload: response?.data });
                    dispatch({ type: SET_PLAN_SELECTED_FLAG, payload: true });
                    dispatch({ type: SET_VERIFICAITON_STEPS, payload: 3 })
                    navigation?.dispatch(
                        CommonActions.reset({
                            index: 0,
                            routes: [{ name: "CouponsStack" }],
                        })
                    );
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_STOREIMAGE_LOADER, payload: false });
                dispatch({ type: SET_STOREIMAGE_INFO, payload: null });
                // dispatch({ type: SET_IS_STORE, payload: false });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Accept vendor 
export const acceptVendor = (acceptVendorRequest, navigation) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: ACCEPT_VENDOR_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', Api.acceptVendor, acceptVendorRequest)
                dispatch({ type: ACCEPT_VENDOR_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: ACCEPT_VENDOR_INFO, payload: response.data });
                    dispatch({ type: SET_VENDOR_NOTIFICATION_INFO, payload: null });
                    dispatch(getVendorList())
                    await AsyncStorage.removeItem('@vendorInfo')
                    navigation?.navigate("Vendor")

                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: ACCEPT_VENDOR_LOADER, payload: false });
                dispatch({ type: ACCEPT_VENDOR_INFO, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Search Category (Business Type)
export const searchCategory = (searchRequest) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SET_SEARCH_CATEGORY_LOADER, payload: true });
                let response = await search(`${Api.businessType}?search=${searchRequest}`)
                dispatch({ type: SET_SEARCH_CATEGORY_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SET_SEARCH_CATEGORY_RESULT, payload: response.data });
                } else {
                    // Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SET_SEARCH_CATEGORY_LOADER, payload: false });
                dispatch({ type: SET_SEARCH_CATEGORY_RESULT, payload: null });
                // Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Set vendor information from notification
export const setVendorInfo = (vendorInfo) => {
    return async (dispatch, getState) => {
        try {
            let vendorInfoData = await AsyncStorage.getItem('@vendorInfo');
            if (vendorInfoData && vendorInfoData !== null) {
                vendorInfoData = JSON.parse(vendorInfoData);
            } else if (vendorInfo && vendorInfo !== null) {
                vendorInfoData = vendorInfo;
                await AsyncStorage.setItem('@vendorInfo', JSON.stringify(vendorInfoData));
            }
            if (vendorInfoData && vendorInfoData !== null) {
                dispatch({ type: SET_VENDOR_NOTIFICATION_INFO, payload: vendorInfoData });
            } else {
                dispatch({ type: SET_VENDOR_NOTIFICATION_INFO, payload: null });
                await AsyncStorage.removeItem('@vendorInfo');
            }
        } catch (error) {
            dispatch({ type: SET_VENDOR_NOTIFICATION_INFO, payload: null });
            await AsyncStorage.removeItem('@vendorInfo');
        }
    }
};

// Set vendor ID from reset password link
export const setVendorIdResetPassword = (resetLink) => {
    return async (dispatch, getState) => {
        try {
            
            let vendorId = String(resetLink).split('/').pop()
            dispatch({ type: SET_USER_ID_RESET_PASSWORD, payload: vendorId });
            dispatch({ type: SET_DEFAULT_AUTH_SCREEN, payload: "ResetPassword" });
            await AsyncStorage.setItem('@vendorIdResetPassword', JSON.stringify(vendorId));
        } catch (error) {
            dispatch({ type: SET_USER_ID_RESET_PASSWORD, payload: null });
            dispatch({ type: SET_DEFAULT_AUTH_SCREEN, payload: "Login" });
            await AsyncStorage.removeItem('@vendorIdResetPassword');
        }
    }
};

// Get track earning data
export const getTrackEarningData = () => {
    return async (dispatch, getState) => {
        try {
            dispatch({ type: SET_TRACK_EARNING_LOADER, payload: true });
            let response = await Utilise.apiCalling('POST', Api.getCommissionsListOfSalesman)
            dispatch({ type: SET_TRACK_EARNING_LOADER, payload: false });
            if (response?.status) {
                dispatch({ type: SET_TRACK_EARNING_DATA, payload: response?.data });
            } else {
                // Alert.alert(CommonStrings.AppName, String(response?.message))
            }
        } catch (error) {
            dispatch({ type: SET_TRACK_EARNING_LOADER, payload: null });
            dispatch({ type: SET_TRACK_EARNING_DATA, payload: [] });
        }
    }
};

export const setStockDataValue = (data, navigation) => {
    return async (dispatch, getState) => {
        // await AsyncStorage?.setItem('stockData', JSON.stringify(data))
        dispatch({ type: SET_STOCK_DATA, payload: data });
        navigation?.navigate("Buy")
    }
}

export const depositAmount = (data, navigation) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {

                let response = await Utilise.apiCalling('POST', Api.addToWallet, data);
                if (response?.status == 200) {
                    dispatch({ type: SET_INITIATE_REQUEST, payload: response.data });
                    Alert.alert(CommonStrings.AppName, response?.message)
                    navigation.navigate("Coupons");   
                }
                if (response?.status == 201) {
                    Alert.alert(CommonStrings.AppName, response?.message)

                }
            } catch (error) {

            }
        };
    }
}