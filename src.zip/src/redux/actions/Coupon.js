import {
    COUPONS_LIST_LOADER,
    CREATE_COUPONS_LOADER,
    CREATE_COUPONS_SUCCESS,
    SET_COUPONS_LIST,
    REDEEMED_COUPONS_LOADER,
    SET_REDEEMED_COUPONS,
    REDEEMED_COUPONS_TRACKING_LOADER,
    SET_REDEEMED_TRACKING_COUPONS,
    SUBSCRIPTION_PLAN_DATA,
    SUBSCRIPTION_PURCHASED_DATA,
    SUBSCRIPTION_PURCHASED_LOADER,
    SUBSCRIPTION_STATUS,
    SUBSCRIPTION_PLAN_DATA_LOADER,
    SET_PLAN_SELECTED_FLAG,
    SET_REMAING_COUPON_CREDIT,
    SET_PAYMENT_PROCESS,
    PAYMENT_PROCESS_LOADER,
    GET_TRANSACTION_LIST,
    IS_SUBSCRIPTION_SELECTED,
    SET_TRANSACTION,
    GET_TRANSACTION_STOCK,
    GET_STOCK_LIST
    
} from './ActionTypes';
import { Alert } from 'react-native';
import { Api, CommonStrings, Utilise } from '../../common';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackActions } from '@react-navigation/native';


// Create New Coupon 
export const createNewCoupon = (couponRequest, navigation, couponId) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                let url = Api.createOrUpdateCoupon;
                
                // if (couponId && couponId !== null) {
                //     url = `${Api.createOrUpdateCoupon}?couponId=${couponId}`
                // }
                dispatch({ type: CREATE_COUPONS_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', url, couponRequest)

                dispatch({ type: CREATE_COUPONS_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: CREATE_COUPONS_SUCCESS, payload: response.data });
                    dispatch(getCouponList())
                    navigation?.navigate("CouponPublished")
                } else {
                    if (response?.errorType === "purchase_subscription") {
                        Alert.alert(
                            CommonStrings.AppName,
                            String(response?.message),
                            [
                                {
                                    text: 'Cancel',
                                    onPress: () => console.log('Cancel Pressed'),
                                    style: 'cancel'
                                },
                                {
                                    text: 'Subscribe Now', onPress: () => {
                                        dispatch({ type: IS_SUBSCRIPTION_SELECTED, payload: true });
                                        navigation?.dispatch(
                                            StackActions.replace('SubscriptionStack')
                                        );
                                    }
                                }
                            ],
                            { cancelable: false }
                        );
                    } else {
                        Alert.alert(CommonStrings.AppName, String(response?.message))
                    }
                }
            } catch (error) {
                dispatch({ type: CREATE_COUPONS_LOADER, payload: false });
                dispatch({ type: CREATE_COUPONS_SUCCESS, payload: null });
                
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};


export const createNewService = (couponRequest, navigation, couponId) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                let url = Api.createNewService;
                // if (couponId && couponId !== null) {
                //     url = `${Api.createOrUpdateCoupon}?couponId=${couponId}`
                // }
                dispatch({ type: CREATE_COUPONS_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', url, couponRequest)

                dispatch({ type: CREATE_COUPONS_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: CREATE_COUPONS_SUCCESS, payload: response.data });
                    dispatch(getCouponList())
                    navigation?.navigate("Coupons")
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: CREATE_COUPONS_LOADER, payload: false });
                dispatch({ type: CREATE_COUPONS_SUCCESS, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// get Coupon list
export const getCouponList = () => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        dispatch({ type: SET_COUPONS_LIST, payload: [] });
        if (isInternetConnected) {
            try {
                let storeInfo = await AsyncStorage.getItem('@storeInfo');
                if (storeInfo && storeInfo !== null) {
                    storeInfo = JSON.parse(storeInfo);
                    dispatch({ type: COUPONS_LIST_LOADER, payload: true });
                    let response = await Utilise.apiCalling('GET', `${Api.getCoupons}?storeId=${storeInfo?._id}`)
                    
                    dispatch({ type: COUPONS_LIST_LOADER, payload: false });
                    if (response?.status) {
                        //dispatch({ type: SET_REMAING_COUPON_CREDIT, payload: response.data?.credits || 0 });
                        dispatch({ type: SET_COUPONS_LIST, payload: response.data?.coupons || [] });
                    } else {
                        Alert.alert(CommonStrings.AppName, String(response?.message))
                    }
                } else {
                    // Alert.alert(CommonStrings.AppName, String("Some thing went wrong."))
                }
            } catch (error) {
                dispatch({ type: COUPONS_LIST_LOADER, payload: false });
                dispatch({ type: SET_COUPONS_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// get Coupon list
export const setNotificationCount = () => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                let response = await Utilise.apiCalling('GET', `${Api.setNotificationCount}`)
            } catch (error) {
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// get Redeemed coupon  list
export const getRedeemedCoupons = () => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: REDEEMED_COUPONS_LOADER, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.redeemCoupon}/${loginCredentials?._id}`)
                dispatch({ type: REDEEMED_COUPONS_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SET_REDEEMED_COUPONS, payload: response.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: REDEEMED_COUPONS_LOADER, payload: false });
                dispatch({ type: SET_REDEEMED_COUPONS, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
// transactionList
export const getTransactionsList = (type) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.getTransactionsList}?type=${type}`)
                
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type: GET_TRANSACTION_LIST, payload: response.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                dispatch({ type: GET_TRANSACTION_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

export const getTransactionsListStock = (data) => {
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('POST', `${Api.transactionListStock}`,data)
                
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status == 200) {
                    dispatch({ type: GET_TRANSACTION_STOCK, payload: response.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: GET_TRANSACTION_STOCK, payload: false });
                dispatch({ type: GET_TRANSACTION_STOCK, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};
export const getstocklist = (data) => {
    
    return async (dispatch, getState) => {
        let loginCredentials = await getState().auth?.loginCredentials;
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                // dispatch({ type: GET_TRANSACTION_LIST, payload: true });
                let response = await Utilise.apiCalling('POST', `${Api.getstockListing}`,data)
                // dispatch({ type: GET_TRANSACTION_LIST, payload: false });
                if (response?.status) {
                    dispatch({ type:  GET_STOCK_LIST, payload: response.data.rows });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type:  GET_STOCK_LIST, payload: false });
                dispatch({ type:  GET_STOCK_LIST, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// get Redeemed tracking data
export const getRedeemedTrackingData = (couponId) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: REDEEMED_COUPONS_TRACKING_LOADER, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.getRedeemCouponTracking}?couponId=${couponId}`)
                dispatch({ type: REDEEMED_COUPONS_TRACKING_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SET_REDEEMED_TRACKING_COUPONS, payload: response.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: REDEEMED_COUPONS_TRACKING_LOADER, payload: false });
                dispatch({ type: SET_REDEEMED_TRACKING_COUPONS, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// get Subscription Plan data
export const getSubscriptionPlans = () => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        if (isInternetConnected) {
            try {
                dispatch({ type: SUBSCRIPTION_PLAN_DATA_LOADER, payload: true });
                let response = await Utilise.apiCalling('GET', `${Api.getSubscroptionPlan}`)
                dispatch({ type: SUBSCRIPTION_PLAN_DATA_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SUBSCRIPTION_PLAN_DATA, payload: response.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SUBSCRIPTION_PLAN_DATA_LOADER, payload: false });
                dispatch({ type: SUBSCRIPTION_PLAN_DATA, payload: [] });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

// Purchase Subscription Plan 
export const purchaseSubscriptionPlan = (purchaseCouponRequest, navigation) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        let loginCredentials = await getState().auth?.loginCredentials;
        //loginCredentials?._id
        if (isInternetConnected) {
            purchaseCouponRequest.user_id = loginCredentials?._id;
            
            try {
                dispatch({ type: SUBSCRIPTION_PURCHASED_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', `${Api.purchaseSubscription}`, purchaseCouponRequest)
                dispatch({ type: SUBSCRIPTION_PURCHASED_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SUBSCRIPTION_PURCHASED_DATA, payload: response?.data });
                    // dispatch({ type: SET_PLAN_SELECTED_FLAG, payload: true });
                    // navigation?.dispatch(
                    //     StackActions.replace('TransactionDetail')
                    // );
                    navigation?.navigate("TransactionDetail");
                    // Alert.alert(CommonStrings.AppName, String(response?.data?.charge?.message))
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SUBSCRIPTION_PURCHASED_LOADER, payload: false });
                dispatch({ type: SUBSCRIPTION_PURCHASED_DATA, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};


// // Payment process 
// export const paymentProcess = (paymentRequest, purchaseCouponRequest, navigation) => {
//     return async (dispatch, getState) => {
//         let isInternetConnected = await getState().auth?.isInternetConnected;
//         if (isInternetConnected) {
//             try {
//                 dispatch({ type: PAYMENT_PROCESS_LOADER, payload: true });
//                 let response = await Utilise.apiCalling('POST', `${Api.paymentGatewayAuthorization}`, paymentRequest)
//                 dispatch({ type: PAYMENT_PROCESS_LOADER, payload: false });
//                 
//                 if (response?.status) {
//                     dispatch({ type: SET_PAYMENT_PROCESS, payload: response.data });
//                     // dispatch(purchaseSubscriptionPlan(purchaseCouponRequest, navigation))
//                     navigation?.dispatch(
//                         StackActions.replace('TransactionDetail')
//                     );
//                     Alert.alert(CommonStrings.AppName, String(response?.data?.message))
//                 } else {
//                     Alert.alert(CommonStrings.AppName, String(response?.message))
//                 }
//             } catch (error) {
//                 dispatch({ type: PAYMENT_PROCESS_LOADER, payload: false });
//                 dispatch({ type: SET_PAYMENT_PROCESS, payload: null });
//                 Alert.alert(CommonStrings.AppName, String(error?.message))
//             }
//         };
//     }
// };


// get Subscription Status 
export const getSubscriptionStatus = (navigation) => {
    return async (dispatch, getState) => {
        let isInternetConnected = await getState().auth?.isInternetConnected;
        let loginCredentials = await getState().auth?.loginCredentials;

        if (isInternetConnected) {
            var getSubscriptionStatusData = [];
            getSubscriptionStatusData.user_id = loginCredentials?._id;
            
            try {
                dispatch({ type: SUBSCRIPTION_PURCHASED_LOADER, payload: true });
                let response = await Utilise.apiCalling('POST', `${Api.subscriptionStatus}`, getSubscriptionStatus)
                dispatch({ type: SUBSCRIPTION_PURCHASED_LOADER, payload: false });
                if (response?.status) {
                    dispatch({ type: SUBSCRIPTION_STATUS, payload: response?.data });
                } else {
                    Alert.alert(CommonStrings.AppName, String(response?.message))
                }
            } catch (error) {
                dispatch({ type: SUBSCRIPTION_PURCHASED_LOADER, payload: false });
                dispatch({ type: SUBSCRIPTION_STATUS, payload: null });
                Alert.alert(CommonStrings.AppName, String(error?.message))
            }
        };
    }
};

