import {
  SET_EDITPROFILE_LOADER,
  SET_EDITPROFILE,
  USER_PROFILE,
  SET_PROFILE_USER,
  USER_PROFILE_SUCCESS,
  SIGNUP_CREDENTIALS,
  SIGNUP_SUCCESS,
  SET_LOGIN_CREDENTIAL,
  OTP_VERIFIED,
  SIGNUP_ROLE_SUCCESS,
  OTP_RESEND_SUCCESS,
  EXIST_EMAIL_DATA,
  SET_REGISTRATION_LOADER,
  SET_OTP_LOADER,
  SET_LOGIN_LOADER,
  SET_FORGET_PASSWORD_LOADER,
  SET_RESET_PASSWORD_LOADER,
  SET_FORGET_PASSWORD_SUCCESS,
  SET_RESET_PASSWORD_SUCCESS,
  SET_NETWORK_STATE,
  SET_IS_STORE,
  VENDOR_REQUEST_LOADER,
  VENDOR_REQUESTED_INFO,
  SET_DEFAULT_AUTH_SCREEN,
  SET_USER_ID_RESET_PASSWORD,
  SET_VERIFICAITON_STATUS,
  SET_CREATE_STORE_INFO,
  SET_VERIFICAITON_STEPS,
  GET_WALLET_DATA,
  GET_DEPOSIT_DATA,
  GET_NEWS_DATA,
  GET_STOCK_DATA,
  SEARCH_NEWS_DATA

} from '../actions/ActionTypes';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import { Api, CommonStrings, Utilise } from '../../common';
import { setStoreAutofilInfo } from './Vendor';
import NetInfo from "@react-native-community/netinfo";
import { StackActions } from '@react-navigation/native';

//Set Network Connection
export const setNetworkConnection = (networkState) => {
  return async (dispatch, getState) => {
    dispatch({ type: SET_NETWORK_STATE, payload: networkState });
  }
}

export const walletBalance = () => {
  return async (dispatch, getState) => {
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: GET_WALLET_DATA, payload: [] });
        let response = await Utilise.apiCalling('GET', Api.walletBalance);
        
        if (response?.status) {
          dispatch({ type: GET_WALLET_DATA, payload: response.data });
         
        }
      } catch (error) {
       
      }
    };
  }
};

export const getDepositDetail = () => {
  return async (dispatch, getState) => {
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: GET_DEPOSIT_DATA, payload: [] });
        let response = await Utilise.apiCalling('GET', Api.getDepositDetail);
        
        if (response?.status) {
          dispatch({ type: GET_DEPOSIT_DATA, payload: response.data });
         
        }
      } catch (error) {
       
      }
    };
  }
};


export const searchNews = (data) => {
  return async (dispatch, getState) => {
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SEARCH_NEWS_DATA, payload: [] });
        let response = await Utilise.apiCalling('POST', `${Api.searchNews}`, data);

        // Check the status field in your API response if it exists
        // if (response?.status === 'success') {
          dispatch({ type: SEARCH_NEWS_DATA, payload: response.data });
        // } else {
          // Handle error cases, e.g., dispatch an error action or show a message
        //   console.error('Search news failed:', response?.error);
        // }
      } catch (error) {
        console.error('Error during news search:', error);
      }
    } else {
      // Handle the case when there is no internet connection
      console.error('No internet connection');
    }
  };
};

export const getNewsList = () => {
  return async (dispatch, getState) => {
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: GET_NEWS_DATA, payload: [] });
        let response = await Utilise.apiCalling('GET', Api.getNewsList);
        
        if (response?.status) {
          dispatch({ type: GET_NEWS_DATA, payload: response.data });
         
        }
      } catch (error) {
       
      }
    };
  }
};

export const stockListing = (data) => {
  return async (dispatch, getState) => {
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: GET_STOCK_DATA, payload: [] });
        let response = await Utilise.apiCalling('POST', Api.stockListing,data);
        
        if (response?.status) {
          dispatch({ type: GET_STOCK_DATA, payload: response.data });
         
        }
      } catch (error) {
       
      }
    };
  }
};
// export const getUser = () => {
//     try {
//         return async (dispatch, getState) => {
//             dispatch({ type: USER_PROFILE })
//             let response = await APIService(Api.getuser, 'get', false)
//             if (response.status == "200") {
//                 dispatch({ type: USER_PROFILE_SUCCESS, payload: response.data });
//             } else if (!response.data.status) {
//                 dispatch({ type: USER_PROFILE_FAILED, error: response.data.message })
//             } else {
//                 dispatch({ type: USER_PROFILE_FAILED, error: "Network Error" });
//             }
//         }
//     } catch (error) {
//     }
// }


// get User Profile Data
export const getUser = () => {

  return async (dispatch, getState) => {
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_PROFILE_USER, payload: [] });
        let response = await Utilise.apiCalling('GET', Api.getUser);

        
        // dispatch({ type: REDEEMED_COUPONS_LOADER, payload: false });
        if (response?.status) {
          dispatch({ type: SET_PROFILE_USER, payload: response.data });
          // } else {
          //     Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        // dispatch({ type: REDEEMED_COUPONS_LOADER, payload: false });
        // dispatch({ type: SET_REDEEMED_COUPONS, payload: [] });
        // Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};



//deletaccount
export const deletaccount = (userid, navigation) => {
  
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    let loginCredentials = await getState().auth?.loginCredentials;
    //loginCredentials?._id
    if (isInternetConnected) {
      try {

        let response = await Utilise.apiCalling('GET', `${Api.deletaccount}/${userid}`)

        if (response?.status) {
          alert("Account Deleted successfully.");
          dispatch(logout());

        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};




// LOGIN 
export const login = (loginCredentials, navigation) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_LOGIN_LOADER, payload: true });

        
        
        let response = await Utilise.apiCalling('POST', Api.login, loginCredentials);

        dispatch({ type: SET_LOGIN_LOADER, payload: false });

        if(response?.data?.isVerified == false){
          Alert.alert(CommonStrings.AppName, "Please verify your account before logging from email address.")  
        } else if (response?.status) {
          dispatch({ type: SET_VERIFICAITON_STEPS, payload: 2 })
          dispatch(changeLoginCredentials(response?.data,navigation));
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        dispatch({ type: SET_LOGIN_LOADER, payload: false });
        dispatch(changeLoginCredentials(null));
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    }
  };
};

// SIGNUP 
export const signup = (signupRequest, navigation, role) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: VENDOR_REQUEST_LOADER, payload: true });
        dispatch({ type: SET_REGISTRATION_LOADER, payload: true });

        let response = await Utilise.apiCalling('POST', Api.signup, signupRequest);
        dispatch({ type: SET_REGISTRATION_LOADER, payload: false });
        dispatch({ type: VENDOR_REQUEST_LOADER, payload: false });
        if (response?.status) {

          dispatch({ type: VENDOR_REQUESTED_INFO, payload: response.data });
          dispatch({ type: SIGNUP_CREDENTIALS, payload: response.data });

          if (navigation) {
            if (role === "vendor") {
              navigation.goBack();
              Alert.alert(CommonStrings.AppName, "Request sent successfully")
            } else {
              navigation.navigate("OTPVerification");
            }
          }
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
        dispatch({ type: SET_REGISTRATION_LOADER, payload: false });
        dispatch({ type: VENDOR_REQUEST_LOADER, payload: false });
      }
    }
  }
};



// Update Vendor 
export const signupVendor = (updateVendorRequest, navigation) => {
  return async (dispatch, getState) => {
    // let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        let url = Api.signup;
        dispatch({ type: SET_REGISTRATION_LOADER, payload: true });

        let response = await Utilise.apiCalling('POST', url, updateVendorRequest)
        

        dispatch({ type: SET_REGISTRATION_LOADER, payload: false });
        if (response?.status) {
          dispatch({ type: SIGNUP_CREDENTIALS, payload: response.data });
          Alert.alert(CommonStrings.AppName, 'Signup successful. Kindly verify your email')
          if (navigation) {
            navigation.navigate("Verification", { response: response.data });
          }
        } else {
          Alert.alert(CommonStrings.AppName, "Email Already Exist ")
        }
      } catch (error) {
        dispatch({ type: SET_REGISTRATION_LOADER, payload: false });
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};

//chnagemobileno
export const chnagemobileno = (Request, navigation) => {
  
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    let loginCredentials = await getState().auth?.loginCredentials;
    //loginCredentials?._id
    if (isInternetConnected) {
      try {

        let response = await Utilise.apiCalling('POST', `${Api.changeMobileno}`, Request)

        if (response?.status) {
          // Alert.alert(CommonStrings.AppName, String(response?.data?.charge?.message))
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};




// VERFY OTP 
export const verifyOtp = (otpCredentials, navigation, ) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;

    // Check if there's an internet connection
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_OTP_LOADER, payload: true }); // Dispatch loading action

        // Call the API to verify the OTP
        let response = await Utilise.apiCalling('POST', Api.verifyOTP, otpCredentials);
        

        dispatch({ type: SET_OTP_LOADER, payload: false }); // Dispatch loading action

          if (response.status == 200)  {
          // If the OTP is valid
          Alert.alert(CommonStrings.AppName,'Successfully Verified' );
            // Otherwise, navigate to the Verification screen
            navigation.navigate('Documentverification', { response: response.data });
        
        } else {
          // If the OTP is invalid, show an alert
          Alert.alert(CommonStrings.AppName, 'Invalid OTP!');
        }
      } catch (error) {
        // If an error occurs, show an alert with the error message
        Alert.alert(CommonStrings.AppName, String(error?.message));
        dispatch({ type: SET_OTP_LOADER, payload: false }); // Dispatch loading action
        dispatch({ type: OTP_VERIFIED, payload: false });
      }
    }
  };
};


export const verifyOtpForgot = (otpCredentials, navigation, isForgetPassword) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_OTP_LOADER, payload: true });
        let response = await Utilise.apiCalling('POST', Api.verifyOTP, otpCredentials);
        
        dispatch({ type: SET_OTP_LOADER, payload: false });
        if (response.status == 200) {
          dispatch(changeLoginCredentials(response?.data, navigation, 'forgot'));
        } else {
          Alert.alert(CommonStrings.AppName, String('Invalid OTP!'))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
        dispatch({ type: SET_OTP_LOADER, payload: false });
        dispatch({ type: OTP_VERIFIED, payload: false });
      }
    };
  }
};


export const verifyOtpForgotPassword = (otpCredentials, navigation, isForgetPassword) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_OTP_LOADER, payload: true });
        let response = await Utilise.apiCalling('POST', Api.verifyOTP, otpCredentials);
        
        dispatch({ type: SET_OTP_LOADER, payload: false });
        if (response.status == 200) {
          navigation.navigate("ResetPassword");
        } else {
          Alert.alert(CommonStrings.AppName, String('Invalid OTP!'))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
        dispatch({ type: SET_OTP_LOADER, payload: false });
        dispatch({ type: OTP_VERIFIED, payload: false });
      }
    };
  }
};

export const CheckEmail = (payload, navigation) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        let response = await Utilise.apiCalling('POST', Api.checkemail, payload);
        if (response.status == "200") {
          dispatch({ type: EXIST_EMAIL_DATA, payload: response || false });
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};

export const UpdateRole = (payload, navigation) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        let response = await Utilise.apiCalling('POST', Api.updaterole, payload);
        if (response.status == "200") {
          dispatch({ type: SIGNUP_ROLE_SUCCESS, payload: response || false });
          Alert.alert(CommonStrings.AppName, 'Registered successfully. Please Login with WallPon Username/Password.')
          navigation.dispatch(
            StackActions.replace('Login')
          );
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};

// RESEND OTP 
export const resendOtp = () => {
  return async (dispatch, getState) => {
    let signUpCredential = await getState().auth?.signupCredentials;
    let loginCredentials = await getState().auth?.loginCredentials;
    let isInternetConnected = await getState().auth?.isInternetConnected;
    let userId = signUpCredential?._id || loginCredentials?.userId
    if (isInternetConnected) {
      try {
        let response = await Utilise.apiCalling('POST', `${Api.resendOTP}?userId=${userId}`)
        if (response.status) {
          dispatch({ type: OTP_RESEND_SUCCESS, payload: response || false });
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
        dispatch({ type: OTP_RESEND_SUCCESS, payload: false });
      }
    };
  }
};

// FORGET PASSWORD
export const forgetPassword = (request, navigation) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_FORGET_PASSWORD_LOADER, payload: true });
        let response = await Utilise.apiCalling('POST', `${Api.forgotPassword}`, request);
        
        dispatch({ type: SET_FORGET_PASSWORD_LOADER, payload: false });
        if (response.status) {
          dispatch({ type: SET_FORGET_PASSWORD_SUCCESS, payload: response || false });
          dispatch({ type: SIGNUP_CREDENTIALS, payload: { _id: response?.data?.user_id } });
          dispatch({ type: SET_USER_ID_RESET_PASSWORD, payload: response?.data?.user_id });
          if (navigation) {
            navigation.dispatch(
              StackActions.replace('ResetPassword', { isForgetPassword: true })
            );
          }
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
        dispatch({ type: SET_FORGET_PASSWORD_SUCCESS, payload: false });
        dispatch({ type: SET_FORGET_PASSWORD_LOADER, payload: false });
      }
    };
  }
};

// RESET PASSWORD
export const resetPassword = (request, userId, navigation) => {
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_RESET_PASSWORD_LOADER, payload: true });
        let response = await Utilise.apiCalling('POST', `${Api.resetPassword}?userId=${userId}`, request)
        
        dispatch({ type: SET_RESET_PASSWORD_LOADER, payload: false });
        if (response.status ==200) {
          dispatch({ type: SET_RESET_PASSWORD_SUCCESS, payload: response || false });
          dispatch({ type: SET_DEFAULT_AUTH_SCREEN, payload: "Login" });
          dispatch(logout())
          NetInfo.fetch().then(state => {
            dispatch(setNetworkConnection(state.isConnected));
          });
          dispatch({ type: SET_DEFAULT_AUTH_SCREEN, payload: "Login" })
          if (navigation) {
            Alert.alert(CommonStrings.AppName, 'Password updated Successfully')
            navigation.dispatch(
              StackActions.replace('Login')
              
            );
          }
        } else {
          Alert.alert(CommonStrings.AppName, 'Enter Valid OTP')
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
        dispatch({ type: SET_RESET_PASSWORD_SUCCESS, payload: false });
        dispatch({ type: SET_RESET_PASSWORD_LOADER, payload: false });
      }
    };
  }
};

// CHANGE LOGIN CRENDENTIAL 
export const changeLoginCredentials = (loginCredentials, navigation, source) => {
  
  return async (dispatch, getState) => {
    global.authToken = loginCredentials?.token || null;

    await AsyncStorage.setItem('@loginCredential', JSON.stringify(loginCredentials));
    dispatch({ type: SET_LOGIN_CREDENTIAL, payload: loginCredentials });

    let verificationStatus = loginCredentials?.store?.verificationStatus
    dispatch({ type: SET_VERIFICAITON_STATUS, payload: 1 })
    dispatch({ type: SET_CREATE_STORE_INFO, payload: loginCredentials?.store });

    dispatch({ type: SET_VERIFICAITON_STEPS, payload: verificationStatus })

    await AsyncStorage.setItem('@storeInfo', JSON.stringify(loginCredentials?.store));

    navigation.navigate("Coupons");

    // if(source=='forgot') {
    //   navigation.navigate("Coupons");
    // } else {
    //   navigation.navigate("VerificationForm");
    // }        
  };
};



// LOGOUT  
export const logout = () => {
  return async (dispatch, getState) => {
    dispatch({ type: "USER_LOGOUT", payload: null });
    global.authToken = null;
    let loginDetail = await AsyncStorage.getItem('@rememberMe');
    await AsyncStorage.clear();
    if (loginDetail && loginDetail !== null) {
      await AsyncStorage.setItem('@rememberMe', loginDetail);
    }
  };
};

export const updateProfile = (payload, navigation) => {
  
  return async (dispatch, getState) => {
    let isInternetConnected = await getState().auth?.isInternetConnected;
    if (isInternetConnected) {
      try {
        dispatch({ type: SET_EDITPROFILE_LOADER, payload: true });
        let response = await Utilise.apiCalling('POST', Api.edituserads, payload);
        
        dispatch({ type: SET_EDITPROFILE_LOADER, payload: false });
        if (response.status == "200") {
          dispatch({ type: SET_EDITPROFILE, payload: response || false });
          // dispatch(changeLoginCredentials(response?.data, navigation));
          Alert.alert(CommonStrings.AppName, 'Saved successfully.')
          navigation.dispatch(
            StackActions.replace('Profile')
          );
        } else {
          Alert.alert(CommonStrings.AppName, String(response?.message))
        }
      } catch (error) {
        Alert.alert(CommonStrings.AppName, String(error?.message))
      }
    };
  }
};



// Submit verification detail OTP 
export const submitverificationData = (verificationCredentials, navigation, ) => {
  return async (dispatch, getState) => {
      try {
        let response = await Utilise.apiCalling('POST', Api.verificationSubmit, verificationCredentials);
          
      } catch (error) {
        //navigation.navigation.navigate('Login')
      }
  }
}

// Submit verification detail OTP 
export const submitverificationData2 = (verificationCredentials, navigation, ) => {
  console.log('verificationCredentials',verificationCredentials)
  return async (dispatch, getState) => {
      try {
        let response = await Utilise.apiCalling('POST', Api.verificationSubmit, verificationCredentials);
          if (response.status == 200)  {
            Alert.alert(CommonStrings.AppName,'Verification details submitted successfully' );
            navigation.navigate('Login')
        } else {
          navigation.navigate('Login')
        }
      } catch (error) {
        navigation.navigate('Login')
      }
  }
}
