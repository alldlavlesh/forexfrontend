const assetsRootPath = '../res/assets/'

const assetsRootPath1 = '../res/'


const ds_logo_512 = require(`${assetsRootPath}ds_logo_512.png`);
const greenmark = require(`${assetsRootPath}greenmark.png`);
const duplicate = require(`${assetsRootPath}duplicate.png`);
const BusinessServiceIcon = require(`${assetsRootPath}BusinessServiceIcon.png`);
const cover = require(`${assetsRootPath}curve.png`);
const profi = require(`${assetsRootPath}profile.png`);
const fq = require(`${assetsRootPath}faq.png`);
const veriIcon = require(`${assetsRootPath}veriIcon.png`);
const edit_icon1 = require(`${assetsRootPath}edit_icon1.png`);
const wallponLogo = require(`${assetsRootPath}wallpon.png`);
const venderIcon = require(`${assetsRootPath}vender_icon.png`);
const earningIcon = require(`${assetsRootPath}earning_icon.png`);
const loginBgIcon = require(`${assetsRootPath}login_bg_icon.png`);
const registrationBgIcon = require(`${assetsRootPath}registration_bg_icon.png`);
const wallponCouponLogo = require(`${assetsRootPath}wallpon_coupon_logo.png`);
const backIcon = require(`${assetsRootPath}back_icon.png`);
const backarrow = require(`${assetsRootPath}backarrow.png`);
const eyeIcon = require(`${assetsRootPath}eye_icon.png`);
const eyeIconHide = require(`${assetsRootPath}eye_icon_hide.png`);
const locationIcon = require(`${assetsRootPath}location_icon.png`);
const searchIcon = require(`${assetsRootPath}search_icon.png`);
const wallponLogoHorizontal = require(`${assetsRootPath}wallpon_logo_horizontal.png`);
const logoutIcon = require(`${assetsRootPath}logout_icon.png`);
const menuIcon = require(`${assetsRootPath}menu_icon.png`);
const bankBuildingIcon = require(`${assetsRootPath}bank_building_icon.png`);
const accountIcon = require(`${assetsRootPath}account_icon.png`);
const insightsIcon = require(`${assetsRootPath}insights_icon.png`);
const noteIcon = require(`${assetsRootPath}note_icon.png`);
const listIcon = require(`${assetsRootPath}list_icon.png`);
const homeIcon = require(`${assetsRootPath}home_icon.png`);
const addIcon = require(`${assetsRootPath}add_icon.png`);
const calendarIcon = require(`${assetsRootPath}calendar_icon.png`);
const noVendorIcon = require(`${assetsRootPath}noVendor_icon.png`);
const dropDownIcon = require(`${assetsRootPath}drop_down_icon.png`);
const nextIcon = require(`${assetsRootPath}next_icon.png`);
const infoIcon = require(`${assetsRootPath}info_icon.png`);
const downArrow = require(`${assetsRootPath}down_arrow.png`);
const envelopeIcon = require(`${assetsRootPath}envelope_icon.png`);
const callIcon = require(`${assetsRootPath}call_icon.png`);
const editIcon = require(`${assetsRootPath}edit_icon.png`);
const viewIcon = require(`${assetsRootPath}view_icon.png`);
const closeIcon = require(`${assetsRootPath}close_icon.png`);
const social1 = require(`${assetsRootPath}social1.png`);
const social2 = require(`${assetsRootPath}social2.png`);
const social3 = require(`${assetsRootPath}social3.png`);
const social4 = require(`${assetsRootPath}social4.png`);
const social5 = require(`${assetsRootPath}social5.png`);
const social6 = require(`${assetsRootPath}social6.png`);
const social7 = require(`${assetsRootPath}social7.png`);
const social8 = require(`${assetsRootPath}social8.png`);
const social9 = require(`${assetsRootPath}social9.png`);
const social10 = require(`${assetsRootPath}social10.png`);
const social11 = require(`${assetsRootPath}social11.png`);
const social12 = require(`${assetsRootPath}social12.png`);
const social13 = require(`${assetsRootPath}social13.jpg`);
const social14 = require(`${assetsRootPath}social14.jpg`);
const social15 = require(`${assetsRootPath}social15.png`);
const pro1 = require(`${assetsRootPath}pro1.png`);
const pro2 = require(`${assetsRootPath}pro2.png`);
const pro3 = require(`${assetsRootPath}pro3.png`);
const pro4 = require(`${assetsRootPath}pro4.png`);
const detailbacground = require(`${assetsRootPath}detailbacground.png`);

const prof = require(`${assetsRootPath}profile.png`);




//BANKS
// const _2coBankIcon = require(`${assetsRootPath}2co_bank_icon.png`);
// const americalExpressBankIcon = require(`${assetsRootPath}americal_express_bank_icon.png`);
// const centraliBankIcon = require(`${assetsRootPath}centrali_bank_icon.png`);
// const citiBankIcon = require(`${assetsRootPath}citi_bank_icon.png`);
// const clickBankIcon = require(`${assetsRootPath}click_bank_icon.png`);
// const discoverBankIcon = require(`${assetsRootPath}discover_bank_icon.png`);
// const eBankIcon = require(`${assetsRootPath}e_bank_icon.png`);
// const jcbBankIcon = require(`${assetsRootPath}jcb_bank_icon.png`);
// const charteredBankIcon = require(`${assetsRootPath}chartered_bank_icon.png`);
//COUPONS
// const bagIcon = require(`${assetsRootPath}bag_icon.png`);
// const cartIcon = require(`${assetsRootPath}cart_icon.png`);
// const fruitBasketIcon = require(`${assetsRootPath}fruit_basket_icon.png`);
// const groceriesIcon = require(`${assetsRootPath}groceries_icon.png`);
const stock = require(`${assetsRootPath}stock.png`);
const ICON = require(`${assetsRootPath}ICON.png`);
const Dot = require(`${assetsRootPath}Dot.png`);
const Support = require(`${assetsRootPath}Support.png`);
const Invite = require(`${assetsRootPath}Invite.png`);
const Cup = require(`${assetsRootPath}Cup.png`);
const AML = require(`${assetsRootPath}AML.png`);
const NFT = require(`${assetsRootPath}NFT.png`);
const Staking = require(`${assetsRootPath}Staking.png`);
const Refresh = require(`${assetsRootPath}Refresh.png`);
const Withdraw = require(`${assetsRootPath}Withdraw.png`);
const Base = require(`${assetsRootPath}Base.png`);
const Banner = require(`${assetsRootPath}Banner.png`);
const Deposit = require(`${assetsRootPath}Deposit.png`);
const Recieved = require(`${assetsRootPath}Recieved.png`);
const pathRight = require(`${assetsRootPath}pathRight.png`);
const down = require (`${assetsRootPath}down.png`);
const Fill = require(`${assetsRootPath}Fill.png`);
const home = require(`${assetsRootPath}home.png`);
const Market = require(`${assetsRootPath}Market.png`); 
const Swap = require(`${assetsRootPath}Swap.png`);
const Dollar = require (`${assetsRootPath}Dollar.png`);
const circle =require (`${assetsRootPath}circle.png`);
const Refferalframe =require (`${assetsRootPath}Refferalframe.png`);
const Man = require (`${assetsRootPath}Man.png`);
const F_wallet = require(`${assetsRootPath}F_wallet.png`);
const Rest =require(`${assetsRootPath}Rest.png`);
const foreximg =require(`${assetsRootPath}foreximg.png`);
const F_Profile = require(`${assetsRootPath}F_Profile.png`);image
const Google = require(`${assetsRootPath}Google.png`);
const Microsoft = require(`${assetsRootPath}Microsoft.png`);
const Nike = require(`${assetsRootPath}Nike.png`);
const Spotify = require(`${assetsRootPath}Spotify.png`);
const Twitter = require(`${assetsRootPath}Twitter.png`);
const image = require(`${assetsRootPath}image.png`);
const Chart = require(`${assetsRootPath}Chart.png`);
const Chart1 = require(`${assetsRootPath}Chart1.png`);
const Chart2 = require(`${assetsRootPath}Chart2.png`);
const Chart3 = require(`${assetsRootPath}Chart3.png`);
const Chart4 = require(`${assetsRootPath}Chart4.png`);
const search = require(`${assetsRootPath}search.png`); 
const Fprofile = require(`${assetsRootPath}Fprofile.png`);
const faq1 = require(`${assetsRootPath}faq1.png`);
const settings = require(`${assetsRootPath}settings.png`);
const language = require(`${assetsRootPath}language.png`);
const about_Icon = require(`${assetsRootPath}about_Icon.png`);
const Gift = require(`${assetsRootPath}Gift.png`); 
const Chevron_Right = require(`${assetsRootPath}Chevron-Right.png`);
const feedback = require(`${assetsRootPath}feedback.png`);
const next_icon = require(`${assetsRootPath}next_icon.png`); 
const image_icon = require(`${assetsRootPath}image_icon.png`);
const bg = require(`${assetsRootPath}bg.png`);
const Path_back = require(`${assetsRootPath}Path_back.png`); 
const Notification = require(`${assetsRootPath}Notification.png`); 
const Chart_buysell = require(`${assetsRootPath}Chart_buysell.png`);



const couponIcon = require(`${assetsRootPath}coupon_icon.png`);
const noCouponIcon = require(`${assetsRootPath}no_coupon_icon.png`);
const cropImageBg = require(`${assetsRootPath}cropImage_bg.png`);
const couponLabelIcon = require(`${assetsRootPath}coupon_label.png`);
const subscriptionIcon = require(`${assetsRootPath}subscription_icon.png`);

 const bottomplus = require(`${assetsRootPath}bottomplus.png`);
 const MenuTabIcon = require(`${assetsRootPath}menu_ic.png`);
 const CouponTabIcon = require(`${assetsRootPath}coupon_ic.png`);
const footerbackground = require(`${assetsRootPath}footerbackground.png`);
const listbackground = require(`${assetsRootPath}listbackground.png`);
const Line = require(`${assetsRootPath}Line.png`);
const locations = require(`${assetsRootPath}Group.png`);
const calculater = require(`${assetsRootPath}calculater.png`);
const Calculator = require(`${assetsRootPath}Calculator.png`);
const shareicon = require(`${assetsRootPath}shareicon.png`);
const globe = require(`${assetsRootPath}globe.png`);
const phone = require(`${assetsRootPath}phone.png`);
const Linevertical = require(`${assetsRootPath}Linevertical.png`);
const crossx = require(`${assetsRootPath}crossx.png`);
const video = require(`${assetsRootPath}video.png`);
const changeimage = require(`${assetsRootPath}changeimage.png`);
const seee_more_icon = require(`${assetsRootPath}seee_more_icon.png`);
const locationsingle = require(`${assetsRootPath}locationsingle.png`);
const reviewrating = require(`${assetsRootPath}reviewrating.png`);
const landing_img = require(`${assetsRootPath}landing_img.png`);
const landing_img2 = require(`${assetsRootPath}landing_img2.png`);
const landing_img3 = require(`${assetsRootPath}landing_img3.png`);
const landing_img4 = require(`${assetsRootPath}landing_img4.png`);
const dots_img = require(`${assetsRootPath}dots_img.png`);
const line_img = require(`${assetsRootPath}line_img.png`);
const menu_Icons = require(`${assetsRootPath}menu_Icons.png`);
const Notification_image = require(`${assetsRootPath}Notification_image.png`);
const message_three = require(`${assetsRootPath}message_three.png`);
const galleryImage = require(`${assetsRootPath}galleryImage.png`);
const BitcoinBadge = require(`${assetsRootPath}BitcoinBadge.png`);
const BitcoinBadge2 = require(`${assetsRootPath}BitcoinBadge2.png`);
const TrustWallet = require(`${assetsRootPath}TrustWallet.png`);
const TetherGoldBadge = require(`${assetsRootPath}TetherGoldBadge.png`);
const homeimg = require(`${assetsRootPath}homeimg.png`);
const arrowleftright = require(`${assetsRootPath}arrowleftright.png`);
const Medium = require(`${assetsRootPath}Medium.png`);
const Medium1 = require(`${assetsRootPath}Medium1.png`);
const Medium3 = require(`${assetsRootPath}Medium3.png`);
const tabbar = require(`${assetsRootPath}tabbar.png`);
const Navigation = require(`${assetsRootPath}Navigation.png`);
const Extra = require(`${assetsRootPath}Extra.png`);
const Extra1 = require(`${assetsRootPath}Extra1.png`);
const Extra2 = require(`${assetsRootPath}Extra2.png`);
const script = require(`${assetsRootPath}script.png`);
const vector = require(`${assetsRootPath}vector.png`);
const arrow_down = require(`${assetsRootPath}arrow_down.png`);
const arrow_left = require(`${assetsRootPath}arrow_left.png`);
const MetaMaskBadge = require(`${assetsRootPath}MetaMaskBadge.png`);
const coinPayment = require(`${assetsRootPath}coinPayment.png`);
const multitasking = require(`${assetsRootPath}multitasking.png`);
const Ellipse = require(`${assetsRootPath}Ellipse.png`);
const Ellipse_top_keyboard = require(`${assetsRootPath}Ellipse_top_keyboard.png`);
const Rectangle = require(`${assetsRootPath}Rectangle.png`);
const Path = require(`${assetsRootPath}Path.png`);
const Shape = require(`${assetsRootPath}Shape.png`);
const GroupUser = require(`${assetsRootPath}GroupUser.png`);
const Share = require(`${assetsRootPath}Share.png`);
const user_support = require(`${assetsRootPath}user_support.png`);
const PathOn = require(`${assetsRootPath}PathOn.png`);
const Rectangle2 = require(`${assetsRootPath}Rectangle2.png`);
const Rectangle4 = require(`${assetsRootPath}Rectangle4.png`);
const Base1 = require(`${assetsRootPath}Base1.png`);
const editcolor = require(`${assetsRootPath}editcolor.png`);
const Rectanglebox = require(`${assetsRootPath}Rectanglebox.png`);
const dollar_icon = require(`${assetsRootPath}dollar_icon.png`);
const arrow_login = require(`${assetsRootPath}arrow_login.png`);
const filter_icon = require(`${assetsRootPath}filter_icon.png`);
const dropdown = require(`${assetsRootPath}dropdown.png`);
const Copy = require(`${assetsRootPath}Copy.png`);
const refferFriend = require(`${assetsRootPath}refferFriend.png`);
const copy_icon = require(`${assetsRootPath}copy_icon.png`);
const technical_support = require(`${assetsRootPath}technical_support.png`);
const Dailycoupon = require(`${assetsRootPath}Dailycoupon.png`);
const withdraw_amount = require(`${assetsRootPath}withdraw_amount.png`);
const transaction_icon = require(`${assetsRootPath}transaction_icon.png`);
const Vector_img = require(`${assetsRootPath}Vector_img.png`);
const Vector_ticon = require(`${assetsRootPath}Vector_ticon.png`);
const Ellipse_welcome = require(`${assetsRootPath}Ellipse_welcome.png`);
const Ellipse_login = require(`${assetsRootPath}Ellipse_login.png`);
const Pngtree = require(`${assetsRootPath}Pngtree.png`);
const Ellipse_bottom = require(`${assetsRootPath}Ellipse_bottom.png`);
const wallet = require(`${assetsRootPath}wallet.png`);
const withdrawmoney = require(`${assetsRootPath}withdrawmoney.png`);
const depost_red = require(`${assetsRootPath}depost_red.png`);
const referral_red = require(`${assetsRootPath}referral_red.png`);
const referral_white = require(`${assetsRootPath}referral_white.png`);
const profit_red = require(`${assetsRootPath}profit_red.png`);
const profit_white = require(`${assetsRootPath}profit_white.png`);
const withdraw_red = require(`${assetsRootPath}withdraw_red.png`);
const withdraw_white = require(`${assetsRootPath}withdraw_white.png`);
const downarrow_img = require(`${assetsRootPath}downarrow_img.png`);
const upi_logo = require(`${assetsRootPath}upi_logo.png`);
const upi_logo_small = require(`${assetsRootPath}upi_logo_small.png`);
const usdt_img = require(`${assetsRootPath}usdt_img.png`);
const network = require(`${assetsRootPath}network.png`);
const network1 = require(`${assetsRootPath}network1.png`);
const refreshcaptcha = require(`${assetsRootPath}rotate_image.png`);
const whatsapp =  require(`${assetsRootPath}whatsapp.png`);
const email =  require(`${assetsRootPath}email.png`);
const arrow_both = require (`${assetsRootPath}arrow_both.png`);
const stevs_forex_patience_strategy_1 =require (`${assetsRootPath}stevs_forex_patience_strategy_1.png`);
const stevs_forex_patience_strategy_4 = require (`${assetsRootPath}stevs_forex_patience_strategy_4.png`);
const Frame= require (`${assetsRootPath}Frame.png`);
const Frame_71 = require (`${assetsRootPath}Frame_71.png`);
const whitecircle = require (`${assetsRootPath}whitecircle.png`);
const Line_2 = require (`${assetsRootPath}Line_2.png`);
const Handollar = require (`${assetsRootPath}Handollar.png`);
const Hand = require (`${assetsRootPath}Hand.png`);
const Plus = require (`${assetsRootPath}Plus.png`);
const Polygon_4 =require (`${assetsRootPath}Polygon_4.png`);
const Icon_7 = require (`${assetsRootPath}Icon_7.png`);
const Path_1 = require(`${assetsRootPath}Path_1.png`);
const right = require(`${assetsRootPath}right.png`)
const upArrow = require(`${assetsRootPath}up-arrow.png`);
const checkmark3 =require(`${assetsRootPath}checkmark3.png`);

const Iconpath =require(`${assetsRootPath1}Icon.png`);
const Idcardpath =require(`${assetsRootPath1}id-card.png`);
const Passportpath =require(`${assetsRootPath1}passport-svgrepo.png`);
const IconSelfiepath =require(`${assetsRootPath1}id-card-identification.png`);
const onesel =require(`${assetsRootPath1}onesel.png`);
const twosel =require(`${assetsRootPath1}twosel.png`);
const threesel =require(`${assetsRootPath1}threesel.png`);




const ImageIcons = {
  ICON,
  Iconpath,
  Idcardpath,
  Passportpath,
  IconSelfiepath,
  onesel,
  twosel,
  threesel,
  Dot,
  arrow_both,
  stock,
  Support,
  Invite,
  Cup,
  AML,
  NFT,
  Staking,
  Refresh,
  Withdraw,
  Banner,
  Recieved,
  Deposit,
  pathRight,
  Dollar,
  Copy,
  Base,
  Rest,
  foreximg,
  Refferalframe,
  circle,
  Man,
  down,
  stevs_forex_patience_strategy_1,
  stevs_forex_patience_strategy_4,
  Fill,
  home,
  Market,
  Swap,
  F_wallet,
  F_Profile,
  image,
  Google,
  Microsoft,
  Nike,
  Spotify,
  Twitter,
  Chart,
  Chart1,
  Chart2,
  Chart3,
  Chart4,
  search,
  Fprofile,
  faq1,
  settings,
  language,
  about_Icon,
  Gift,
  Chevron_Right,
  feedback,
  next_icon,
  image_icon,
  bg,
  Path_back,
  Notification,
  Chart_buysell,
  

  email,
  whatsapp,
  refreshcaptcha,
  ds_logo_512,
  Ellipse_top_keyboard,
  upi_logo,
  upi_logo_small,
  usdt_img,
  network1,
  network,
  downarrow_img,
  bottomplus,
  withdraw_white,
  withdraw_red,
  profit_white,
  depost_red,
  profit_red,
  referral_white,
  referral_red,
  withdrawmoney,
  Shape,
  wallet,
  Ellipse_login,
  Ellipse_bottom,
  Ellipse_welcome,
  Pngtree,
  Vector_img,
  transaction_icon,
  copy_icon,
  Vector_ticon,
  withdraw_amount,
  arrow_login,
  editcolor,
  Base1,
  Dailycoupon,
  filter_icon,
  Rectangle2,
  Rectangle4,
  Share,
  refferFriend,
  dropdown,
  Rectanglebox,
  technical_support,
  PathOn,
  user_support,
  GroupUser,
  Ellipse,
  dollar_icon,
  Path,
  Medium3,
  Rectangle,
  coinPayment,
  multitasking,
  Line,
  Navigation,
  arrow_down,
  Medium1,
  vector,
  Extra1,
  Extra2,
  arrow_left,
  script,
  Extra,
  tabbar,
  message_three,
  video,
  homeimg,
  BitcoinBadge2,
  Medium,
  arrowleftright,
  TetherGoldBadge,
  galleryImage,
  Notification_image,
  menu_Icons,
  BitcoinBadge,
  TrustWallet,
  crossx,
  Linevertical,
  globe,
  phone,
  dots_img,
  landing_img,
  landing_img2,
  landing_img3,
  landing_img4,
  changeimage,
  line_img,
  locations,
  shareicon,
  reviewrating,
  calculater,
  Calculator,
  seee_more_icon,
  listbackground,
  CouponTabIcon,
  MenuTabIcon,
  footerbackground,
  wallponLogo,
  pro1,
  pro2,
  pro3,
  pro4,
  MetaMaskBadge,
  venderIcon,
  edit_icon1,
  earningIcon,
  loginBgIcon,
  registrationBgIcon,
  wallponCouponLogo,
  backIcon,
  eyeIcon,
  eyeIconHide,
  locationIcon,
  searchIcon,
  wallponLogoHorizontal,
  logoutIcon,
  menuIcon,
  bankBuildingIcon,
  accountIcon,
  insightsIcon,
  noteIcon,
  listIcon,
  homeIcon,
  addIcon,
  locationsingle,
  calendarIcon,
  detailbacground,
  noVendorIcon,
  dropDownIcon,
  nextIcon,
  infoIcon,
  downArrow,
  envelopeIcon,
  callIcon,
  editIcon,
  viewIcon,
  closeIcon,
  //banks
  // _2coBankIcon,
  // americalExpressBankIcon,
  // centraliBankIcon,
  // citiBankIcon,
  // clickBankIcon,
  // discoverBankIcon,
  // eBankIcon,
  // jcbBankIcon,
  // charteredBankIcon,
  //coupons
  // bagIcon,
  // cartIcon,
  // fruitBasketIcon,
  // groceriesIcon,
  couponIcon,
  noCouponIcon,
  cropImageBg,
  couponLabelIcon,
  subscriptionIcon,
  fq,
  profi,
  veriIcon,
  cover,
  duplicate,
  greenmark,
  BusinessServiceIcon,
  backarrow,
  social1,
  social2,
  social3,
  social4,
  social5,
  social6,
  social7,
  social8,
  social9,
  social10,
  social11,
  social12,
  social13,
  social14,
  social15,
  Frame,
  Frame_71,
  whitecircle,
  Line_2,
  Handollar,
  Hand,
  Plus,
  Polygon_4,
  Icon_7,
  Path_1,
  right,
  upArrow,
  prof,
  checkmark3
};
export default ImageIcons;
