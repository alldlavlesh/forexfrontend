const RalewayExtraBold = "Raleway-ExtraBold"; //similar GothamBold
const QuestrialRegular = "Questrial-Regular"; //  similar GothamBook //Raleway-Medium  //Raleway-Regular
const RalewaySemiBold = "Raleway-SemiBold";  // similar GothamMedium
const RalewayLight = "Raleway-Light";
const RalewayThin = "Raleway-Thin";
const SfproSemibold = "SFProText-Semibold";
const HomepageBaukastenBold = "HomepageBaukasten-Bold"; // Number

export default Fonts = {
    RalewayExtraBold,
    QuestrialRegular,
    RalewaySemiBold,
    RalewayLight,
    RalewayThin,
    SfproSemibold,
    HomepageBaukastenBold
}