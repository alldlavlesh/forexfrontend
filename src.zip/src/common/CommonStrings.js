

const CommonStrings={
    AppName:"Forex"
}

export default CommonStrings;

