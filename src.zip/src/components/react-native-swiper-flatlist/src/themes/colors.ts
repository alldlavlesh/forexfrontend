export const colors = {
  white: '#FFFFFF',
  gray: 'gray',
};
