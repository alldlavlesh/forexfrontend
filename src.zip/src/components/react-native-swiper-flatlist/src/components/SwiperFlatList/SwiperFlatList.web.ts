const { SwiperFlatList: SwiperFlatListBase } = require('./SwiperFlatList.tsx');

export const SwiperFlatList = SwiperFlatListBase;
