import React, { useRef } from 'react';
import { Image, TextInput, TouchableOpacity, View } from 'react-native';
import styles from './styles';
import { ImageIcons, Colors } from '../../../common'

const SearchBar = ({ ...others }) => {
  
  //References
  const searchRef = useRef();

  return (
    <View style={styles.vendorSearchContainer}>
      <TouchableOpacity onPress={() => searchRef.current?.focus()}>
        <Image source={ImageIcons.searchIcon} style={{ width: 15, height: 15, tintColor: Colors.GREY, resizeMode: 'contain', marginLeft:5 }} />
      </TouchableOpacity>
      <TextInput
        ref={(ref) => searchRef.current = ref}
        style={styles.searchInput}
        {...others}
      />
    </View>
  )
}

export default SearchBar;