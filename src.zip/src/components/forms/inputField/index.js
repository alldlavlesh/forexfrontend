import React from 'react';
import { Text, Image, TextInput, View, TouchableOpacity } from 'react-native';
import { Colors } from '../../../common'
import styles from './styles';

const InputField = ({ customStyle, id, title, leftIcon, rightIcon, iconTintColor, passwordToogle, textStyle, theme, disable,numberOfLines, inputHeight, rightLabel, onRightLinkPress, reference, customInputStyle,customOuterStyle,multiline, ...others }) => {
    return (
        <View style={styles.root} key={id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={[styles.title, { color: theme === "white" ? '#323435' : Colors.WHITE }, textStyle]}>{title}</Text>
                {rightLabel &&
                    <Text onPress={onRightLinkPress} style={[styles.rightTitle, { color: theme === "white" ? Colors.BLACK : Colors.WHITE }, textStyle]}>{rightLabel}</Text>
                }
            </View>
            <View style={[styles.inputContainer,
            {
                backgroundColor: theme === "white" ? '#f2f2f2' : '#767676',
                borderColor: '#f2f2f2',
                borderWidth: theme === "white" ? 0.5 : 0,
                height: inputHeight || 50
            },customOuterStyle]}>
                {
                    leftIcon &&
                    <View style={[styles.iconContainer, { height: 40, justifyContent: 'center' }]}>
                        <Text style={styles.leftIcon}>{leftIcon}</Text>
                    </View>
                }
                <TextInput
                    ref={reference}
                    editable={!disable || true}
                    autoCapitalize="none"
                    placeholderTextColor={Colors.LIGHT_GREY}
                    numberOfLines={ numberOfLines!=''? numberOfLines : 1}
                    multiline={multiline}
                    style={[styles.input, customInputStyle, { color: theme === "white" ? disable ? Colors.GREY : Colors.BLACK : Colors.WHITE}]}
                    {...others}
                />
                {
                    rightIcon &&
                    <TouchableOpacity onPress={passwordToogle} style={styles.iconContainer}>
                        <Image
                            source={rightIcon}
                            style={[styles.icon, iconTintColor && { tintColor: iconTintColor }]}
                        />
                    </TouchableOpacity>
                }
            </View>
        </View>
    )
}

export default InputField;