import React, {useState, useRef} from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Colors, Fonts } from '../../../common'
import PhoneInput from "react-native-phone-number-input";
import TextInputMask from 'react-native-text-input-mask';
import styles from './styles';


const PhoneMaskInput = ({ id, theme, onCountryChange,onCountryCodeChange, onChangePhone, defaultValue, reference, title , ...others }) => {
    const phoneInput1 = useRef(null);
    return (
        <View style={{
            marginHorizontal: 40,        
        }}>
            <Text style={[styles.phoneTitle, { color: theme === "black" ? Colors.WHITE : Colors.BLACK }]}>{ title ? title : ""}</Text>
            <View style={[styles.formattedView, { backgroundColor: theme === "black" ? Colors.LIGHT_BLACK : Colors.WHITE, borderWidth: theme === "black" ? 0 : 1 }]}>
                <PhoneInput
                    ref={phoneInput1}
                    key={id}
                    // disableArrowIcon={true}
                    // onChangeCountry={(countryCode) => onCountryChange(countryCode)}
                    onChangeFormattedText={(countryCode) => {
                        // onCountryChange(countryCode);
                        onCountryCodeChange(phoneInput1.current?.getCountryCode() || '');
                    }}
                    containerStyle={[styles.phoneContainer, { backgroundColor: theme === "black" ? Colors.LIGHT_BLACK : Colors.WHITE }]}
                    codeTextStyle={{
                        color: theme === "black" ? Colors.WHITE : Colors.LIGHT_BLACK,
                        width: '100%',
                        paddingLeft: '20%'
                    }}
                    {...others}
                // autoFocus
                />
                <TextInputMask
                    ref={reference}
                    returnKeyType="next"
                    style={[styles.inputmask, {
                        backgroundColor: theme === "black" ? Colors.LIGHT_BLACK : Colors.WHITE,
                        color: theme === "black" ? Colors.WHITE : Colors.BLACK, fontSize: 14,
                        flex: 1
                    }]}
                    value={defaultValue}
                    onChangeText={(formatted, extracted) => onChangePhone(extracted)}
                    mask={"[000] [000] [0000]"}
                    placeholder="000 000 0000"
                    placeholderTextColor={'#C7C7CD'}
                    keyboardType="numeric"
                    selectionColor={'#C20A33'}
                />
            </View>
        </View>
    )
}

export default PhoneMaskInput;