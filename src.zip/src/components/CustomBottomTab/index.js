import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, Dimensions, View, ImageBackground, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, Fonts, ImageIcons, Images } from '../../common';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import tw from 'twrnc';

const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

// const BottomTabRoute = () => {
//     return (
//         <Tab.Navigator initialRouteName="Home" tabBar={props => <CustomBottomTab {...props} />} >
//             <Tab.Screen
//                 name="Home"
//                 component={DashboardNavigation}
//                 options={{
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.HomeTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text style={[styles.label, { color: focused ? Colors.green : Colors.black }]}>Coupons</Text>
//                 }}
//             />
//             <Tab.Screen
//                 name="Coupons"
//                 component={Coupons}
//                 options={{
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.CouponTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text style={[styles.label, { Colors: focused ? Colors.green : Colors.black }]}>Coupons</Text>
//                 }}
//             />
//             <Tab.Screen
//                 name="CreateFeed"
//                 component={CreateFeedCommon}
//                 options={{
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.PlusTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text style={[styles.label, { color: focused ? Colors.green : Colors.black }]}>Post</Text>
//                 }}
//             />
//             <Tab.Screen
//                 name="Menu"
//                 component={MenuScreen}
//                 options={({ navigation }) => ({
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.MenuTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text onPress={() => navigation.toggleDrawer()} style={[styles.label, { color: focused ? Colors.green : Colors.black }]}>Coupons</Text>,
//                 })}
//             />
//         </Tab.Navigator >
//     );
// }



const CustomBottomTab = (props) => {
    const screenWidth = Dimensions.get('window').width;
    const [currentScreen, setCurrentScreen] = useState();
    const { isActive, selected } = props

    const onPressTab = (route) => {
        props.navigation.navigate(route)
        setCurrentScreen(route)
    }

    return (

        
        <ImageBackground resizeMode="stretch"
        
        // style={tw`flex-row items-center bg-white shadow-[#7D64FF] shadow-2xl  w-90% ml-4.5 mt-50 h-20 mb-10 absolute bottom--4 justify-evenly pt-0 rounded-full`}
            style={tw`flex-row items-center w-90% h-17 bg-white shadow-[#7D64FF] shadow-2xl ml-4.5 mt-50 mb-8 absolute bottom--4  justify-evenly pt-0 rounded-full`}
        
            //style={styles.root}
        >
            <TouchableOpacity onPress={() => onPressTab("Coupons")} >
                <View style={[tw`w-10 h-10  rounded-[6] justify-center items-center flex-row`, { backgroundColor: (selected == 'Coupon') ? '#282828' : '#ffffff' }]}>
                    <Image source={ImageIcons.home} style={[tw`w-5.5 h-5.5 mb-1`, { tintColor: (selected == 'Coupon') ? '#ffffff' : '#000000' }]} />
                    {/* <Text style={[tw`text-xs right-0.5`, { color: (selected != true) && '#ffffff' }]}>Home</Text> */}
                </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => onPressTab("Market")}>
                <View style={[tw`w-10 h-10  rounded-[6] justify-center items-center flex-row`, { backgroundColor: (selected == 'Market') ? '#282828' : '#ffffff' }]}>
                    <Image source={ImageIcons.Market} style={[tw`w-5.5 h-5.5`, { tintColor: (selected == 'Market') ? '#ffffff' : '#000000' }]} />
                    {/* <Text style={[tw`text-xs right-1.5`, { color: (selected != true) && '#ffffff' }]}>Txns</Text> */}
                </View>
            </TouchableOpacity>

            <TouchableOpacity
                onPress={() => onPressTab("Portfolio")}
            >
                <View style={[tw`w-10 h-10  rounded-[6] justify-center items-center flex-row`, { backgroundColor: (selected == 'Portfolio') ? '#282828' : '#ffffff' }]}>
                    <Image source={ImageIcons.Swap} style={[tw`w-5.5 h-5.5`, { tintColor: (selected == 'Portfolio') ? '#ffffff' : '#000000' }]} />
                  
                </View>
            </TouchableOpacity>

            <TouchableOpacity
             onPress={() => onPressTab("Wallet")}
            >
                <View style={[tw`w-10 h-10  rounded-[6] justify-center items-center flex-row`, { backgroundColor: (selected == 'Wallet') ? '#282828' : '#ffffff' }]}>
                    <Image source={ImageIcons.F_wallet} style={[tw`w-5.5 h-5`, { tintColor: (selected == 'Wallet') ? '#ffffff' : '#000000' }]} />
                    {/* <Text style={[tw`text-xs right-1.5`, { color: (selected != true) && '#ffffff' }]}>Txns</Text> */}
                </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => onPressTab("Profile")}>
                <View style={[tw`w-10 h-10  rounded-[6] justify-center items-center flex-row`, { backgroundColor: (selected == 'Profile') ? '#282828' : '#ffffff' }]}>
                    <Image source={ImageIcons.Extra2} style={[tw`w-10 h-14 `, { tintColor: (selected == 'Profile') ? '#ffffff' : '#000000' }]} />
                    {/* <Text style={[tw`text-xs right-1.5`, { color: (selected != true) && '#ffffff'}]}>Profile</Text> */}
                </View>
            </TouchableOpacity>

            {/* <TouchableOpacity  onPress={() => props.navigation.toggleDrawer()}>
                <Image source={ImageIcons.MenuTabIcon} style={[tw`w-6 h-6`,  { tintColor: '#767676' }]} />
            </TouchableOpacity> */}
        </ImageBackground>

    );
}

const styles = StyleSheet.create({
    root: {
        flexDirection: 'row',
        //width: '100%',
        width: screenWidth,
        height: 90,
        alignItems: 'center',
        alignSelf: 'center',
        justifyContent: 'space-around',
        paddingHorizontal: '5%',
        paddingTop: '8%',
        // paddingVertical: 3,
        //backgroundColor: Colors.white,
        //backgroundColor: '#323435',
        position: 'absolute',
        bottom: 0,


    },
    label1: {
        fontSize: 14,
        fontFamily: Fonts.RalewayRegular,
        color: Colors.black,
        marginTop: 3,
        marginBottom: 2
        // marginLeft: -20,
    },
    label: {
        fontSize: 14,
        fontFamily: Fonts.RalewayRegular,
        color: Colors.black,
        marginBottom: 5
        // marginLeft: -20,
    },
    label_new: {
        fontSize: 14,
        fontFamily: Fonts.RalewayRegular,
        color: Colors.black,
        marginBottom: 5
        // marginLeft: -20,
    },
    img1: {
        width: wp('6%'),
        height: hp('4%'),
        resizeMode: 'contain'
    },
    img2: {
        width: wp('8%'),
        height: hp('8%'),
        resizeMode: 'contain'
    },

    img_bottomplus: {
        width: 20,
        height: 20,
        resizeMode: 'contain'
    },
    img: {
        width: wp('4.5%'),
        height: hp('3%'),
        resizeMode: 'contain'
    },
    // customTab: {
    //     width: 70,

    //     alignItems: 'center'
    //     // height: 50
    // }
});

export default CustomBottomTab;
