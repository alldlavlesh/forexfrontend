import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, Dimensions, View, ImageBackground, TouchableOpacity, SafeAreaView } from 'react-native';
import { Colors, Fonts, ImageIcons, Images } from '../../common';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import tw from 'twrnc';

const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

// const BottomTabRoute = () => {
//     return (
//         <Tab.Navigator initialRouteName="Home" tabBar={props => <CustomBottomTab {...props} />} >
//             <Tab.Screen
//                 name="Home"
//                 component={DashboardNavigation}
//                 options={{
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.HomeTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text style={[styles.label, { color: focused ? Colors.green : Colors.black }]}>Coupons</Text>
//                 }}
//             />
//             <Tab.Screen
//                 name="Coupons"
//                 component={Coupons}
//                 options={{
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.CouponTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text style={[styles.label, { Colors: focused ? Colors.green : Colors.black }]}>Coupons</Text>
//                 }}
//             />
//             <Tab.Screen
//                 name="CreateFeed"
//                 component={CreateFeedCommon}
//                 options={{
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.PlusTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text style={[styles.label, { color: focused ? Colors.green : Colors.black }]}>Post</Text>
//                 }}
//             />
//             <Tab.Screen
//                 name="Menu"
//                 component={MenuScreen}
//                 options={({ navigation }) => ({
//                     tabBarIcon: ({ focused }) => <Image source={ImageIcons.MenuTabIcon} style={[styles.img, { tintColor: focused ? Colors.green : Colors.black }]} />,
//                     tabBarLabel: ({ focused }) => <Text onPress={() => navigation.toggleDrawer()} style={[styles.label, { color: focused ? Colors.green : Colors.black }]}>Coupons</Text>,
//                 })}
//             />
//         </Tab.Navigator >
//     );
// }



const CustomHeaderTab = (props) => {
    const screenWidth = Dimensions.get('window').width;
    const [currentScreen, setCurrentScreen] = useState();
    const { isActive, selected } = props

    const onPressTab = (route) => {
        props.navigation.navigate(route)
        setCurrentScreen(route)
    }

    return (

        <View style={tw`flex-row w-12/12 pt-8 h-25 bg-[#ffffff] shadow-2xl shadow-[#7D64FF] justify-around items-center`}>


            {props?.parent == true &&
                <View style={tw` `} >
                    <TouchableOpacity>
                        <Image resizeMode='contain' style={tw`h-10 w-10`} source={ImageIcons.prof} />
                    </TouchableOpacity>
                </View>
            }
            {props?.parent == true ? (
                <View style={tw` w-8/12`} >
                    <Text style={tw`text-4 font-bold  text-[#451873]`}>{props?.name}</Text>
                    <Text style={tw`text-6 font-bold  text-[#451873]`}>WELCOME BACK</Text>
                </View>
            ) : (
                <View style={tw`flex-row w-12/12`}>
                    <View style={tw`w-2/12 flex justify-center items-center`}>
                        <TouchableOpacity onPress={() => props.navigation.goBack()}>
                            <Image resizeMode='contain' style={tw`h-5 w-4 tint-black `} source={ImageIcons.Path_back} />
                        </TouchableOpacity>
                    </View>

                    <View  style={tw` w-8/12 flex justify-center items-center`}>
                        <Text style={tw`text-6 font-bold text-black`}>{props?.name}</Text>
                    </View>
                </View>
            )}



            {props?.parent == true && (
                <View style={tw` `}>
                    <TouchableOpacity onPress={() => onPressTab("Notification")}>
                        <Image resizeMode='contain' style={tw`h-10 w-8 `} source={ImageIcons.Notification} />
                    </TouchableOpacity>
                </View>
            )}
            
            {props?.profile == true && (
                <View style={tw` w-2/12`}>
                    <TouchableOpacity onPress={() => onPressTab("Editprofile")}>
                        <Text style={tw`text-4 font-bold text-[#F61C7A]`}>Edit</Text>
                    </TouchableOpacity>
                </View>
            )}
            

        </View>


    );
}

const styles = StyleSheet.create({
    root: {
        flexDirection: 'row',
        //width: '100%',
        width: screenWidth,
        height: 90,
        alignItems: 'center',
        alignSelf: 'center',
        justifyContent: 'space-around',
        paddingHorizontal: '5%',
        paddingTop: '8%',
        // paddingVertical: 3,
        //backgroundColor: Colors.white,
        //backgroundColor: '#323435',
        position: 'absolute',
        bottom: 0,


    },
    label1: {
        fontSize: 14,
        fontFamily: Fonts.RalewayRegular,
        color: Colors.black,
        marginTop: 3,
        marginBottom: 2
        // marginLeft: -20,
    },
    label: {
        fontSize: 14,
        fontFamily: Fonts.RalewayRegular,
        color: Colors.black,
        marginBottom: 5
        // marginLeft: -20,
    },
    label_new: {
        fontSize: 14,
        fontFamily: Fonts.RalewayRegular,
        color: Colors.black,
        marginBottom: 5
        // marginLeft: -20,
    },
    img1: {
        width: wp('6%'),
        height: hp('4%'),
        resizeMode: 'contain'
    },
    img2: {
        width: wp('8%'),
        height: hp('8%'),
        resizeMode: 'contain'
    },

    img_bottomplus: {
        width: 20,
        height: 20,
        resizeMode: 'contain'
    },
    img: {
        width: wp('4.5%'),
        height: hp('3%'),
        resizeMode: 'contain'
    },
    // customTab: {
    //     width: 70,

    //     alignItems: 'center'
    //     // height: 50
    // }
});

export default CustomHeaderTab;
