import React, { useEffect, useState } from 'react';
import { Image, Text, View, SafeAreaView, TouchableOpacity, StyleSheet, Platform, Linking, PixelRatio } from 'react-native';
import { connect, useDispatch } from 'react-redux';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItem, DrawerItemList } from '@react-navigation/drawer';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import VendorStack from './VendorStack';
import CouponsStack from './CouponsStack';
import BuysellStack from './BuysellStack';
import FrameStack from './FrameStack';
import EarningStack from './EarningStack';
import CreateTicketStack from './CreateTicketStack';
import { ImageIcons, Colors, Fonts } from '../common';
import { logout } from '../redux/actions/Auth'
import { StackActions } from '@react-navigation/native';
import { IS_SUBSCRIPTION_SELECTED } from '../redux/actions/ActionTypes';
import tw from 'twrnc'

const Drawer = createDrawerNavigator();

// Custom Drawer 
const CustomDrawer = (props) => {

  //Local states
  const [currentItem, setCurrentItem] = useState("Verification");
  const completedVerificationdata = 'true';
  const onItemSelection = (routeName) => {
    setCurrentItem(routeName);
  }
  useEffect(() => {
    props?.navigation?.closeDrawer();
  }, [])


  useEffect(() => {
    if (props.isSubscriptionSelected) {
      setCurrentItem("Subscriptions")
      // props?.navigation?.dispatch(
      //   StackActions.replace('SubscriptionStack')
      // );
    }
  }, [props.isSubscriptionSelected])

  
  return (
    <Drawer.Navigator
      screenOptions={({ navigation }) => ({
        headerShown: false,
        swipeEdgeWidth: 0,
      })}
      openByDefault={false}
      initialRouteName={""}
      drawerContent={prop => ''}
    >
      <Drawer.Screen 
        name="Coupons"
        component={CouponsStack}
        
      />
      

    </Drawer.Navigator >
  );
};

// Custom Drwaer content
const CustomDrawerContent = ({ prop, rootProps, currentItem, onItemSelection }) => {

  const dispatch = useDispatch()
  const { logoutIcon, wallponLogoHorizontal, accountIcon, veriIcon } = ImageIcons;
  const { loginCredentials, storeAutofilInfo, verificationStatus, verificationSteps } = rootProps;
  const completedVerification = (verificationStatus?.isStore && verificationStatus?.isUtilityBill) ? true : false;

  const [enableCoupon, setEnableCoupon] = useState(verificationStatus?.isStore || false);

 

  return (
    <SafeAreaView style={{ flex: 1, display:'none',width:10 }} >
      

      
    </SafeAreaView >
  )
}



const styles = StyleSheet.create({
  label: {
    fontSize: 16,
    // fontFamily: Fonts.QuestrialRegular,
    color: Colors.BLACK,
    marginLeft: -17
  },
  activeLabel: {
    fontSize: 16,
    fontFamily: Fonts.RalewayExtraBold,
    color: Colors.WHITE,
    marginLeft: -17
  },
  drawerHeader: {
    height: hp('18%'),
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: Platform.OS === "ios" ? hp('2%') : hp('10%'),
  },
  logo: {
    width: '85%',
    height: '100%',
    resizeMode: 'contain'
  },
  logoutItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    backgroundColor: 'white'
  },
  leftIcon: {
    width: wp('5%'),
    height: wp('5%'),
    marginLeft: 15,
    tintColor: Colors.WHITE
  },
  icon: {
    width: wp('8%'),
    height: wp('8%'),
  },
  info: {
    width: wp('3%'),
    height: wp('3%'),
    resizeMode: 'contain'
  },
  drawerItemsContainer: {
    height: Platform.OS === "ios" ? hp('80%') : hp('95%'),
    flexDirection: 'column',
    justifyContent: 'space-between',
    marginTop: Platform.OS === "ios" ? hp('-1%') : hp('-1%')
  }
});

const mapStateToProps = (state) => ({
  loginCredentials: state.auth.loginCredentials,
  // isStore: state.vendor.isStore,
  verificationStatus: state.vendor.verificationStatus,
  verificationSteps: state.vendor.verificationSteps,
  storeAutofilInfo: state.vendor.storeAutofilInfo,
  storeImageUploadInfo: state.vendor.storeImageUploadInfo,
  planSelected: state.coupon.planSelected,
  isSubscriptionSelected: state.coupon.isSubscriptionSelected,
});

const mapDispatchToProps = {
  logout
};

export default connect(mapStateToProps, mapDispatchToProps)(CustomDrawer);
