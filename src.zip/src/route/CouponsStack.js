import React, { Fragment, useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { TouchableOpacity, Text, Image, StyleSheet, View } from 'react-native';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { Deposite, Withdraw_USD, Notification, SuccessPayment,Wallet,Withdraw,Buy,Sell,SellUsdt, BuyUsdt,Refferal, AllRefferalView,Transaction,Coupons,Market,Totalinvest,Profile,Editprofile, CurrencySetting, Setting, ChatPage, FAQ ,TermsConditions, Introduction, BuySell, CouponPublished,Portfolio, DoneShare, Withrawamount, AllTicketView,Invest, News, NewsDetails } from '../container'
import AddServices from '../container/coupon/AddServices';
import AddcouponServices from '../container/coupon/AddcouponServices';
import { Colors, Fonts, ImageIcons } from '../common';
import { useSelector } from 'react-redux';
import CouponDetailJS from '../container/coupon/CouponDetail';
import { Frame,Frameinsurence,Merchant,Webmobile,Financial,Tax} from '../container'
// import withdrawamount from '../screens/coupons/Withrawamount';

const Stack = createStackNavigator();

const CouponsStack = (props) => {
    const { navigation } = props;
    const { couponCredits } = useSelector(state => state.coupon);
    useEffect(() => {
        navigation.closeDrawer();
    }, [])

    return (
        <>        
            <Stack.Navigator>
                <Stack.Screen
                    name="Coupons"
                    component={Coupons}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        //headerRight: () => <RightMenuItem navigation={navigation} couponCredits={couponCredits} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontFamily: Fonts.RalewayExtraBold },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
 
                <Stack.Screen
                    name="Deposite"
                    component={Deposite}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                 <Stack.Screen
                    name="Invest"
                    component={Invest}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="Withdraw_USD"
                    component={Withdraw_USD}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="AllTicketView" 
                    component={AllTicketView}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "All Ticket View",
                        
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Portfolio"
                    component={Portfolio}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "Portfolio",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Notification"
                    component={Notification}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                
                <Stack.Screen
                    name="Wallet"
                    component={Wallet}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "Wallet",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="SuccessPayment"
                    component={SuccessPayment}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Buy"
                    component={Buy}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerTitle: "Buy",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="BuyUsdt"
                    component={BuyUsdt}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerTitle: "BuyUsdt",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                 
                 <Stack.Screen
                    name="Sell"
                    component={Sell}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerTitle: "Sell",                        
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="SellUsdt"
                    component={SellUsdt}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerTitle: "SellUsdt",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="AddServices"
                    component={AddServices}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "Add Services",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Withdraw"
                    component={Withdraw}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} leftImage={ImageIcons.menuIcon} />,
                        headerTitle: "Withdraw",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.HomepageBaukastenBold,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Totalinvest"
                    component={Totalinvest}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} leftImage={ImageIcons.menuIcon} />,
                        headerTitle: "Withdraw",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.HomepageBaukastenBold,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                
                <Stack.Screen
                    name="Transaction"
                    component={Transaction}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "Transaction",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="AddcouponServices"
                    component={AddcouponServices}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "Add Coupon Or Services",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />                 
                
                <Stack.Screen
                    name="CouponDetail"
                    component={CouponDetailJS}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "COUPON",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="CouponPublished"
                    component={CouponPublished}
                    options={({ navigation }) => ({
                        //headerShown: true,
                        headerLeft: () => <LeftMenuItem1 navigation={navigation} isMenu={false} />,
                        headerTitle: "CouponPublished",
                        // headerTitleAlign: "center",
                         headerTitleStyle: { color: Colors.WHITE, fontWeight: 'bold' },
                        // headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="DoneShare"
                    component={DoneShare}
                    options={({ navigation }) => ({
                        //headerShown: true,
                        headerLeft: () => <LeftMenuItem1 navigation={navigation} isMenu={false} />,
                        headerTitle: "DoneShare",
                        // headerTitleAlign: "center",
                         headerTitleStyle: { color: Colors.WHITE, fontWeight: 'bold' },
                        // headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Frameinsurence"
                    component={Frameinsurence}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "Frameinsurence",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.WHITE,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="Merchant"
                    component={Merchant}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "Merchant",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.WHITE,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="Webmobile"
                    component={Webmobile}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "Webmobile",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                 
                <Stack.Screen
                    name="Tax"
                    component={Tax}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "Tax",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="Financial"
                    component={Financial}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "CoinPayments",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Market"
                    component={Market}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "Market",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />



                <Stack.Screen
                    name="BuySell"
                    component={BuySell}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerTitle: "BuySell",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />


                <Stack.Screen
                    name="News"
                    component={News}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} leftImage={ImageIcons.menuIcon} />,
                        headerTitle: "News",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.HomepageBaukastenBold,
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="NewsDetails"
                    component={NewsDetails}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: { color: Colors.BLACK, fontWeight: 'bold' },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="Profile"
                    component={Profile}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={props?.navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="Editprofile"
                    component={Editprofile}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="CurrencySetting"
                    component={CurrencySetting}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="FAQ"
                    component={FAQ}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                
                <Stack.Screen
                    name="Introduction"
                    component={Introduction}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="TermsConditions"
                    component={TermsConditions}
                    options={({ navigation }) => ({
                        headerShown: false,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="ChatPage"
                    component={ChatPage}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                <Stack.Screen
                    name="Setting"
                    component={Setting}
                    options={({ navigation }) => ({
                        headerShown: false,
                        // headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                <Stack.Screen
                    name="AllRefferalView"
                    component={AllRefferalView}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "All Refferal View",
                        
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />
                
                <Stack.Screen
                    name="Refferal"
                    component={Refferal}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "REFFERAL",
                        
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />


                {/* <Stack.Screen
                    name="Verification"
                    component={VerificationStack}
                    options={{ headerShown: false }}
                /> */}
            </Stack.Navigator>
        </>
    );
};

const LeftMenuItem = ({ navigation, isMenu }) => {
    return (
        <TouchableOpacity
            onPress={() => {
                if (isMenu) {
                    navigation?.toggleDrawer()
                } else {
                    navigation?.goBack();
                }
            }}
            style={styles.leftButton}
        >
            <Image source={isMenu ? ImageIcons.menuIcon : ImageIcons.backarrow} style={styles.leftIcon} />
        </TouchableOpacity>
    )
}

const LeftMenuItem1 = ({ navigation, isMenu }) => {
    return (
        <TouchableOpacity
            onPress={() => {
                if (isMenu) {
                    navigation?.toggleDrawer()
                } else {
                    navigation?.navigate("Coupons");
                }
            }}
            style={styles.leftButton}
        >
            <Image source={isMenu ? ImageIcons.menuIcon : ImageIcons.backarrow} style={styles.leftIcon} />
        </TouchableOpacity>
    )
}

const RightMenuItem = ({ navigation, couponCredits }) => {
    return (
        <View style={styles.rightLabel}>
            <Text style={styles.rightText}>{`(${couponCredits || 0} credits)`}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    leftButton: {
        height: wp('6%'),
        marginLeft: 15,
        paddingHorizontal: 8,
        justifyContent: 'center'
    },
    rightLabel: {
        height: wp('6%'),
        paddingHorizontal: 8,
        marginRight: 10,
        justifyContent: 'center'
    },
    leftIcon: {
        width: wp('3%'),
        height: wp('5%'),
        // marginLeft: 15,
        tintColor: Colors.BLACK
    },
    rightText: {
        fontSize: 12
    }
});

export default CouponsStack;
