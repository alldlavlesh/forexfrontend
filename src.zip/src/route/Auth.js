import React, { useEffect, useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { TouchableOpacity, Text } from 'react-native';
import {
  Registration,
  Login,
  Getstarted,
  Verification,
  Documentverification,
  SetupPin,
  Deposite,
  Withdraw_USD,
  OTPVerification,
  Landing,
  // Slideshow,
  StoreOwner,
  ForgetPassword,
  ResetPassword,
  Searchlocation,
  VerifyPassword,
  WelcomeBack  
} from '../container';
import { connect } from 'react-redux';
import { Colors, Fonts, ImageIcons } from '../common';

const Stack = createStackNavigator();

const Auth = (props) => {

  // useEffect(() => {
  //   if (props.defaultAuthScreen === "ResetPassword") {
  //     props.navigation.navigate("ResetPassword");
  //   }
  // }, [props.defaultAuthScreen])

  return (
    <Stack.Navigator
    // initialRouteName={defaultScreen}
    // screenOptions={{
    //   headerStyle: {
    //     backgroundColor: Colors.SKY_BLUE,
    //   },
    //   headerTintColor: Colors.WHITE,
    // }}
    >

      <Stack.Screen
        name="Landing"
        component={Landing}
        options={{ title: '', headerShown: false }}
      />
       <Stack.Screen
        name="Getstarted"
        component={Getstarted}
        options={{ title: '', headerShown: false }}
      />

      {/* <Stack.Screen
        name="Slideshow"
        component={Slideshow}
        options={{ title: '', headerShown: false }}
      /> */}

      <Stack.Screen
        name="Login"
        component={Login}
        options={{ title: '', headerShown: false }}
      />

      <Stack.Screen
        name="Registration"
        component={Registration}
        options={{ title: '', headerShown: false }}
      />
      <Stack.Screen
        name="Verification"
        component={Verification}
        options={{ title: '', headerShown: false }}
      />
      <Stack.Screen
        name="Documentverification"
        component={Documentverification}
        options={{ title: '', headerShown: false }}
      />
      
      <Stack.Screen
        name="SetupPin"
        component={SetupPin}
        options={{ title: '', headerShown: false }}
      />
      <Stack.Screen
        name="Deposite"
        component={Deposite}
        options={{ title: '', headerShown: false }}
      />
      <Stack.Screen
        name="Withdraw_USD"
        component={Withdraw_USD}
        options={{ title: '', headerShown: false }}
      />
      

      <Stack.Screen
        name="OTPVerification"
        component={OTPVerification}
        options={{ title: '', headerShown: false }}
      />

      <Stack.Screen
        name="ResetPassword"
        component={ResetPassword}
        options={{ title: '', headerShown: false }}
      />

      <Stack.Screen
        name="StoreOwner"
        component={StoreOwner}
        options={{ title: '', headerShown: true, headerTransparent: true, headerTintColor: Colors.WHITE }}
      />
      <Stack.Screen
        name="ForgetPassword"
        component={ForgetPassword}
        options={{ title: '', headerShown: true, headerTransparent: true, headerTintColor: Colors.WHITE }}
      />
      <Stack.Screen
        name="VerifyPassword"
        component={VerifyPassword}
        options={{ title: '', headerShown: true, headerTransparent: true, headerTintColor: Colors.WHITE }}
      />

      {/* <Stack.Screen
        name="VerificationForm"
        component={VerificationForm}
        options={{ title: '', headerShown: false, headerTransparent: true,headerTintColor:Colors.WHITE }}
      /> */}

      <Stack.Screen
        name="Searchlocation"
        component={Searchlocation}
        options={{ title: '', headerShown: false, headerTransparent: true, headerTintColor: Colors.WHITE }}
      />

      <Stack.Screen
        name="WelcomeBack"
        component={WelcomeBack}
        options={{ title: '', headerShown: false, headerTransparent: true, headerTintColor: Colors.WHITE }}
      />

      

    </Stack.Navigator>
  );
};


const mapStateToProps = (state) => ({
  defaultAuthScreen: state.auth.defaultAuthScreen,
});

const mapDispatchToProps = {
};

export default connect(mapStateToProps, mapDispatchToProps)(Auth);

// export default Auth;
