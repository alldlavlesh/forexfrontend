import React, { Fragment } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { TouchableOpacity, Text, Image, StyleSheet } from 'react-native';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { Coupons, Market, SingleCouponInsight, Wallet, Transaction } from '../container'
import { Colors, Fonts, ImageIcons } from '../common';

const Stack = createStackNavigator();

const TransactionStack = (props) => {
    const { navigation } = props;

    return (
        <>
            <Stack.Navigator 
            initialRouteName='Market'
            >
                <Stack.Screen
                    name="Transaction"
                    component={Transaction}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "Transaction",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                />

                

                {/* <Stack.Screen
                    name="Coupons"
                    component={Coupons}
                    options={({ navigation }) => ({
                        headerShown: false,
                        //headerRight: () => <LeftMenuItem navigation={navigation} isMenu={true} />,
                        headerTitle: "Coupons",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            //  fontFamily: Fonts.RalewayExtraBold 
                            fontWeight: 'bold'
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                /> */}

                {/* <Stack.Screen
                    name="SingleCouponInsight"
                    component={SingleCouponInsight}
                    options={({ navigation }) => ({
                        headerShown: true,
                        headerLeft: () => <LeftMenuItem navigation={navigation} isMenu={false} />,
                        headerTitle: "INSIGHTS",
                        headerTitleAlign: "center",
                        headerTitleStyle: {
                            color: Colors.BLACK,
                            fontFamily: Fonts.RalewayExtraBold
                        },
                        headerStyle: { backgroundColor: Colors.WHITE, elevation: 0, shadowOpacity: 0 },
                    })}
                /> */}
            </Stack.Navigator>
        </>
    );
};

const LeftMenuItem = ({ navigation, isMenu }) => {
    return (
        <TouchableOpacity
            onPress={() => {
                if (isMenu) {
                    navigation?.toggleDrawer()
                } else {
                    navigation?.goBack();
                }
            }}
            style={styles.leftButton}
        >
            <Image source={isMenu ? ImageIcons.menuIcon : ImageIcons.backarrow} style={styles.leftIcon} />
        </TouchableOpacity>
    )
}


const styles = StyleSheet.create({
    leftButton: {
        height: wp('6%'),
        marginLeft: 15,
        paddingHorizontal: 8,
        justifyContent: 'center'
    },
    leftIcon: {
        width: wp('3%'),
        height: wp('5%'),
        marginLeft: 15,
        tintColor: Colors.BLACK,
    }
});

export default TransactionStack;
