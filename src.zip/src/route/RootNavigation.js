import React, { useState, useEffect } from 'react';
import { connect, useSelector } from 'react-redux';
import {
    View,
    Alert,
    StyleSheet,
    ActivityIndicator,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import Auth from '../route/Auth';
// import RNBootSplash from "react-native-bootsplash";
import CustomDrawer from './CustomDrawer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { login, changeLoginCredentials, setNetworkConnection, logout } from '../redux/actions/Auth'
import { setVendorInfo, setVendorIdResetPassword } from '../redux/actions/Vendor'
import NetInfo from "@react-native-community/netinfo";
// import messaging from '@react-native-firebase/messaging';
import { Colors } from '../common';

const RootNavigation = (props) => {

    //Local states
    const [isResetLink, setIsResetLink] = useState(false)
    const [isLoading, setIsLoading] = useState(true)
    // Redux states
    let { loginCredentials, defaultAuthScreen } = useSelector(state => state.auth)

    useEffect(() => {
        NetInfo.fetch().then(state => {
            props.setNetworkConnection(state.isConnected);
        });
    }, [loginCredentials])

    useEffect(async () => {        
        // End: Dynamic link Listener
        const unsubscribe = NetInfo.addEventListener(state => {
            if (!state.isConnected) {
                Alert.alert(CommonStrings.AppName, "Please check your internet connection")
            }
            props.setNetworkConnection(state.isConnected);
        });
        validateLoginCredential();
        return () => {
            unsubscribe();
            //unsubscribeFCMbackground();
            //unsubscribeFCM();
            linkUnsubscribe();
        }
    }, [])

    // Validate login credential
    const validateLoginCredential = async () => {
        let loginCredentials = await AsyncStorage.getItem('@loginCredential');
        if (loginCredentials && loginCredentials != null) {
            loginCredentials = JSON.parse(loginCredentials);
            props.changeLoginCredentials(loginCredentials)
                setIsLoading(false)
        } else {
                setIsLoading(false)
        }
        //RNBootSplash.hide();
    }

    if (isLoading) {
        return <View style={{
            flex: 1,
            justifyContent: 'center',
            backgroundColor: Colors.BLACK
        }}>
            <ActivityIndicator size="large" color={Colors.GREEN} />
        </View >
    } else {
        return (
            <NavigationContainer >
                {(!loginCredentials) && <Auth />}
                {(loginCredentials) && <CustomDrawer />}
            </NavigationContainer>
        );
    }
}


const mapStateToProps = (state) => ({

});

const mapDispatchToProps = {
    login,
    changeLoginCredentials,
    setNetworkConnection,
    setVendorInfo,
    setVendorIdResetPassword,
    logout
};
export default connect(mapStateToProps, mapDispatchToProps)(RootNavigation);
