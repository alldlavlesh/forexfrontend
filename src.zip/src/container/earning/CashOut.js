
import { connect } from 'react-redux';
import   CashOut from '../../screens/earning/cashOut';

const mapStateToProps = (state) => ({

});

const mapDispatchToProps = {

};

export default connect(mapStateToProps, mapDispatchToProps)(CashOut);

