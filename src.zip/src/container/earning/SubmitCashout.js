
import { connect } from 'react-redux';
import   SubmitCashout from '../../screens/earning/cashOut/SubmitCashout';

const mapStateToProps = (state) => ({

});

const mapDispatchToProps = {

};

export default connect(mapStateToProps, mapDispatchToProps)(SubmitCashout);

