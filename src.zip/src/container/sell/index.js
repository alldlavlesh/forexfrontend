
import { connect } from 'react-redux';
import Sell from '../../screens/sell';
import { initiateSellUSDT } from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    transactionslist: state.coupon.transactionslist,
});

const mapDispatchToProps = {
    initiateSellUSDT,
};

export default connect(mapStateToProps, mapDispatchToProps)(Sell);

