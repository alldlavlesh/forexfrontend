import { connect } from 'react-redux';
import SellUsdt from '../../screens/sell/SellUsdt';
import { initiateSellUSDT } from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    loginCredentials:state.auth.loginCredentials,
    initiateReqUsdt: state.vendor.initiateReqUsdt
});

const mapDispatchToProps = {
    initiateSellUSDT
};

export default connect(mapStateToProps, mapDispatchToProps)(SellUsdt);

