
import { connect } from 'react-redux';
import Transaction from '../../screens/transaction';
import { getRedeemedCoupons,getTransactionsList,getTransactionsListStock } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    transactionslist: state.coupon.transactionslist,
    transactionStock:state.coupon.transactionStock
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getTransactionsList,
    getTransactionsListStock
};

export default connect(mapStateToProps, mapDispatchToProps)(Transaction);

