import Registration from './auth/Registration';
import OTPVerification from './auth/OTPVerification';

import WelcomeBack from './auth/WelcomeBack';

import Landing from './auth/Landing';
// import Slideshow from './auth/Slideshow';
import StoreOwner from './auth/StoreOwner';
import Login from './auth/Login';
import Getstarted from './auth/Getstarted';
import Verification from './auth/Verification';
import Documentverification from './auth/Documentverification';
import SetupPin from './auth/SetupPin';
import ResetPassword from './auth/ResetPassword';
import ForgetPassword from './auth/ForgetPassword';
import VerifyPassword from './auth/VerifyPassword';
import Vendor from './vender';
import AddNewVendor from './vender/AddNewVendor';
import AcceptedVendor from './vender/AcceptedVendor';
import SearchLocation from './vender/SearchLocation';
import Searchlocation from './auth/Searchlocation';
import VendorDetails from './vender/VendorDetails';
import Earning from './earning';
import CashOut from './earning/CashOut';
import ManageBank from './earning/ManageBank';
import SubmitCashout from './earning/SubmitCashout';
import SelectBank from './earning/SelectBank'; 
import AddBankAccount from './earning/AddBankAccount';
import Coupons from './coupon';

import Deposite from './coupon/Deposite';

import AddcouponServices from './coupon/AddcouponServices';
// import HomePage from './coupon/HomePage';
import AddServices from './coupon/AddServices';
import CouponPublished from './coupon/CouponPublished';
import DoneShare from './coupon/DoneShare';
import Market from './market'; 
import Wallet from './wallet'; 
import Transaction from './transaction';
import Portfolio from './market/Portfolio';
import Refferal from './refferal';
import AllRefferalView from './refferal/AllRefferalView';
import CreateTicket from './createticket';

import AllTicketView from './createticket/AllTicketView';
import SingleCouponInsight from './transaction/SingleCouponInsight';
import Withdraw from './withdraw/Withdraw';
import Totalinvest from './totalinvest/Totalinvest';
import Invest from './totalinvest/Invest';
import News from './news/News';
import NewsDetails from './news/NewsDetails';
import Withdraw_USD from './coupon/Withdraw_USD';
import VerificationForm2 from './withdraw/VerificationForm2';
import VerificationForm3 from './withdraw/VerificationForm3';
import VerificationForm4 from './withdraw/VerificationForm4';
import ChooseSubscription from './subscription/ChooseSubscription';
import SubscriptionDetail from './subscription/SubscriptionDetail';
import Profile from './profile'
import Buy from './buy';
import Sell from './sell';
import BuySell from './buySell';
import SellUsdt from './sell/SellUsdt';
import BuyUsdt from './buy/BuyUsdt';
import Editprofile from './profile/Editprofile';
import CurrencySetting from './profile/CurrencySetting';
import TermsConditions from './profile/TermsConditions';
import Setting from './profile/Setting';
import Introduction from './profile/Introduction';
import ChatPage from './createticket/ChatPage';
import Frame from './frame';
import Frameinsurence from './frame/Frameinsurence';
import Merchant from './frame/Merchant';
import Webmobile from './frame/Webmobile';
import Financial from './frame/Financial';
import Tax from './frame/Tax';
import SuccessPayment from './coupon/SuccessPayment';
import Notification from './coupon/Notification';

import FAQ from './profile/FAQ';



export {
    Searchlocation,
    Refferal,
    CreateTicket,
    TermsConditions,
    Introduction,
    WelcomeBack,
    AllRefferalView,
    AllTicketView,
    Registration,
    ChatPage,
    FAQ,
    Buy,
    BuyUsdt,
    Notification,
    OTPVerification,
    Login,
    Getstarted,
    Landing,
    // Slideshow,
    CurrencySetting,
    SuccessPayment ,
    ResetPassword,
    AddcouponServices,
    ForgetPassword,
    VerifyPassword,
    Vendor,
    Earning,
    AddServices,
    StoreOwner,
    AddNewVendor,
    AcceptedVendor,
    SearchLocation,
    VendorDetails,
    CashOut,
    ManageBank,
    SubmitCashout,
    SelectBank,
    AddBankAccount,
    Coupons,
    Market,
    Wallet,
    Portfolio,
    Transaction,
    SingleCouponInsight,
    Deposite,
    Withdraw,
    News,
    NewsDetails,
    Withdraw_USD,
    Totalinvest,
    Invest,
    VerificationForm2,
    VerificationForm3,
    VerificationForm4,
    ChooseSubscription,
    SubscriptionDetail,
    Profile,
    Editprofile,
    Frame,
    Frameinsurence,
    Merchant,
    Webmobile,
    CouponPublished,
    Financial,
    Tax,
    DoneShare,
    Sell,
    SellUsdt,
    Verification,
    Documentverification,
    SetupPin,
    Setting,
    BuySell,
};
