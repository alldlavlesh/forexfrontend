
import { connect } from 'react-redux';
import BuySell from '../../screens/buySell';
import {stockListing } from '../../redux/actions/Auth'
import { setStockDataValue } from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    getStocklist: state.auth.getStocklist, 
    stockData:state.vendor.setStockData
});

const mapDispatchToProps = {
    stockListing, 
    setStockDataValue
};

export default connect(mapStateToProps, mapDispatchToProps)(BuySell);

