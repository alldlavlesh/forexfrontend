
import { connect } from 'react-redux';
import Frame from '../../screens/frame';
import { getRedeemedCoupons } from '../../redux/actions/Coupon'
import {  getUser } from '../../redux/actions/Auth';
const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser
};

export default connect(mapStateToProps, mapDispatchToProps)(Frame);

