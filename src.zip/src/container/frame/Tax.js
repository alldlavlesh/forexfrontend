
import { connect } from 'react-redux';
import Tax from '../../screens/frame/Tax';
import { getRedeemedTrackingData } from '../../redux/actions/Coupon';
import { updateProfile } from '../../redux/actions/Auth';

const mapStateToProps = (state) => ({
    redeemedCouponTrackingData: state.coupon.redeemedCouponTrackingData,
    redeemedCouponTrackingLoader: state.coupon.redeemedCouponTrackingLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,
     seteditprofile:state.auth.seteditprofile,
     editprofileloader:state.auth.editprofileloader,
});

const mapDispatchToProps = {
    getRedeemedTrackingData,
    updateProfile
};

export default connect(mapStateToProps, mapDispatchToProps)(Tax);

