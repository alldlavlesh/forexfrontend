
import { connect } from 'react-redux';
import Financial from '../../screens/frame/Financial';
import { getRedeemedTrackingData } from '../../redux/actions/Coupon';
import { updateProfile } from '../../redux/actions/Auth';

const mapStateToProps = (state) => ({
    loginCredentials:state.auth.loginCredentials,
    initiateReqData: state.vendor.initiateReqData
});

const mapDispatchToProps = {
    getRedeemedTrackingData,
    updateProfile
};

export default connect(mapStateToProps, mapDispatchToProps)(Financial);

