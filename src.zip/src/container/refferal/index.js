
import { connect } from 'react-redux';
import Refferal from '../../screens/refferal';
import { getRedeemedCoupons,getTransactionsList,addReferral } from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    transactionslist: state.coupon.transactionslist,
    refferalfrienddata: state.vendor.refferalfrienddata,
    getUserdetail:state.auth.userdarshanDetail,
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getTransactionsList,
    addReferral
};

export default connect(mapStateToProps, mapDispatchToProps)(Refferal);

