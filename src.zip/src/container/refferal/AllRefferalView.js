
import { connect } from 'react-redux';
import AllRefferalView from '../../screens/refferal/AllRefferalView';
import { getRedeemedTrackingData,referralListing } from '../../redux/actions/Vendor';

const mapStateToProps = (state) => ({
    redeemedCouponTrackingData: state.coupon.redeemedCouponTrackingData,
    redeemedCouponTrackingLoader: state.coupon.redeemedCouponTrackingLoader,
    refferalList: state.vendor.refferalList,
    loginCredentials: state.auth.loginCredentials,


});

const mapDispatchToProps = {
    getRedeemedTrackingData,
    referralListing

};

export default connect(mapStateToProps, mapDispatchToProps)(AllRefferalView);

