
import { connect } from 'react-redux';
import ChatPage from '../../screens/createticket/ChatPage';
import { getRedeemedCoupons ,ticketThreadChat, chatThread} from '../../redux/actions/Vendor'
import {  getUser,deletaccount } from '../../redux/actions/Auth';


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,
     ticketThread: state.vendor.ticketThread,
     chatthread:state.vendor.chatthread
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser,
    deletaccount,
    ticketThreadChat,
    chatThread
};

export default connect(mapStateToProps, mapDispatchToProps)(ChatPage);

