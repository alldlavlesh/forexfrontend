
import { connect } from 'react-redux';
import AllTicketView from '../../screens/createticket/AllTicketView';
import { getRedeemedTrackingData,ticketsListing } from '../../redux/actions/Vendor';

const mapStateToProps = (state) => ({
    redeemedCouponTrackingData: state.coupon.redeemedCouponTrackingData,
    redeemedCouponTrackingLoader: state.coupon.redeemedCouponTrackingLoader,
    createticket: state.vendor.createticket,
});

const mapDispatchToProps = {
    getRedeemedTrackingData,
    ticketsListing
};

export default connect(mapStateToProps, mapDispatchToProps)(AllTicketView);

