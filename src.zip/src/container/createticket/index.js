
import { connect } from 'react-redux';
import CreateTicket from '../../screens/createticket';
import { getRedeemedCoupons,getTransactionsList,addTickets,ticketsListing} from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    transactionslist: state.coupon.transactionslist,
    
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getTransactionsList,
    addTickets,
    
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateTicket);

