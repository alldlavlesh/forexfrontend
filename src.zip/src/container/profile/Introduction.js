import { connect } from 'react-redux';
import Introduction from '../../screens/profile/Introduction';
import { getRedeemedCoupons } from '../../redux/actions/Coupon'
import {  getUser,deletaccount } from '../../redux/actions/Auth';


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,

});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser,
    deletaccount
};

export default connect(mapStateToProps, mapDispatchToProps)(Introduction);

