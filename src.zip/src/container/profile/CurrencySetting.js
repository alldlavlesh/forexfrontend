
import { connect } from 'react-redux';
import CurrencySetting from '../../screens/profile/CurrencySetting';
import { getRedeemedCoupons,setCurrency } from '../../redux/actions/Vendor'
import {  getUser,deletaccount } from '../../redux/actions/Auth';


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,
Currency:state.vendor.Currency
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser,
    deletaccount,
    setCurrency
};

export default connect(mapStateToProps, mapDispatchToProps)(CurrencySetting);

