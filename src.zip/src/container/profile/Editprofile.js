
import { connect } from 'react-redux';
import Editprofile from '../../screens/profile/Editprofile';
import { getRedeemedTrackingData } from '../../redux/actions/Coupon';
import { updateProfile,getUser } from '../../redux/actions/Auth';

const mapStateToProps = (state) => ({
    redeemedCouponTrackingData: state.coupon.redeemedCouponTrackingData,
    redeemedCouponTrackingLoader: state.coupon.redeemedCouponTrackingLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,
     seteditprofile:state.auth.seteditprofile,
     editprofileloader:state.auth.editprofileloader,
});

const mapDispatchToProps = {
    getRedeemedTrackingData,
    updateProfile,
    getUser
};

export default connect(mapStateToProps, mapDispatchToProps)(Editprofile);

