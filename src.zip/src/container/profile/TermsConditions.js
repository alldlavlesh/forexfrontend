import { connect } from 'react-redux';
import TermsConditions from '../../screens/profile/TermsConditions';
import { getRedeemedCoupons } from '../../redux/actions/Coupon'
import {  getUser,deletaccount } from '../../redux/actions/Auth';


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,

});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser,
    deletaccount
};

export default connect(mapStateToProps, mapDispatchToProps)(TermsConditions);

