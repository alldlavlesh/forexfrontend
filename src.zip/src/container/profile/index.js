
import { connect } from 'react-redux';
import Profile from '../../screens/profile';
import { getRedeemedCoupons } from '../../redux/actions/Coupon'
import {  getUser,deletaccount,logout } from '../../redux/actions/Auth';


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
    loginCredentials:state.auth.loginCredentials,
    dashboarddata:state.vendor.dashboarddata,
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser,
    deletaccount,
    logout
};

export default connect(mapStateToProps, mapDispatchToProps)(Profile);

