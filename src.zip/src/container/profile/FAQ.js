
import { connect } from 'react-redux';
import FAQ from '../../screens/profile/FAQ';
import { getRedeemedCoupons } from '../../redux/actions/Coupon'
import {  getUser,deletaccount } from '../../redux/actions/Auth';


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getUserdetail:state.auth.userdarshanDetail,
     loginCredentials:state.auth.loginCredentials,

});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getUser,
    deletaccount
};

export default connect(mapStateToProps, mapDispatchToProps)(FAQ);

