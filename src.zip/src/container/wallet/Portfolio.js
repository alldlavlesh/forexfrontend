
import { connect } from 'react-redux';
import Portfolio from '../../screens/market/Portfolio';
import { getRedeemedCoupons,getTransactionsList } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    transactionslist: state.coupon.transactionslist,
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getTransactionsList
};

export default connect(mapStateToProps, mapDispatchToProps)(Portfolio);

