
import { connect } from 'react-redux';
import Wallet from '../../screens/wallet';
import {getTransactionsList,walletBalance,getDepositDetail, } from '../../redux/actions/Auth'
import {getTransactionsListStock } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getwalletBalance: state.auth.getwalletBalance,
    getDeposit: state.auth.getDeposit,
    transactionStock:state.coupon.transactionStock
    
});

const mapDispatchToProps = {
    getTransactionsList,
    walletBalance,
    getDepositDetail,
    getTransactionsListStock,
};

export default connect(mapStateToProps, mapDispatchToProps)(Wallet);

