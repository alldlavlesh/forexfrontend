
import { connect } from 'react-redux';
import Portfolio from '../../screens/market/Portfolio';
import { getRedeemedCoupons,getTransactionsList,getstocklist } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    getStocklist1: state.coupon.getStocklist,
});

const mapDispatchToProps = {
    getRedeemedCoupons,
    getTransactionsList,
    getstocklist
};

export default connect(mapStateToProps, mapDispatchToProps)(Portfolio);

