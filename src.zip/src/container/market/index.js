
import { connect } from 'react-redux';
import Market from '../../screens/market';
import {stockListing } from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
    getStocklist: state.auth.getStocklist, 
});

const mapDispatchToProps = {
    stockListing, 
};

export default connect(mapStateToProps, mapDispatchToProps)(Market);

