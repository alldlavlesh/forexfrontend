import { connect } from 'react-redux';
import BuyUsdt from '../../screens/buy/BuyUsdt';
import { initiateBuyUSDT } from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    loginCredentials:state.auth.loginCredentials,
    initiateReqUsdt: state.vendor.initiateReqUsdt
});

const mapDispatchToProps = {
    initiateBuyUSDT
};

export default connect(mapStateToProps, mapDispatchToProps)(BuyUsdt);

