
import { connect } from 'react-redux';
import Buy from '../../screens/buy';
import { initiateBuyUSDT,stocksHolds,initiateSellStock } from '../../redux/actions/Vendor'

import { walletBalance } from '../../redux/actions/Auth'


const mapStateToProps = (state) => ({
    redeemedCoupons: state.coupon.redeemedCoupons,
    redeemedCouponsLoader: state.coupon.redeemedCouponsLoader,
    transactionslist: state.coupon.transactionslist,
    stockData:state.vendor.setStockData,
    getwalletBalance:state.auth.getwalletBalance,
    getAssestsHolds:state.vendor.getAssestsHolds
});

const mapDispatchToProps = {
    initiateBuyUSDT,
    walletBalance,
    stocksHolds,
    initiateSellStock
    
};

export default connect(mapStateToProps, mapDispatchToProps)(Buy);

