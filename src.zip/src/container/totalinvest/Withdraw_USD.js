
import { connect } from 'react-redux';
import Withdraw_USD from '../../screens/withdraw/Withdraw_USD';

import { createOrUpdateStore,getStoreInfo,addTransaction,initiateWithdrawRequest } from '../../redux/actions/Vendor';

const mapStateToProps = (state) => ({
    createStoreLoader: state.vendor.createStoreLoader,
    storeInfo: state.vendor.storeInfo,
    dashboarddata:state.vendor.dashboarddata,
    initiateWithdrawRequestdata: state.vendor.initiateWithdrawRequestdata,

});

const mapDispatchToProps = {
    createOrUpdateStore,
    getStoreInfo,
    addTransaction,
    initiateWithdrawRequest
};

export default connect(mapStateToProps, mapDispatchToProps)(Withdraw_USD);

