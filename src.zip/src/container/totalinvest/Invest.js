
import { connect } from 'react-redux';
import Invest from '../../screens/totalinvest/Invest';
import { createNewCoupon, getCouponList } from '../../redux/actions/Coupon'
import { getRedeemedCoupons,getTransactionsList,walletBalance } from '../../redux/actions/Auth'
import { createOrUpdateStore,getStoreInfo,initiateTransaction } from '../../redux/actions/Vendor';

const mapStateToProps = (state) => ({
    couponsList: state.coupon.couponsList,
    loginCredentials: state.auth.loginCredentials,
    initiateReqData: state.vendor.initiateReqData,
    getwalletBalance: state.auth.getwalletBalance,
});

const mapDispatchToProps = {
    createNewCoupon,
    getCouponList,
    initiateTransaction,
    walletBalance
};

export default connect(mapStateToProps, mapDispatchToProps)(Invest);

