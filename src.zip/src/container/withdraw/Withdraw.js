
import { connect } from 'react-redux';
import Withdraw from '../../screens/withdraw/Withdraw';
import { createOrUpdateStore,getStoreInfo,addTransaction,initiateWithdrawRequest } from '../../redux/actions/Vendor';

const mapStateToProps = (state) => ({
    createStoreLoader: state.vendor.createStoreLoader,
    storeInfo: state.vendor.storeInfo,
    dashboarddata:state.vendor.dashboarddata,
    initiateWithdrawRequestdata: state.vendor.initiateWithdrawRequestdata,

});

const mapDispatchToProps = {
    createOrUpdateStore,
    getStoreInfo,
    addTransaction,
    initiateWithdrawRequest
};

export default connect(mapStateToProps, mapDispatchToProps)(Withdraw);

