
import { connect } from 'react-redux';
import Searchlocation from '../../screens/auth/Searchlocation';

const mapStateToProps = (state) => ({

});

const mapDispatchToProps = {

};

export default connect(mapStateToProps, mapDispatchToProps)(Searchlocation);

