
import { connect } from 'react-redux';
import Registration from '../../screens/auth/Registration';
import Verification from '../../screens/auth/Verification';
import SetupPin  from '../../screens/auth/SetupPin';
import { getVendorList, acceptVendor,setVendorInfo } from '../../redux/actions/Vendor';
import {signup, CheckEmail, UpdateRole, signupVendor} from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
    vendorList: state.vendor.vendorList,
    vendorListLoader: state.vendor.vendorListLoader,
    acceptVendorInfo: state.vendor.acceptVendorInfo,
    acceptVendorLoader: state.vendor.acceptVendorLoader,
    loginCredentials: state.auth.loginCredentials,
    isInternetConnected: state.auth.isInternetConnected,
    vendorInfo: state.vendor.vendorInfo,
    signupCredentials: state.auth.signupCredentials,
    signupSuccess: state.auth.signupSuccess,
    registrationLoader: state.auth.registrationLoader,
    existemail: state.auth.existemail
});

const mapDispatchToProps = {
    getVendorList,
    acceptVendor,
    setVendorInfo,
     signup,
    CheckEmail,
    UpdateRole,
    signupVendor
};

export default connect(mapStateToProps, mapDispatchToProps)(SetupPin);

