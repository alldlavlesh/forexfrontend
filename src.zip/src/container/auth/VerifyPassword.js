import { connect } from 'react-redux';
import { VerifyPassword } from '../../screens/auth';
import { verifyOtp,verifyOtpForgotPassword,resendOtp,chnagemobileno,signupVendor } from '../../redux/actions/Auth';

const mapStateToProps = (state) => ({
    otpVerified: state.auth.otpVerified,
    signupCredentials: state.auth.signupCredentials,
    loginCredentials: state.auth.loginCredentials,
    signupSuccess: state.auth.signupSuccess,
    otpVerificationLoader: state.auth.otpVerificationLoader,
    setmobileno:state.auth.setmobileno,
    signupCredentials: state.auth.signupCredentials,
});

const mapDispatchToProps = {
    verifyOtp,
    verifyOtpForgotPassword,
    resendOtp,
    chnagemobileno,
    signupVendor
};

export default connect(mapStateToProps, mapDispatchToProps)(VerifyPassword);
