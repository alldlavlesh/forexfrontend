import { connect } from 'react-redux';
import { WelcomeBack } from '../../screens/auth';
// import {resetPassword} from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
    resetPasswordLoader:state.auth.resetPasswordLoader,
    resetPasswordSuccess:state.auth.resetPasswordSuccess,
    userIdResetpassoword:state.vendor.userIdResetpassoword,
    signupCredentials: state.auth.signupCredentials,

});

const mapDispatchToProps = {
    // resetPassword
};

export default connect(mapStateToProps, mapDispatchToProps)(WelcomeBack);
