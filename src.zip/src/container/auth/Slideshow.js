import { connect } from 'react-redux';
import { Slideshow } from '../../screens/auth';
import { verifyOtp,resendOtp,chnagemobileno,signupVendor } from '../../redux/actions/Auth';

const mapStateToProps = (state) => ({
    otpVerified: state.auth.otpVerified,
    signupCredentials: state.auth.signupCredentials,
    loginCredentials: state.auth.loginCredentials,
    signupSuccess: state.auth.signupSuccess,
    otpVerificationLoader: state.auth.otpVerificationLoader,
    setmobileno:state.auth.setmobileno,
    signupCredentials: state.auth.signupCredentials,
    vendorRequestedInfo: state.auth.vendorRequestedInfo
});

const mapDispatchToProps = {
    verifyOtp,
    resendOtp,
    chnagemobileno,
    signupVendor
};

export default connect(mapStateToProps, mapDispatchToProps)(Slideshow);