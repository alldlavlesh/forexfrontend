
import { connect } from 'react-redux';
import Registration from '../../screens/auth/Registration';
import Verification from '../../screens/auth/Verification';
import { getVendorList, acceptVendor,setVendorInfo } from '../../redux/actions/Vendor';
import { verifyOtp,resendOtp,chnagemobileno,signupVendor } from '../../redux/actions/Auth';

const mapStateToProps = (state) => ({
    otpVerified: state.auth.otpVerified,
    signupCredentials: state.auth.signupCredentials,
    loginCredentials: state.auth.loginCredentials,
    signupSuccess: state.auth.signupSuccess,
    otpVerificationLoader: state.auth.otpVerificationLoader,
    setmobileno:state.auth.setmobileno,
    signupCredentials: state.auth.signupCredentials,
    vendorRequestedInfo: state.auth.vendorRequestedInfo
});

const mapDispatchToProps = {
    verifyOtp,
    resendOtp,
    chnagemobileno,
    signupVendor
};
export default connect(mapStateToProps, mapDispatchToProps)(Verification);

