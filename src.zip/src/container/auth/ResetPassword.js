import { connect } from 'react-redux';
import { ResetPassword } from '../../screens/auth';
import {resetPassword, getUser} from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
    resetPasswordLoader:state.auth.resetPasswordLoader,
    resetPasswordSuccess:state.auth.resetPasswordSuccess,
    userIdResetpassoword:state.vendor.userIdResetpassoword,
    signupCredentials: state.auth.signupCredentials,
    getUserdetail:state.auth.userdarshanDetail,


});

const mapDispatchToProps = {
    resetPassword,
    getUser
};

export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword);
