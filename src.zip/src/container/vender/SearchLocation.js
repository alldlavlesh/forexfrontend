
import { connect } from 'react-redux';
import SearchLocation from '../../screens/vender/searchLocation';

const mapStateToProps = (state) => ({

});

const mapDispatchToProps = {

};

export default connect(mapStateToProps, mapDispatchToProps)(SearchLocation);

