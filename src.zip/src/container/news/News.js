
import { connect } from 'react-redux';
import News from '../../screens/news/News';
import {getNewsList,searchNews } from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
   
    getNewslist: state.auth.getNewslist, 
    searchNewsdata: state.auth.searchNewsdata,
});

const mapDispatchToProps = {
    getNewsList, 
    searchNews
};

export default connect(mapStateToProps, mapDispatchToProps)(News);

