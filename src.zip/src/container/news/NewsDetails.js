
import { connect } from 'react-redux';
import NewsDetails from '../../screens/news/NewsDetails';
import {getNewsList } from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
   
    getNewslist: state.auth.getNewslist, 
});

const mapDispatchToProps = {
    getNewsList, 
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsDetails);

