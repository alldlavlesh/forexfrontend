import { connect } from 'react-redux';
import Notification from '../../screens/coupons/Notification';
import { getCouponList, setNotificationCount } from '../../redux/actions/Coupon'
import { getnotificationlist } from '../../redux/actions/Vendor'

const mapStateToProps = (state) => ({
    couponsList: state.coupon.couponsList,
    couponsListLoader: state.coupon.couponsListLoader,
    isInternetConnected:state.auth.isInternetConnected,
    notificationlist:state.vendor.notificationlist
});

const mapDispatchToProps = {
    getCouponList,
    setNotificationCount,
    getnotificationlist
};

export default connect(mapStateToProps, mapDispatchToProps)(Notification);

