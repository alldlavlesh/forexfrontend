AddcouponServices
import { connect } from 'react-redux';
import AddcouponServices from '../../screens/coupons/AddcouponServices';
import { createNewCoupon, getCouponList } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    couponsList: state.coupon.couponsList,
    couponsListLoader: state.coupon.couponsListLoader,
    createCouponLoader: state.coupon.createCouponLoader,
    createCouponSuccess: state.coupon.createCouponSuccess,
    verificationStatus: state.vendor.verificationStatus,
});

const mapDispatchToProps = {
    createNewCoupon,
    getCouponList
};

export default connect(mapStateToProps, mapDispatchToProps)(AddcouponServices);

