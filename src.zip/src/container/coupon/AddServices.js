import { connect } from 'react-redux';
import AddServices from '../../screens/coupons/AddServices';
import { createNewService, getCouponList } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    couponsList: state.coupon.couponsList,
    couponsListLoader: state.coupon.couponsListLoader,
    createCouponLoader: state.coupon.createCouponLoader,
    createCouponSuccess: state.coupon.createCouponSuccess,
    verificationStatus: state.vendor.verificationStatus,
});

const mapDispatchToProps = {
    createNewService,
    getCouponList
};

export default connect(mapStateToProps, mapDispatchToProps)(AddServices);

