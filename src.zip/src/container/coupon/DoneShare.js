import { connect } from 'react-redux';
import DoneShare from '../../screens/coupons/DoneShare';
import { createNewCoupon } from '../../redux/actions/Coupon'

const mapStateToProps = (state) => ({
    createCouponLoader: state.coupon.createCouponLoader,
    createCouponSuccess: state.coupon.createCouponSuccess,
    loginCredentials:state.auth.loginCredentials,
    initiateReqData: state.vendor.initiateReqData
});

const mapDispatchToProps = {
    createNewCoupon
};

export default connect(mapStateToProps, mapDispatchToProps)(DoneShare);

