import { connect } from 'react-redux';
import Deposite from '../../screens/coupons/Deposite';
import { createNewCoupon, getCouponList } from '../../redux/actions/Coupon'
import { createOrUpdateStore,getStoreInfo,initiateTransaction,depositAmount } from '../../redux/actions/Vendor';

const mapStateToProps = (state) => ({
    couponsList: state.coupon.couponsList,
    loginCredentials: state.auth.loginCredentials,
    initiateReqData: state.vendor.initiateReqData
});

const mapDispatchToProps = {
    createNewCoupon,
    getCouponList,
    initiateTransaction,
    depositAmount
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposite);

