import { connect } from 'react-redux';
import Coupons from '../../screens/coupons';
import { getCouponList, setNotificationCount,dashboardData,getBannerList } from '../../redux/actions/Vendor'


const mapStateToProps = (state) => ({
    couponsList: state.coupon.couponsList,
    couponsListLoader: state.coupon.couponsListLoader,
    isInternetConnected:state.auth.isInternetConnected,
    dashboarddata:state.vendor.dashboarddata,
    loginCredentials: state.auth.loginCredentials,
    bannerList:state.vendor.bannerList
});

const mapDispatchToProps = {
    getCouponList,
    setNotificationCount,
    dashboardData,
    getBannerList,
    
};

export default connect(mapStateToProps, mapDispatchToProps)(Coupons);

