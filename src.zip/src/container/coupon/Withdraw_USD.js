
import { connect } from 'react-redux';
import Withdraw_USD from '../../screens/coupons/Withdraw_USD';

import { createOrUpdateStore,getStoreInfo,addTransaction,initiateWithdrawRequest } from '../../redux/actions/Vendor';
import {getTransactionsList,walletBalance,getDepositDetail, } from '../../redux/actions/Auth'

const mapStateToProps = (state) => ({
    createStoreLoader: state.vendor.createStoreLoader,
    storeInfo: state.vendor.storeInfo,
    dashboarddata:state.vendor.dashboarddata,
    initiateWithdrawRequestdata: state.vendor.initiateWithdrawRequestdata,
    getwalletBalance: state.auth.getwalletBalance,

});

const mapDispatchToProps = {
    createOrUpdateStore,
    getStoreInfo,
    addTransaction,
    initiateWithdrawRequest,
    walletBalance,
};

export default connect(mapStateToProps, mapDispatchToProps)(Withdraw_USD);

